#!/usr/bin/env python3
"""Fail-closed pre-publication authorization gate for the canonical
formal-release workflow (#125, R3 per A's exact-SHA review of 4e6c4e4).

A's entire remote release act is one contents write of the designated
dispatch record (`docs/releases/dispatch.yaml`, the #82 pattern — the one
remote mutation A has durably proven on this repo). A reconciles and
freezes the exact accepted-main target BEFORE the write; the record then
durably mirrors the User authorization (version, authorized_by, timing,
statement), BINDS that frozen exact target SHA (`target`), and carries the
Release Notes verbatim. The dispatch-record commit itself is trigger and
authorization evidence only — it is NEVER the release target and never
changes the release source cut. This gate validates the record and the
frozen target BEFORE the canonical `ght release-publish` primitive
performs any publication write:

- `action: release` marks a release instruction; `action: none` is a clean
  governance write (e.g. clearing the record) and requests nothing;
- a release record must bind the frozen exact target: `target` must be a
  full 40-hex commit SHA — the accepted-main cut A froze before the write;
- only an explicit, User-owned mirror passes: `authorized_by` must be
  exactly `User` — merge state, Issue DONE, Milestone completion,
  runtime/bootstrap need, and deadlines are not release authorization;
- the timing semantics recorded by A must be present;
- the frozen target's CHANGELOG must already carry the version's entry —
  any source change the release requires completed the normal exact-SHA
  review/integration path before the freeze; the workflow never edits
  source;
- the Release Notes block is emitted verbatim for the canonical primitive
  to publish — never regenerated.

The gate reads ONLY the files it is given; the mirror fields are never
re-read from anywhere else and nothing else can substitute for them.
Recording or editing a dispatch record never mints release authority: it
is only ever a durable evidence mirror of an existing User decision. Any
validation failure is fail closed.
"""

import argparse
import json
import re
import sys

RELEASE_TAG = re.compile(r"v\d+(?:\.\d+)*")
TARGET_SHA = re.compile(r"[0-9a-f]{40}")
AUTHORIZED_BY = "User"
ACTION_RELEASE = "release"
ACTION_NONE = "none"
NOTES_BEGIN = "release-notes-begin:"
NOTES_END = "release-notes-end:"


class GateFailure(Exception):
    pass


def parse_dispatch(text: str, source: str) -> tuple[dict[str, str], str]:
    """Parse the dispatch record: flat single-line `key: value` pairs,
    then one verbatim `release-notes-begin:` ... `release-notes-end:`
    block. Blank and comment lines are ignored outside the block; anything
    that is not well-formed fails closed. Returns (fields, notes) where
    notes is the verbatim block content ("" when no block is present)."""
    fields: dict[str, str] = {}
    notes_parts: list[str] = []
    in_notes = False
    notes_closed = False
    for lineno, raw in enumerate(text.splitlines(), 1):
        stripped = raw.strip()
        if in_notes:
            if stripped == NOTES_END:
                in_notes = False
                notes_closed = True
            else:
                notes_parts.append(raw)
            continue
        if not stripped or stripped.startswith("#"):
            continue
        if stripped == NOTES_BEGIN:
            if notes_closed or notes_parts:
                raise GateFailure(f"{source}:{lineno}: duplicate "
                                  f"{NOTES_BEGIN} block — fail closed")
            in_notes = True
            continue
        if stripped == NOTES_END:
            raise GateFailure(f"{source}:{lineno}: {NOTES_END} without "
                              f"{NOTES_BEGIN} — fail closed")
        if ":" not in stripped:
            raise GateFailure(f"{source}:{lineno}: not a 'key: value' line: "
                              f"{raw!r}; single-line key: value pairs only — "
                              "fail closed")
        key, _, value = stripped.partition(":")
        key, value = key.strip(), value.strip()
        if not key or not value:
            raise GateFailure(f"{source}:{lineno}: empty key or value in "
                              f"{stripped!r} — fail closed")
        if key in fields:
            raise GateFailure(f"{source}:{lineno}: duplicate key {key!r} — "
                              "fail closed")
        fields[key] = value
    if in_notes:
        raise GateFailure(f"{source}: {NOTES_BEGIN} block is not closed by "
                          f"{NOTES_END} — fail closed")
    return fields, "\n".join(notes_parts)


def run_gate(version: str, dispatch_path: str, changelog_path: str | None,
             emit_notes: str | None) -> dict[str, object]:
    try:
        dispatch_text = open(dispatch_path, encoding="utf-8").read()
    except OSError as exc:
        raise GateFailure(f"dispatch record unreadable: {exc} — fail closed") from exc
    fields, notes = parse_dispatch(dispatch_text, dispatch_path)

    if "action" not in fields:
        raise GateFailure(f"dispatch record is missing required key "
                          f"'action' — fail closed")
    action = fields["action"]
    if action == ACTION_NONE:
        # A cleared/updated governance write: explicitly not a release
        # instruction. Clean parse is still mandatory (any malformed line
        # above already failed closed), but no mirror/notes validation and
        # no publication request.
        return {"ok": True, "requested": False}
    if action != ACTION_RELEASE:
        raise GateFailure(f"dispatch action {action!r} is not a release "
                          f"instruction ({ACTION_RELEASE!r} or "
                          f"{ACTION_NONE!r}) — fail closed")
    for key in ("version", "target", "authorized_by", "timing", "statement"):
        if key not in fields:
            raise GateFailure(f"release dispatch record is missing required "
                              f"key {key!r} — fail closed")

    if not RELEASE_TAG.fullmatch(version):
        raise GateFailure(f"version must be a Harry Dev release tag "
                          f"(v<major>[.<minor>...]), got {version!r} — "
                          "fail closed")
    if fields["version"] != version:
        raise GateFailure(f"dispatch record authorizes "
                          f"{fields['version']!r}, not the extracted "
                          f"{version!r} — fail closed")
    if not TARGET_SHA.fullmatch(fields["target"]):
        # #125 R3: the record must bind the exact accepted-main target A
        # reconciled/froze BEFORE the write — a full commit SHA, never a
        # ref, a short SHA, or the dispatch record's own commit.
        raise GateFailure(f"dispatch record target {fields['target']!r} is "
                          f"not an exact 40-hex frozen-target commit SHA "
                          f"binding the accepted-main cut A froze before "
                          f"the write — fail closed")
    if fields["authorized_by"] != AUTHORIZED_BY:
        raise GateFailure(f"dispatch record authorized_by is "
                          f"{fields['authorized_by']!r} — not the User "
                          f"({AUTHORIZED_BY!r}): merge state, Issue DONE, "
                          "Milestone completion, runtime/bootstrap need, and "
                          "deadlines are not release authorization — "
                          "fail closed")
    if changelog_path is None:
        raise GateFailure(f"the frozen target's CHANGELOG was not provided "
                          f"for validation — fail closed")
    try:
        changelog = open(changelog_path, encoding="utf-8").read()
    except OSError as exc:
        raise GateFailure(f"CHANGELOG unreadable: {exc} — fail closed") from exc
    if not re.search(rf"(?m)^##\s+{re.escape(version)}(?![.\d])", changelog):
        raise GateFailure(f"the frozen target's CHANGELOG carries no "
                          f"{version!r} entry: any source change this release "
                          "requires must complete the normal exact-SHA "
                          "review/integration path first, then the target is "
                          "re-frozen — the workflow never edits source — "
                          "fail closed")
    if not notes.strip():
        raise GateFailure(f"Release Notes block in the dispatch record "
                          f"({dispatch_path}) is empty — fail closed")
    if emit_notes:
        with open(emit_notes, "w", encoding="utf-8") as handle:
            handle.write(notes + "\n" if not notes.endswith("\n") else notes)
    return {"ok": True, "requested": True, "version": version,
            "target": fields["target"],
            "authorized_by": fields["authorized_by"],
            "timing": fields["timing"]}


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Fail-closed authorization gate for the formal-release "
                    "workflow (#125); validates only the files it is given.")
    parser.add_argument("--version", required=True, metavar="RELEASE_TAG",
                        help="the version extracted from the dispatch "
                             "record's flat head; cross-checked exactly")
    parser.add_argument("--dispatch", required=True, metavar="FILE")
    parser.add_argument("--changelog", required=False, default=None,
                        metavar="FILE",
                        help="the frozen target's CHANGELOG, extracted "
                             "byte-exactly from the frozen target's commit "
                             "objects (required for a release record)")
    parser.add_argument("--emit-notes", metavar="FILE",
                        help="write the verbatim Release Notes block here on "
                             "success (absent when no release is requested)")
    args = parser.parse_args()
    try:
        evidence = run_gate(args.version, args.dispatch, args.changelog,
                            args.emit_notes)
    except GateFailure as exc:
        print(f"formal-release gate: {exc}", file=sys.stderr)
        raise SystemExit(1)
    print(json.dumps(evidence))


if __name__ == "__main__":
    main()
