"""GitHub intake surface for github-task.

Every GitHub CLI call lives here so the supported request surface is
auditable in one place:

- ``gh issue view --json`` is only ever asked for fields the GitHub CLI
  actually exposes; the unsupported Issue/PR discriminator flag is never
  requested;
- Issue-versus-PR discrimination uses the returned ``url`` shape, with a
  ``gh pr view`` fallback for CLI versions that refuse to view a PR
  through ``gh issue view``;
- the Issue mirror mutations the runtime performs are removing the
  one-shot ``ready`` label, evidence comments, and the ONE mechanical
  lifecycle close: ``issue_close_completed`` closes an Issue with
  state_reason completed ONLY as the final reconciliation step of an
  already-proven A-owned acceptance (#171) — an already-closed Issue is
  never reopened or re-reasoned, and success is reported only when the
  durable Issue proves CLOSED with state_reason completed.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


ISSUE_FIELDS = ("number", "title", "body", "state", "stateReason", "url", "labels",
                "assignees", "comments")
LABELS_FIELDS = ("number", "state", "url", "labels")
PR_FIELDS = ("number", "state", "url")
PR_VIEW_FIELDS = ("number", "state", "url", "headRefName", "headRefOid", "mergeCommit")

_PR_URL = re.compile(r"/pull/\d+/?$")


class IntakeError(RuntimeError):
    def __init__(self, message: str, *, kind: str = "error"):
        super().__init__(message)
        self.kind = kind  # "pr" | "missing" | "error"


class MirrorError(RuntimeError):
    """A GitHub mirror mutation failed after claim ownership was established."""


def _run(command: list[str], check: bool = True,
         cwd: str | None = None) -> subprocess.CompletedProcess[str]:
    try:
        result = subprocess.run(command, capture_output=True, text=True, cwd=cwd)
    except OSError as exc:
        # A missing/unrunnable executable degrades to a failed probe result,
        # never an unhandled crash: callers fail closed through their normal
        # returncode paths (127 = executable not found).
        result = subprocess.CompletedProcess(command, 127, "",
                                             f"{type(exc).__name__}: {exc}")
    if check and result.returncode:
        detail = result.stderr.strip() or result.stdout.strip() or "command failed"
        raise RuntimeError(f"command failed: {' '.join(command[:3])}...: {detail}")
    return result


# ------------------------------------------- gh resolution + tool provision
# #165 AC2 (R1): the gh executable is resolved through ONE deterministic
# seam so every surface (preflight, bootstrap, discovery, release
# publication, the GitHub adapter) uses the same binary: an explicit
# ``GHT_GH_BIN`` override, then the Skill-owned user-space provisioning
# location, then PATH. The provisioning location is deliberately OUTSIDE
# the installed distribution tree — a tool installation must never change
# the installed distribution's content identity.

GHT_GH_BIN_ENV = "GHT_GH_BIN"
GHT_TOOL_BIN_DIR_ENV = "GHT_TOOL_BIN_DIR"


def tool_bin_dir() -> Path:
    """The canonical user-space directory ght owns for provisioned
    non-secret tooling (``~/.local/share/harry-dev/bin``, XDG-aware). No
    root, no system locations; ``GHT_TOOL_BIN_DIR`` is the explicit
    override (and the hermetic test seam)."""

    override = os.environ.get(GHT_TOOL_BIN_DIR_ENV, "").strip()
    if override:
        return Path(override).expanduser()
    data_home = os.environ.get("XDG_DATA_HOME", "").strip()
    base = Path(data_home).expanduser() if data_home else Path.home() / ".local" / "share"
    return base / "harry-dev" / "bin"


def provisioned_gh_path() -> Path | None:
    """The provisioned gh binary, when one is installed and executable."""

    candidate = tool_bin_dir() / "gh"
    if candidate.is_file() and os.access(candidate, os.X_OK):
        return candidate
    return None


def gh_executable() -> str:
    """The gh binary this process uses: ``GHT_GH_BIN`` override, then the
    provisioned user-space installation (deterministic — a provisioned gh
    is preferred over whatever happens to sit on PATH), then PATH."""

    override = os.environ.get(GHT_GH_BIN_ENV, "").strip()
    if override:
        return override
    provisioned = provisioned_gh_path()
    if provisioned is not None:
        return str(provisioned)
    return "gh"


def classify_object(number: int, url: str) -> str:
    """Classify a GitHub object as ``issue`` or ``pr`` from its URL shape."""

    path = urlparse(url).path
    if _PR_URL.search(path):
        return "pr"
    return "issue"


class GitHub:
    """Thin, auditable adapter over the supported GitHub CLI surfaces."""

    def __init__(self, repo: str | None = None, remote: str = "origin"):
        self.repo = repo
        self.remote = remote

    def _base(self) -> list[str]:
        """The argv prefix for REPO-SCOPED subcommands only (issue/pr/
        release/repo view) — the one class the real CLI accepts ``--repo``
        on. Global-scope commands (``gh api``, ``gh auth``) refuse the flag
        ("unknown flag: --repo") and are invoked through the bare
        executable (see ``principal``)."""
        return [gh_executable(), "--repo", self.repo] if self.repo else [gh_executable()]

    def slug(self) -> str | None:
        """``owner/repo`` for ``gh api`` paths, which never auto-infer."""

        if self.repo:
            return self.repo.strip()
        # Same inference surface as ``gh pr view``: the GitHub CLI resolves
        # the repository from the git remote, whatever URL shape it has.
        result = _run([gh_executable(), "repo", "view", "--json", "nameWithOwner",
                       "--jq", ".nameWithOwner"], check=False)
        if result.returncode:
            return None
        slug = result.stdout.strip()
        return slug or None

    # Historical internal name kept as an alias.
    _slug = slug

    def issue_list_ready(self, label: str) -> list[int] | None:
        """Open Issues carrying the one-shot authorization label — B's
        read-only auto-discovery surface (AC4). Returns ``None`` when the
        listing surface itself is unavailable (durable truth unreadable →
        discovery must fail closed), vs. an empty list (no ready work)."""
        result = _run([*self._base(), "issue", "list", "--state", "open",
                       "--label", label, "--json", "number"], check=False)
        if result.returncode:
            return None
        try:
            data = json.loads(result.stdout)
        except json.JSONDecodeError as exc:
            raise IntakeError(f"gh returned invalid JSON: {exc}") from exc
        return sorted(int(item["number"]) for item in data)

    def pr_edit_body(self, number: int, body: str) -> bool:
        """Replace a PR body — the mechanical Current Candidate Snapshot
        update (AC19). Returns False when the edit could not be applied;
        delivery stays durable either way."""

        import os
        import tempfile
        fd, path = tempfile.mkstemp(prefix="ght-snapshot-", suffix=".md")
        try:
            with os.fdopen(fd, "w") as handle:
                handle.write(body)
            result = _run([*self._base(), "pr", "edit", str(number),
                           "--body-file", path], check=False)
        finally:
            os.unlink(path)
        return result.returncode == 0

    def principal(self) -> str | None:
        """The authenticated GitHub principal, or None when the credential
        cannot answer ``GET /user`` — GitHub App installation tokens (the
        Actions ``GITHUB_TOKEN``) do not support that endpoint. Callers
        decide whether a principal is mandatory (every ownership-sensitive
        path) or an explicit machine/reconciler identity may stand in
        (executor-neutral completion audit only).

        ``gh api user`` is a GLOBAL-scope invocation (review R2 finding 2):
        the real CLI refuses ``gh --repo <repo> api user`` with
        "unknown flag: --repo", so the explicit repository selection is
        never attached here — the principal is repo-independent by
        definition, and repo-scoped calls carry the selection through
        ``_base()``."""
        result = _run([gh_executable(), "api", "user", "--jq", ".login"], check=False)
        if result.returncode:
            return None
        return result.stdout.strip() or None

    def _view(self, fields: tuple[str, ...], *command: str) -> dict[str, Any] | None:
        result = _run([*self._base(), *command, "--json", ",".join(fields)], check=False)
        if result.returncode:
            return None
        try:
            return json.loads(result.stdout)
        except json.JSONDecodeError as exc:
            raise IntakeError(f"gh returned invalid JSON: {exc}") from exc

    def issue_view(self, number: int) -> dict[str, Any]:
        """Fetch the object, refusing Pull Requests on supported grounds.

        Modern ``gh issue view`` happily returns a Pull Request object; the
        URL shape is what mechanically distinguishes it. Older versions fail
        the view instead, so a ``gh pr view`` probe gives the precise reason.
        """

        data = self._view(ISSUE_FIELDS, "issue", "view", str(number))
        if data is not None:
            if classify_object(number, data.get("url", "")) == "pr":
                raise IntakeError(f"#{number} is a Pull Request, not an Issue", kind="pr")
            return data
        probe = self._view(PR_FIELDS, "pr", "view", str(number))
        if probe is not None:
            raise IntakeError(f"#{number} is a Pull Request, not an Issue", kind="pr")
        raise IntakeError(f"#{number} is not a viewable GitHub Issue", kind="missing")

    def issue_labels(self, number: int) -> set[str]:
        data = self._view(LABELS_FIELDS, "issue", "view", str(number))
        if data is None:
            raise IntakeError(f"cannot read labels for #{number}", kind="missing")
        if classify_object(number, data.get("url", "")) == "pr":
            raise IntakeError(f"#{number} is a Pull Request, not an Issue", kind="pr")
        return {label.get("name", "") for label in data.get("labels", [])}

    def pr_view(self, number: int) -> dict[str, Any] | None:
        """Fetch durable PR facts (supported ``gh pr view`` fields only)."""

        return self._view(PR_VIEW_FIELDS, "pr", "view", str(number))

    def pr_reviews(self, number: int) -> list[dict[str, Any]] | None:
        """Fetch the PR's durable review surface (REST review objects).

        Returns the full review objects (each carrying ``state`` and the
        exact ``commit_id`` the review binds to), or ``None`` when the
        reviews surface cannot be read — callers must fail closed on None.
        """

        slug = self._slug()
        if not slug:
            return None
        result = _run([gh_executable(), "api", f"repos/{slug}/pulls/{number}/reviews"], check=False)
        if result.returncode:
            return None
        try:
            reviews = json.loads(result.stdout)
        except json.JSONDecodeError as exc:
            raise IntakeError(f"gh returned invalid JSON: {exc}") from exc
        return reviews if isinstance(reviews, list) else None

    def pr_comments(self, number: int) -> list[dict[str, Any]] | None:
        """Fetch the PR's top-level comment surface (REST issue comments).

        This is where the canonical structured exact-SHA ACCEPT fallback
        lives when platform identity prevents a native review action.
        Returns ``None`` when the surface cannot be read — callers must
        fail closed on None.
        """

        slug = self._slug()
        if not slug:
            return None
        result = _run([gh_executable(), "api", f"repos/{slug}/issues/{number}/comments"], check=False)
        if result.returncode:
            return None
        try:
            comments = json.loads(result.stdout)
        except json.JSONDecodeError as exc:
            raise IntakeError(f"gh returned invalid JSON: {exc}") from exc
        return comments if isinstance(comments, list) else None

    def remove_label(self, number: int, label: str) -> tuple[bool, str | None]:
        result = _run([*self._base(), "issue", "edit", str(number), "--remove-label", label], check=False)
        if result.returncode == 0:
            return True, None
        return False, (result.stderr.strip() or result.stdout.strip() or "gh issue edit failed")

    def consume_ready(self, number: int, label: str, *, attempts: int = 3) -> dict[str, Any]:
        """Consume the one-shot READY authorization and repair the mirror.

        Claim CAS is the ownership truth, but a failed label removal must
        never leave the authorization mirror silently available. Removal is
        retried and each attempt is verified by re-reading the Issue; only a
        verified absence counts as consumed.
        """

        last_error: str | None = None
        for attempt in range(1, attempts + 1):
            removed, error = self.remove_label(number, label)
            if removed:
                try:
                    if label not in self.issue_labels(number):
                        return {"consumed": True, "attempts": attempt, "verified": True}
                    last_error = "label still present after successful removal"
                except IntakeError as exc:
                    last_error = f"verification read failed: {exc}"
            else:
                last_error = error
        return {"consumed": False, "attempts": attempts, "verified": False, "error": last_error}

    def issue_close_completed(self, number: int) -> dict[str, Any]:
        """The one mechanical Issue lifecycle close (state_reason completed)
        — the final reconciliation step of an A-owned acceptance that a
        caller has already proven on the durable review/merge surfaces
        (#171). This method owns NO acceptance judgment: it neither reads
        reviews nor inspects the attempt; it only executes the close
        narrowly and verifiably.

        Successful convergence is reported ONLY when the durable Issue
        proves CLOSED with state_reason completed. An already-closed Issue
        is never reopened or re-reasoned: with state_reason completed it is
        the converged no-op; with any other or unknown reason it is an
        A-owned lifecycle decision preserved untouched (no provenance
        distinction, no second registry) but NOT converged — ``preserved``
        fail-closed, because AC1's terminal state is not true. An open
        Issue is closed with state_reason completed and the close is PROVEN
        by a fresh read: success is returned only when the durable Issue
        reads CLOSED with state_reason completed (#171 AC1) — a close
        command that reports success but leaves any other durable state or
        reason (including a concurrent lifecycle transition) is a failure.
        Raises IntakeError when the Issue surface is unreadable;
        ``{"action": "failed", "error": ...}`` when the close mutation does
        not land OR the verified/observed reason contradicts the required
        one — callers fail closed on all of these.
        """

        issue = self.issue_view(number)
        if str(issue.get("state", "")).upper() == "CLOSED":
            reason = issue.get("stateReason")
            if str(reason or "").upper() == "COMPLETED":
                return {"action": "none", "state": "CLOSED",
                        "state_reason": reason}
            shown = "null" if reason is None else str(reason)
            return {"action": "failed", "preserved": True,
                    "state": "CLOSED", "state_reason": reason,
                    "error": "the Issue is already CLOSED with state_reason "
                             f"{shown!r}, not 'completed' — an A-owned "
                             "lifecycle decision preserved untouched (never "
                             "reopened, never re-reasoned); successful "
                             "completion convergence requires CLOSED with "
                             "state_reason 'completed' (#171 AC1)"}
        result = _run([*self._base(), "issue", "close", str(number),
                       "--reason", "completed"], check=False)
        if result.returncode:
            detail = result.stderr.strip() or result.stdout.strip() or "gh issue close failed"
            return {"action": "failed", "error": detail}
        verified = self.issue_view(number)
        if str(verified.get("state", "")).upper() != "CLOSED":
            return {"action": "failed",
                    "error": "Issue still open after `gh issue close`"}
        reason = verified.get("stateReason")
        if str(reason or "").upper() != "COMPLETED":
            shown = "null" if reason is None else str(reason)
            return {"action": "failed",
                    "error": "`gh issue close` reported success but the durable "
                             f"Issue is CLOSED with state_reason {shown!r}, not "
                             "'completed' — the required terminal state is "
                             "unproven"}
        return {"action": "closed", "state_reason": reason}

    def create_pr(self, head_branch: str, title: str, body: str,
                  *, cwd: str | None = None) -> str:
        """Open a PR from an orchestrated Candidate branch (orchestrator
        HOW surface). Returns the PR URL."""
        result = _run([*self._base(), "pr", "create", "--head", head_branch,
                       "--title", title, "--body", body], check=False, cwd=cwd)
        if result.returncode:
            detail = result.stderr.strip() or result.stdout.strip() or "gh pr create failed"
            raise MirrorError(f"PR creation failed: {detail}")
        return result.stdout.strip()

    @staticmethod
    def parse_pr_number(pr_url: str) -> int:
        match = re.search(r"/pull/(\d+)", pr_url)
        if not match:
            raise MirrorError(f"cannot parse a PR number from {pr_url!r}")
        return int(match.group(1))

    def comment(self, number: int, body: str, marker: str) -> None:
        try:
            issue = self.issue_view(number)
        except IntakeError as exc:
            raise MirrorError(f"cannot read #{number} for evidence comment: {exc}") from exc
        if any(marker in entry.get("body", "") for entry in issue.get("comments", [])):
            return
        result = _run([*self._base(), "issue", "comment", str(number), "--body", body], check=False)
        if result.returncode:
            detail = result.stderr.strip() or result.stdout.strip() or "gh issue comment failed"
            raise MirrorError(f"evidence comment failed: {detail}")
