# github-task — navigation and command reference (non-normative)

> **This README is non-normative navigation/reference.** It owns no
> authorization, claim-lifecycle, concurrency, or runtime state-machine
> semantics, and no normative fact may be inferred from it. Every fact
> class has exactly one owner surface — if this file ever disagrees with
> an owner below, the owner wins:

| If you need… | Canonical owner |
| --- | --- |
| A behavior — planning, authorization, review, scheduling rules | [`prompts/A-project-rules.md`](../../prompts/A-project-rules.md) |
| B behavior — orchestration, delivery, review loop, fail-closed HOW | [`SKILL.md`](SKILL.md) |
| Contract schema / CLI / refs / fencing / completion mechanics | the [`github_task/`](github_task/) runtime source, `ght --help`, and the executable [`tests/`](tests/) |
| Current execution / review / release state | GitHub / ght durable truth — Issues, PRs, `refs/ght/*`, `ght status`, `ght inspect` |

A reader recovers every normative fact one-way from those owners; this
README only navigates. github-task carries no independent product
version — `ght version` reports the carried Harry Dev release identity.

## Quick start

In a governed checkout, B starts with `ght discover` (strictly read-only;
it consumes nothing) and follows its decision through the canonical
commands. The B operating flow, fail-closed boundary, and default
execution-lease timings with their override semantics live in
[SKILL.md](SKILL.md):

```bash
python3 skills/github-task/scripts/ght.py discover
python3 skills/github-task/scripts/ght.py claim <issue>   # or --plan-authorization <id> / --mode implement|investigate
# ... engineer inside the Contract boundary; the Superpowers skills own
#     the generic engineering HOW (with 2+ independent runnable work
#     items and host capacity: superpowers:dispatching-parallel-agents)
python3 skills/github-task/scripts/ght.py scope-check <issue>
python3 skills/github-task/scripts/ght.py preserve <issue>
python3 skills/github-task/scripts/ght.py deliver <issue> --pr <N> [--snapshot <file>]
```

Run the regression suite from this directory:

```bash
python3 -m unittest discover -s tests -t . -p 'test_*.py'
```

## Command index (pointers only)

`ght --help` and each subcommand's `--help` are the mechanical truth for
flags and semantics; the [`github_task/`](github_task/) source and the
[`tests/`](tests/) own every protocol fact. The surfaces:

```text
ght version                  # carried Harry Dev distribution identity
ght preflight                # supported-host/install preflight (#165): one pass that
                             # establishes tooling (missing gh is provisioned
                             # user-space from the official cli/cli release's real
                             # archive layout on macOS/Linux); ONE actionable
                             # blocker list remains (after provisioning: `gh auth
                             # login` consent, named as the exact executable
                             # command for the installed gh binary)
ght bootstrap                # one-time mechanical downstream bootstrap (#165): proves
                             # host + write access, then publish + activate + read
                             # back the exact installed RELEASED identity in an
                             # uninitialized repo (concurrency-fenced, create-only
                             # activation), then the fresh discover verdict in the
                             # same activation; first adoption also applies the
                             # project AGENTS contract (#166) before anything is
                             # published; never touches an initialized runtime
ght agents-adopt [--root DIR] [--upgrade]
                             # project AGENTS contract adoption (#166): the same
                             # reconciliation the first-adoption bootstrap runs —
                             # apply/reconcile the released canonical managed block
                             # in the target repository's root AGENTS.md; idempotent,
                             # project-owned content preserved byte-for-byte, nested
                             # AGENTS.md/AGENTS.override.md never touched; material
                             # authority/security/credential conflicts fail closed
                             # for A; no implicit upgrade (--upgrade is only
                             # the execution selector for a release upgrade
                             # ALREADY authorized for the project — the flag
                             # is not itself the authorization, and the
                             # surface cannot mechanically verify the
                             # authorization exists); prepares a
                             # working-tree change only — never commits or
                             # pushes
ght identity                 # executor/identity facts
ght status                   # this executor's claim/lease view
ght inspect <issue>          # one Issue's durable claim lineage
ght discover [--evidence-comment]
                             # read-only durable-truth discovery / workset handoff
                             # (freshness preflight semantics: SKILL.md + source)
ght validate-ready <issue>   # read-only pre-READY mechanical eligibility check
ght claim <issue>            # start an attempt (--mode implement|investigate | --plan-authorization <id>)
ght verify <issue>           # live-attempt verification gate
ght heartbeat <issue>        # manual lease renewal
ght acquire <issue>          # same-attempt resume after REQUEST_CHANGES
ght takeover <issue>         # recover a STALE attempt with durable evidence
ght reclaim-execution-resource <issue>
                             # authorize/confirm fenced destructive worktree
                             # removal (#147): atomic CAS marker on the claim
                             # ref; claim/acquire fail closed while pending
ght ready-repair <issue>     # repair stale `ready` residue after a successful claim
ght scope-check <issue>      # mechanical forbidden-scope gate
ght preserve <issue>         # snapshot the exact Candidate SHA
ght deliver <issue> --pr <N> # hand the Candidate to A (not terminal)
ght complete <issue>         # terminalize after A's merge (executor-neutral)
ght release <issue> --status investigated|blocked --note ...
ght contract-digest <issue>  # canonical Contract digest surface (Plan binding)
ght plan-publish <file>      # publish an immutable Execution Plan revision
                             #   --bind-contract-digests: mechanically bind digest-free
                             #   authoring nodes via the canonical digest primitive (#156);
                             #   the remote publication workflow always passes this
ght plan-view <plan-id>
ght orchestrate              # evaluate the current Plan; hand work to the online primary B
ght migrate-claims           # legacy-namespace migration / expired-reservation cleanup
ght supervise <issue>        # lease supervision (normally auto-spawned at claim time)
ght sync-runtime             # runtime capsule sync
ght activate-runtime         # runtime capsule activation
ght stamp-distribution --release vX.Y.Z         # release packaging
ght release-publish --version vX.Y.Z --target <exact-accepted-main-sha> --notes-file <file>
                             # A-facing release publication (#108): decision-execution only —
                             # User owns whether/when/which version; A owns post-authorization publication and read-back;
                             # B owns HOW; it never chooses version/target/membership/time
```

## Troubleshooting anchors

- `OMP: Error #15` libomp abort under the system Python: prefix the test
  command with `KMP_DUPLICATE_LIB_OK=TRUE`; the suite itself is
  stdlib-only.
- A stale `ready` label persisting after a successful claim: the owning
  worker repairs the mirror with `ght ready-repair <issue>` — never by
  re-claiming.
- A failed ght command is a fail-closed verdict: recover only through its
  stated path (`ght acquire` for same-attempt resume, `ght takeover`
  after lease expiry) or stop and report — see SKILL.md.
- Lease supervision reported as not established: `ght supervise <issue>`
  re-establishes it.
- The automatic supervisor watches the launching execution host with an
  ephemeral kernel process-exit handle. If the host exits, renewal stops;
  the lease remains for canonical expiry/grace and `ght discover` recovery.
  The binding and fencing rules live in [SKILL.md](SKILL.md).
- `ght discover` returns `refresh_required`: reload the local
  Skill/distribution to the activated identity and re-run `ght discover`
  — the decision semantics live in [SKILL.md](SKILL.md).
- Executor worktrees live under the repo-local `.worktree/` directory
  (ignored by the primary working tree, bounded lifetime, disposable
  host state); recovery always reconstructs from GitHub / ght durable
  truth, never from host-local state.
- Worktree cleanup has exactly one destructive route: the fenced reclaim
  sequence owned by the package-owned `scripts/worktree_cleanup.py`
  (inside this Skill, invoked from the installed Skill's own location —
  the target repository never needs a Skill copy: default ght resolution
  anchors on the installed Skill itself, `--ght` stays the host/test
  override; `--execute`, authorized via `ght
  reclaim-execution-resource`; the Harry Dev repository root carries no
  cleanup implementation). Raw `rm -rf
  .worktree/<issue>`, bare `git worktree remove`, and directory-age/PID
  heuristics are forbidden bypasses; the helper's raw remover is internal
  to that sequence — module-private and proof-gated, not an importable
  second entrypoint. GitHub Issue/PR open/closed/merged
  state is never deletion authority. The normative anti-bypass invariant
  lives in [SKILL.md](SKILL.md).
- `refs/heads/claims*` is a legacy compatibility/migration namespace;
  current lineage lives under `refs/ght/claims/` (mechanics: source +
  tests).
- Retired historical semantics are pinned by regression tests in
  [`tests/`](tests/), not re-documented here.
