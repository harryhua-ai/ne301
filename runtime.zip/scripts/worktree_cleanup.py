#!/usr/bin/env python3
"""Fenced worktree cleanup for Harry Dev Issue-executor worktrees (#147).

Host-side/best-effort cleanup must never delete the execution resource of
the current canonical ACTIVE execution capacity — neither an in-flight
executor nor the claim-established-but-pre-dispatch window. Eligibility is
therefore reconciled against canonical GitHub/ght ownership truth
(``ght status`` / ``ght inspect``): discovery (plan) is a diagnostic
snapshot that never authorizes deletion.

The destructive pass is mechanically exclusion-fenced (AC3): removal is
conditional on an atomic ght-side authorization that makes an ACTIVE
transition impossible between authorization and the destructive call.
``ght reclaim-execution-resource <issue> --expect-claim-sha <sha>``
re-reads the claim record fresh, requires the caller's eligibility-read
``claim_sha`` to still anchor the claim ref head, validates the
reclaimable predicate, and CAS-appends a pending-reclaim marker onto the
claim ref — the same CAS domain every capacity-establishing transition
(``ght claim`` / ``ght acquire`` / takeover / renewal) must win to become
valid, serialized by git's force-with-lease. While the marker holds, every
claim/acquire for the Issue fails closed, so no worktree can become the
current ACTIVE execution resource after authorization and before removal;
conversely, a transition that won the ref first makes the authorization
refuse (the caller's anchor no longer matches) and no removal happens.
After the removal, ``--confirm-removal`` clears the marker (CAS-anchored),
restoring normal claim/acquire semantics. For a true orphan (no claim
lineage) the authorization CAS-creates a reclaim tombstone with an empty
expect-lease — a racing fresh claim loses the CAS and fails closed — and
the confirm deletes it. ght is the only writer of its claim-ref CAS
domain, so the authorization is ght's own authoritative record inside the
first ownership truth, not a second registry.

Missing, unreadable, ambiguous, or contradictory ownership truth fails
closed instead of treating a worktree as orphaned — including a refused
authorization, which fences the worktree with a diagnostic instead of
removing it. This stays a single-shot host tool: no durable worktree
registry, no worker database, no polling GC, no daemon, no loop.
PID/process existence and directory age are never consulted as ownership
authority. The helper itself performs no claim/lease lifecycle mutation —
the marker is written and cleared by ght's own atomic primitive, and
ght discover/acquire/fencing remain canonical. Worktrees remain disposable
host state under the #97 bounded lifetime: true orphans (authoritative
claim absence), terminal attempts, and parked (delivered, no live
capacity) resources stay reclaimable.

The canonical implementation is package-owned: it lives inside the
complete standalone ``github-task`` Skill package so a downstream B host
can run fenced cleanup beside an unrelated target repository without any
Harry Dev source checkout (#155). The normal invocation resolves its
canonical ght from the installed Skill itself — the ``ght.py`` packaged
beside this helper — never from the target repository, which carries no
Skill copy; an explicit ``--ght`` stays the test/host override.

Usage (dry-run is the default; removal is always explicit; invoke the
helper from its installed Skill location):

    python3 <installed github-task Skill>/scripts/worktree_cleanup.py --repo-root /path/to/repo
    python3 <installed github-task Skill>/scripts/worktree_cleanup.py --repo-root /path/to/repo --execute
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

PROTECTED = "PROTECTED"
RECLAIMABLE = "RECLAIMABLE"
FAIL_CLOSED = "FAIL_CLOSED"

_NON_TERMINAL_STATES = ("ACTIVE", "STALE")


@dataclass(frozen=True)
class IssueOwnership:
    """Canonical ownership facts for one Issue, as read from ght.

    ``readability`` records whether canonical truth was readable at all:
    ``readable``, ``unreadable`` (missing/broken/truncated), or
    ``ambiguous`` (contradictory). Everything else mirrors the canonical
    surfaces verbatim — ``claim_state`` is ght's own NONE/ACTIVE/STALE/
    TERMINAL classification, ``candidate`` the durable Candidate SHA once
    delivered, ``capacity_live`` the canonical execution-capacity
    classification for this coordination identity, and ``fencing_token``
    the claim record's current commit SHA (``ght inspect``'s
    ``claim_sha``) — the canonical identity whose immutability across the
    removal boundary fences stale decisions (AC3).
    """

    issue: Optional[int]
    readability: str
    claim_state: Optional[str] = None
    executor_id: Optional[str] = None
    candidate: Optional[str] = None
    capacity_live: bool = False
    identity_executor_id: Optional[str] = None
    fencing_token: Optional[str] = None


def classify_ownership(own: IssueOwnership) -> str:
    """Fence decision for destructive cleanup of one Issue worktree.

    AC1: a non-terminal claim lineage that is not canonically parked is
    never cleanup-eligible — this covers a running executor (live
    capacity) and the pre-dispatch window (claim established, no durable
    Candidate yet). AC2: unreadable/ambiguous/contradictory truth fails
    closed. AC4: true orphans (authoritative NONE), terminal attempts, and
    parked deliveries (durable Candidate, no live capacity — the canonical
    parked predicate) stay reclaimable under the #97 bounded lifetime.
    """
    if own.readability != "readable":
        return FAIL_CLOSED
    if own.claim_state == "NONE":
        return RECLAIMABLE
    if own.claim_state == "TERMINAL":
        return RECLAIMABLE
    if own.claim_state in _NON_TERMINAL_STATES:
        if own.executor_id != own.identity_executor_id:
            # A non-terminal claim of another coordination identity is not
            # this cleanup's to judge — fail closed, never orphan it.
            return FAIL_CLOSED
        if own.capacity_live:
            return PROTECTED
        if own.candidate:
            return RECLAIMABLE
        return PROTECTED
    return FAIL_CLOSED


class ReclaimRefused(Exception):
    """The ght-side reclaim authorization refused this removal.

    Raised when ``ght reclaim-execution-resource`` fails: canonical
    ownership moved since the eligibility read, the record is not
    reclaimable, or ght truth is unreadable. The removal never happens —
    the fence stays closed with a diagnostic instead of a silent skip."""


class GhtReclaimCaller:
    """Issues the atomic ght-side reclaim authorization/confirmation.

    ``ght reclaim-execution-resource`` is ght's own CAS primitive on the
    Issue's claim ref: authorize re-reads remote truth, validates the
    reclaimable predicate against the caller's eligibility-read
    ``claim_sha`` anchor, and CAS-writes the pending-reclaim marker in one
    force-with-lease transition; confirm clears it after the removal. Any
    non-zero outcome raises :class:`ReclaimRefused` — the caller fences the
    worktree instead of removing it."""

    def __init__(self, runner: Callable[[list[str]], tuple[int, str]]):
        self._runner = runner

    @classmethod
    def from_cli(cls, ght_cmd: Optional[str] = None) -> "GhtReclaimCaller":
        prefix = _ght_command(ght_cmd)
        return cls(runner=lambda cmd: _default_runner(prefix + cmd))

    def _invoke(self, args: list[str]) -> dict:
        rc, out = self._runner(args)
        payload = None
        try:
            payload = json.loads(out)
        except json.JSONDecodeError:
            payload = None
        if rc != 0 or not isinstance(payload, dict):
            detail = (payload or {}).get("error") if isinstance(payload, dict) else None
            raise ReclaimRefused(str(detail or out.strip() or f"ght exited {rc}"))
        return payload

    def authorize(self, issue: int, fencing_token: Optional[str]) -> str:
        """Authorize the removal atomically; returns the marker commit SHA."""
        payload = self._invoke(["reclaim-execution-resource", str(issue),
                                "--expect-claim-sha", fencing_token or ""])
        marker_sha = payload.get("marker_sha")
        if not isinstance(marker_sha, str) or not marker_sha:
            raise ReclaimRefused("ght authorization returned no marker identity")
        return marker_sha

    def confirm(self, issue: int, marker_sha: str) -> None:
        """Confirm the removal: clears the pending-reclaim marker."""
        self._invoke(["reclaim-execution-resource", str(issue), "--confirm-removal",
                      "--expect-claim-sha", marker_sha])


@dataclass(frozen=True)
class WorktreeRef:
    """One `.worktree/` entry. Names that are not an Issue number have no
    canonical per-Issue ownership to reconcile and are fenced shut."""

    name: str
    path: str
    issue: Optional[int]


def iter_worktrees(repo_root: Path) -> list[WorktreeRef]:
    worktree_root = Path(repo_root) / ".worktree"
    if not worktree_root.is_dir():
        return []
    entries = []
    for child in sorted(worktree_root.iterdir()):
        if not child.is_dir():
            continue
        issue = int(child.name) if child.name.isdigit() else None
        entries.append(WorktreeRef(name=child.name, path=str(child), issue=issue))
    return entries


@dataclass(frozen=True)
class CleanupPlanItem:
    name: str
    path: str
    issue: Optional[int]
    verdict: str


def plan_cleanup(repo_root: Path, read_ownership: Callable[[Optional[int]], IssueOwnership]) -> list[CleanupPlanItem]:
    """Diagnostic snapshot only. The returned verdicts are advisory: the
    destructive path (``execute_cleanup``) never consumes them — it
    revalidates ownership fresh at the removal boundary (AC3)."""
    plan = []
    for entry in iter_worktrees(repo_root):
        verdict = classify_ownership(read_ownership(entry.issue))
        plan.append(CleanupPlanItem(name=entry.name, path=entry.path,
                                    issue=entry.issue, verdict=verdict))
    return plan


def execute_cleanup(
    repo_root: Path,
    read_ownership: Callable[[Optional[int]], IssueOwnership],
    authorize_removal: Callable[[int, Optional[str]], str],
    confirm_removal: Callable[[int, str], None],
    remove: Optional[Callable[[str], None]] = None,
) -> dict:
    """Destructive pass with atomically exclusion-fenced removal (AC3).

    Per candidate worktree:
      1. eligibility read — the fresh classification must be RECLAIMABLE,
         and its canonical ``claim_sha`` anchors the authorization;
      2. atomic ght authorization — ``authorize_removal(issue, token)``
         CAS-writes the pending-reclaim marker onto the claim ref; a
         refusal (ownership moved, not reclaimable, truth unreadable)
         raises and the worktree is fenced, never removed;
      3. removal — while the marker holds, no ``ght claim``/``ght acquire``
         for the Issue can establish ACTIVE execution capacity, so nothing
         can become the current ACTIVE resource in this window; the
         destructive call consumes the single-use
         :class:`RemovalAuthorization` proof minted from the marker
         (bound to this one path), so the raw remover cannot fire without
         — or outside — the fence (#154 anti-bypass);
      4. confirm — ``confirm_removal(issue, marker_sha)`` clears the
         marker; a failed confirm leaves the fence closed (fail-safe: new
         capacity stays blocked) and is reported loudly for reconciliation.

    ``remove`` is the test seam only: when omitted (the production/CLI
    wiring), the built-in binding calls the private raw remover with the
    just-minted proof. Capacity/identity truth is re-derived from ght for
    every read (the reader never sweeps with a construction-time status
    snapshot).
    """
    removed = []
    fenced = []
    alerts = []
    pending_proof: dict = {}

    def fenced_default_remove(path: str) -> None:
        """The only production binding of the raw remover: it consumes the
        single-use proof minted by the authorization step, so the
        destructive call cannot fire without (or before) the fence."""
        proof = pending_proof.pop("removal", None)
        if proof is None:
            raise ValueError(
                "no unspent RemovalAuthorization proof: destructive removal "
                "must follow the fenced authorization (authorize → remove "
                "→ confirm)")
        _remove_worktree(repo_root, path, proof)

    remove_fn = remove if remove is not None else fenced_default_remove
    for entry in iter_worktrees(repo_root):
        authorizing = read_ownership(entry.issue)
        verdict = classify_ownership(authorizing)
        if verdict != RECLAIMABLE:
            fenced.append({"worktree": entry.name, "issue": entry.issue,
                           "verdict": verdict})
            continue
        if entry.issue is None:
            fenced.append({"worktree": entry.name, "issue": None,
                           "verdict": FAIL_CLOSED,
                           "detail": "no canonical per-Issue ownership to "
                                     "reconcile; reconcile via ght"})
            continue
        if authorizing.claim_state != "NONE" and authorizing.fencing_token is None:
            # A present claim record without a readable identity token
            # cannot anchor the atomic authorization — fail closed, never
            # fail-open.
            fenced.append({"worktree": entry.name, "issue": entry.issue,
                           "verdict": FAIL_CLOSED,
                           "detail": "canonical claim record has no readable "
                                     "fencing token to anchor the reclaim "
                                     "authorization"})
            continue
        try:
            marker_sha = authorize_removal(entry.issue, authorizing.fencing_token)
        except ReclaimRefused as refusal:
            fenced.append({"worktree": entry.name, "issue": entry.issue,
                           "verdict": FAIL_CLOSED,
                           "detail": f"reclaim authorization refused: {refusal}"})
            continue
        pending_proof["removal"] = RemovalAuthorization(
            issue=entry.issue, path=entry.path, marker_sha=marker_sha)
        remove_fn(entry.path)
        removed.append(entry.name)
        try:
            confirm_removal(entry.issue, marker_sha)
        except ReclaimRefused as refusal:
            alerts.append({"worktree": entry.name, "issue": entry.issue,
                           "detail": f"reclaim confirm failed ({refusal}); the "
                                     "removal fence stays closed — reconcile "
                                     "via ght"})
    return {"removed": removed, "fenced": fenced,
            "post_removal_alerts": alerts}


@dataclass(frozen=True)
class RemovalAuthorization:
    """Single-use proof that the fenced sequence authorized one removal.

    Minted only inside :func:`execute_cleanup`, immediately after the
    atomic ``ght reclaim-execution-resource`` authorization succeeded, and
    consumed by the raw remover on the destructive call it covers. It is
    bound to the one path the authorization anchored, so the canonical raw
    remover cannot silently serve as a second entrypoint: a bare
    ``(repo_root, path)`` call is impossible by construction, and any
    reference to the remover outside this module fails the #154 conformance
    scan."""

    issue: Optional[int]
    path: str
    marker_sha: str


def _remove_worktree(repo_root: Path, path: str,
                     removal: RemovalAuthorization) -> None:
    """Destructive removal through git's own worktree bookkeeping.

    Charter-scoped (#154 anti-bypass): this remover exists only for the
    fenced sequence in :func:`execute_cleanup` and is reachable only with
    the single-use :class:`RemovalAuthorization` proof that sequence minted
    right after the atomic ght authorization — a bare path call raises, so
    the canonical helper cannot double as a general-purpose destroyer or
    as an importable second entrypoint around the fence. It only ever
    removes a path strictly inside the repo's ``.worktree/``; any other
    path raises."""
    if not isinstance(removal, RemovalAuthorization):
        raise ValueError(
            "raw worktree removal requires the single-use "
            "RemovalAuthorization proof minted by execute_cleanup after a "
            "successful ght reclaim-execution-resource authorization; a "
            "bare path call is a forbidden bypass (#154)")
    if not removal.marker_sha:
        raise ValueError(
            "removal authorization proof carries no marker identity; the "
            "fenced authorization must succeed first")
    if Path(removal.path) != Path(path):
        raise ValueError(
            f"removal authorization proof covers {str(removal.path)!r}, "
            f"not {str(path)!r}: one authorization fences exactly one path")
    root = Path(repo_root).resolve()
    target = Path(path).resolve()
    worktree_root = root / ".worktree"
    if worktree_root not in target.parents:
        raise ValueError(
            f"worktree removal refuses non-.worktree path {str(target)!r}: "
            "Issue-worktree removal is fenced through execute_cleanup only")
    subprocess.run(
        ["git", "-C", str(repo_root), "worktree", "remove", "--force", str(path)],
        check=True, capture_output=True)


def _default_runner(cmd: list[str]) -> tuple[int, str]:
    result = subprocess.run(cmd, capture_output=True, text=True)
    return result.returncode, (result.stdout or "") + (result.stderr or "")


def _ght_command(ght_cmd: Optional[str]) -> list[str]:
    """Resolve the ght entrypoint the cleanup runtime invokes.

    Precedence: an explicit ``--ght`` path (the test/host seam) wins;
    otherwise the canonical ``ght.py`` packaged beside this helper inside
    the installed github-task Skill — resolution anchors on this file's
    own installed location, never on the target repository (#155): a
    downstream business repo carries no Skill copy. An unresolvable ght
    is not worked around; the invocation simply fails and every ownership
    read fails closed.
    """
    path = ght_cmd or str(Path(__file__).resolve().parent / "ght.py")
    return [sys.executable, path] if path.endswith(".py") else [path]


class GhtOwnershipReader:
    """Composes per-Issue ownership facts from canonical ght surfaces.

    ``ght inspect <issue>`` supplies the executor-neutral durable claim
    lineage (presence, canonical claim_state, Candidate delivery, owning
    identity, claim-record fencing token); one fresh ``ght status`` read is
    issued for every ``read`` and supplies this coordination identity's
    canonical execution-capacity classification — capacity truth is never
    a snapshot reused across reads, so each destructive-boundary read sees
    current facts (AC3). Any command failure or unparseable payload
    degrades to unreadable/ambiguous facts — the fence then fails closed;
    an unreadable status read in particular never implies absent capacity.
    No PID, process, or directory age is ever consulted.
    """

    def __init__(self, runner: Callable[[list[str]], tuple[int, str]],
                 identity_executor_id: Optional[str] = None):
        self._runner = runner
        self._identity_executor_id = identity_executor_id

    @classmethod
    def from_cli(cls, ght_cmd: Optional[str] = None) -> "GhtOwnershipReader":
        prefix = _ght_command(ght_cmd)
        runner = lambda cmd: _default_runner(prefix + cmd)  # noqa: E731
        rc, out = runner(["status"])
        identity = None
        if rc == 0:
            try:
                payload = json.loads(out)
            except json.JSONDecodeError:
                payload = None
            if isinstance(payload, dict):
                identity = payload.get("executor_id")
        return cls(runner=runner, identity_executor_id=identity)

    def _read_status(self) -> Optional[dict]:
        """One fresh canonical status read. Unreadable truth returns None —
        the caller fails the whole composite read closed rather than
        letting a stale snapshot stand in for capacity facts."""
        rc, out = self._runner(["status"])
        if rc != 0:
            return None
        try:
            payload = json.loads(out)
        except json.JSONDecodeError:
            return None
        return payload if isinstance(payload, dict) else None

    def read(self, issue: Optional[int]) -> IssueOwnership:
        if issue is None:
            return IssueOwnership(issue=None, readability="unreadable")
        status_payload = self._read_status()
        if status_payload is None:
            # Capacity/identity truth unreadable at this moment: the
            # composite ownership facts are unreadable — fail closed.
            return IssueOwnership(issue=issue, readability="unreadable")
        rc, out = self._runner(["inspect", str(issue)])
        if rc != 0:
            readability = "ambiguous" if "AMBIGUOUS" in out else "unreadable"
            return IssueOwnership(issue=issue, readability=readability)
        try:
            payload = json.loads(out)
        except json.JSONDecodeError:
            return IssueOwnership(issue=issue, readability="unreadable")
        claim = payload.get("claim")
        claim_state = payload.get("claim_state")
        claim_state = claim_state if isinstance(claim_state, str) else None
        executor_id = claim.get("executor_id") if isinstance(claim, dict) else None
        candidate = claim.get("candidate") if isinstance(claim, dict) else None
        capacity_live = any(
            entry.get("issue") == issue
            and entry.get("attempt_state") == "ACTIVE"
            and isinstance(entry.get("execution_capacity"), dict)
            and entry["execution_capacity"].get("state") == "live"
            for entry in status_payload.get("active_claims", []))
        fencing_token = payload.get("claim_sha")
        if not isinstance(fencing_token, str):
            fencing_token = None
        return IssueOwnership(issue=issue, readability="readable",
                              claim_state=claim_state,
                              executor_id=executor_id, candidate=candidate,
                              capacity_live=capacity_live,
                              identity_executor_id=self._identity_executor_id,
                              fencing_token=fencing_token)


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        prog="worktree_cleanup",
        description="Fenced cleanup of Issue-executor worktrees: reconcile "
                    "canonical ght ownership at the destructive boundary "
                    "(#147). Dry-run is the default.")
    parser.add_argument("--repo-root", default=".",
                        help="repository whose .worktree/ is cleaned")
    parser.add_argument("--ght", default=None,
                        help="ght CLI path (default: the canonical ght.py "
                             "packaged beside this helper in the installed "
                             "github-task Skill; the target repository is "
                             "never consulted)")
    parser.add_argument("--execute", action="store_true",
                        help="perform destructive removal after per-worktree "
                             "boundary revalidation (default: dry-run)")
    args = parser.parse_args(argv)
    repo_root = Path(args.repo_root).resolve()
    reader = GhtOwnershipReader.from_cli(args.ght)
    if args.execute:
        reclaim = GhtReclaimCaller.from_cli(args.ght)
        # No remove injection: the CLI uses the built-in proof-carrying
        # binding, so the raw remover is reachable only inside the fence.
        report = execute_cleanup(repo_root, reader.read,
                                 authorize_removal=reclaim.authorize,
                                 confirm_removal=reclaim.confirm)
        report["mode"] = "execute"
    else:
        plan = plan_cleanup(repo_root, reader.read)
        report = {"mode": "dry-run",
                  "plan": [{"worktree": item.name, "issue": item.issue,
                            "verdict": item.verdict} for item in plan],
                  "removed": [],
                  "fenced": [{"worktree": item.name, "issue": item.issue,
                              "verdict": item.verdict}
                             for item in plan if item.verdict != RECLAIMABLE],
                  "post_removal_alerts": []}
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
