"""Contract-drift fencing recovery regressions (the #166 incident class).

An Issue Task Contract changed DURING an active attempt: the claim's
recorded ``contract_digest`` no longer equals the current canonical Issue
Contract digest, so every continuation (acquire/preserve/deliver) fails
closed — while `ght discover` still classified the stale attempt as a
plain "resume" and `ght release` had NO legal exit. Net effect: a
permanently stuck lineage with no termination path.

The recovery contract pinned here (User-authorized minimal fix):

- Digest mismatch keeps failing closed for all execution-under-old-
  authority: acquire/preserve/deliver under the drifted claim stay
  blocked (T5).
- `ght discover` recognizes the drift: an own non-terminal attempt whose
  digest drifted is a distinct non-runnable ``blocked`` classification
  naming the canonical exit — never a plain "resume" (T1), and never
  folded into a ``no_work`` answer — while non-drifted attempts keep
  their ordinary resume/recovery verdicts (T2).
- `ght release --status blocked|investigated` is the ONE authority-
  bounded termination path for the drifted stale attempt: it records the
  disposition + note and ends the old authority (T3) — and grants none:
  a fresh claim still requires a fresh one-shot authorization and binds
  the CURRENT Contract digest (T4).
"""

import json
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[1]))

from github_task import cli
from . import test_cli_safety as safety_tests
from .test_cli_safety import IMPL_CONTRACT, issue_body

# A materially changed (but still parseable, still implementation-allowed)
# Issue Contract: any content change moves the canonical digest.
DRIFTED_CONTRACT = IMPL_CONTRACT.replace(
    "The CLI runs.", "The CLI runs and reports its version.")

STALE_LEASE = "2000-01-01T00:00:00Z"


class ContractDriftFencingTests(unittest.TestCase):
    """Reuses the hermetic local-remote CLI fixture of the safety suite."""

    setUp = safety_tests.CliSafetyTests.setUp
    tearDown = safety_tests.CliSafetyTests.tearDown
    _write_executable = safety_tests.CliSafetyTests._write_executable
    _git = safety_tests.CliSafetyTests._git
    _activate_default_runtime_pin = safety_tests.CliSafetyTests._activate_default_runtime_pin
    _ght = safety_tests.CliSafetyTests._ght
    _ght_json = safety_tests.CliSafetyTests._ght_json
    _issue = safety_tests.CliSafetyTests._issue
    _update_issue = safety_tests.CliSafetyTests._update_issue
    _claim = safety_tests.CliSafetyTests._claim
    _checkout_claim_branch = safety_tests.CliSafetyTests._checkout_claim_branch
    _commit_on_branch = safety_tests.CliSafetyTests._commit_on_branch
    _open_pr = safety_tests.CliSafetyTests._open_pr
    _fabricate_resumable_attempt = safety_tests.CliSafetyTests._fabricate_resumable_attempt
    _expire_attempt_lease = safety_tests.CliSafetyTests._expire_attempt_lease
    _rewrite_claim_record = safety_tests.CliSafetyTests._rewrite_claim_record
    _read_lease_record = safety_tests.CliSafetyTests._read_lease_record
    _rewrite_lease_ref = safety_tests.CliSafetyTests._rewrite_lease_ref
    _expire_execution_lease = safety_tests.CliSafetyTests._expire_execution_lease
    _delivered_parked = safety_tests.CliSafetyTests._delivered_parked

    LEASE_REF_FMT = safety_tests.CliSafetyTests.LEASE_REF_FMT

    # -- fixture helpers --------------------------------------------------

    def _read_claim_record(self, number):
        """Remote durable truth of the claim ref (test-only read)."""
        temp_ref = f"refs/ght-read/drift-read-{number}"
        fetched = self._git(self.repo, "fetch", "-q", "origin",
                            f"+refs/ght/claims/{number}:{temp_ref}")
        self.assertEqual(fetched.returncode, 0, fetched.stderr)
        try:
            result = self._git(self.repo, "show", f"{temp_ref}:CLAIM.json")
            self.assertEqual(result.returncode, 0, result.stderr)
            return json.loads(result.stdout)
        finally:
            self._git(self.repo, "update-ref", "-d", temp_ref)

    def _clear_ready_except(self, keep=()):
        for number in (10, 11, 12, 13, 14, 15):
            if number not in keep:
                self._update_issue(number, labels=[])

    def _drift_contract(self, number=10):
        """A changes the Issue Contract AFTER the attempt started (AC5)."""
        self._update_issue(number, body=issue_body(DRIFTED_CONTRACT))

    def _stale_drifted_attempt(self, state_dir=None):
        """The deadlocked shape: an owned attempt whose lease expired while
        its Contract drifted — fenced for acquire, unresumable, and (before
        the fix) un-releasable."""
        env = {"GHT_STATE_DIR": state_dir} if state_dir else None
        claim = self._claim(10, env_extra=env)
        self._rewrite_claim_record(10, lease_expires_at=STALE_LEASE)
        lease = self._read_lease_record(claim["claim_id"])
        lease["lease_expires_at"] = STALE_LEASE
        self._rewrite_lease_ref(claim["claim_id"], lease)
        self._drift_contract(10)
        return claim

    def _assert_drift_item(self, entry, claim_id):
        """The exact discover verdict shape for one drifted attempt."""
        self.assertEqual(entry["kind"], "blocked")
        self.assertEqual(entry["source"], "resume")
        self.assertFalse(entry["runnable"],
                         "a drifted attempt is never an actionable resume")
        self.assertEqual(entry["claim_id"], claim_id)
        self.assertIn("Task Contract changed during the active attempt",
                      entry["reason"])
        self.assertIn("fenced", entry["reason"])
        self.assertIn("ght release", entry["reason"])
        self.assertIn("re-authorization", entry["reason"])

    # -- T1: discover classifies the drift, never a plain resume ----------

    def test_discover_drifted_stale_correction_is_blocked_not_resume(self):
        # The literal #166 shape: a delivered attempt with an authoritative
        # exact-SHA REQUEST_CHANGES whose Contract drifted while the attempt
        # was active. Discovery must NOT offer `ght acquire` continuation.
        self._fabricate_resumable_attempt(10, 60)
        self._expire_attempt_lease(10)
        self._clear_ready_except(keep=(14,))
        self._drift_contract(10)

        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertNotEqual(payload.get("action"), "no_work",
                            "a drifted attempt is never a no-work answer")
        self.assertNotEqual(payload.get("action"), "resume")
        self.assertEqual(payload["action"], "handoff")
        entry = next(w for w in payload["work"] if w["issue"] == 10)
        self._assert_drift_item(entry, entry["claim_id"])
        self.assertTrue(all(not (w["issue"] == 10 and w.get("kind") == "resume")
                            for w in payload["work"]),
                        "no plain resume item may remain for the drifted attempt")
        # work-conserving: unrelated ready work stays visible after it.
        self.assertTrue(any(w["issue"] == 14 and w["runnable"]
                            for w in payload["work"]))

    def test_discover_drifted_stale_recovery_is_blocked_not_resume(self):
        # The expired-residue shape: an owned ACTIVE attempt with no live
        # execution capacity whose Contract drifted. Today this compiles the
        # plain "resume the same attempt with `ght acquire`" verdict — the
        # acquire that can never succeed.
        claim = self._stale_drifted_attempt(state_dir="state-drift-recovery")
        self._clear_ready_except()

        result, payload = self._ght_json(
            "discover", env_extra={"GHT_STATE_DIR": "state-drift-recovery",
                                   "GHT_TAKEOVER_GRACE_MINUTES": "0"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertNotEqual(payload.get("action"), "resume",
                            "a drifted attempt is never a plain resume verdict")
        self.assertNotEqual(payload.get("action"), "no_work")
        self.assertEqual(payload["action"], "handoff")
        self.assertEqual(len(payload["work"]), 1)
        self._assert_drift_item(payload["work"][0], claim["claim_id"])
        self.assertNotIn("resume the same attempt", payload["work"][0]["reason"],
                         "the plain acquire-recovery reason must be gone")

    def test_discover_drifted_parked_review_wait_is_blocked(self):
        # A drifted parked Candidate awaiting review is also fenced: even A's
        # acceptance could never complete under the stale authority. The
        # drift classification supersedes the awaiting-review wait.
        self._delivered_parked(10, 76)
        self._clear_ready_except()
        self._drift_contract(10)

        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertNotEqual(payload.get("action"), "no_work")
        self.assertEqual(payload["action"], "handoff")
        self.assertNotIn("awaiting_review", payload)
        self._assert_drift_item(payload["work"][0], payload["work"][0]["claim_id"])

    # -- T2: non-drifted own attempts keep their ordinary verdicts --------

    def test_discover_non_drifted_correction_still_resumes(self):
        self._fabricate_resumable_attempt(10, 60)
        self._expire_attempt_lease(10)
        self._clear_ready_except(keep=(14,))

        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "handoff")
        entry = next(w for w in payload["work"] if w["issue"] == 10)
        self.assertEqual(entry["kind"], "resume")
        self.assertEqual(entry["source"], "resume")
        self.assertTrue(entry["runnable"])
        self.assertIn("resume with `ght acquire`", entry["reason"])

    def test_discover_non_drifted_recovery_still_offers_acquire(self):
        claim = self._claim(10, env_extra={"GHT_STATE_DIR": "state-drift-clean"})
        self._clear_ready_except()
        self._rewrite_claim_record(10, lease_expires_at=STALE_LEASE)
        lease = self._read_lease_record(claim["claim_id"])
        lease["lease_expires_at"] = STALE_LEASE
        self._rewrite_lease_ref(claim["claim_id"], lease)

        result, payload = self._ght_json(
            "discover", env_extra={"GHT_STATE_DIR": "state-drift-clean",
                                   "GHT_TAKEOVER_GRACE_MINUTES": "0"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "resume")
        self.assertEqual(payload["issue"], 10)
        self.assertEqual(payload["claim_id"], claim["claim_id"])
        self.assertEqual(payload["recovery"], "execution_lease")

    # -- T3: release is the authority-bounded termination path ------------

    def test_release_blocked_terminates_drifted_stale_attempt(self):
        # The deadlock unlock: `ght release --status blocked` succeeds when
        # the ONLY blocking condition is the digest drift, and the terminal
        # disposition + note land as durable remote truth.
        claim = self._stale_drifted_attempt()
        note = "contract drifted mid-attempt; terminating the fenced attempt"

        # The blocked disposition still requires the recorded decision —
        # under drift the command reaches the note gate, not a blank refusal.
        result = self._ght("release", "10", "--status", "blocked")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("note", result.stdout.lower())

        result, payload = self._ght_json("release", "10", "--status", "blocked",
                                         "--note", note)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["status"], "blocked")
        self.assertEqual(payload["claim_id"], claim["claim_id"])

        record = self._read_claim_record(10)
        self.assertEqual(record["status"], "blocked")
        self.assertEqual(record["note"], note)
        self.assertEqual(record["claim_id"], claim["claim_id"])
        # The stale attempt's capacity residue is cleaned with the lineage.
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      self.LEASE_REF_FMT % claim["claim_id"]).stdout.strip(),
            "",
            "the terminal attempt holds no execution capacity")

    def test_release_blocked_terminates_drifted_parked_attempt(self):
        # The parked variant of the same deadlock (delivery durable, no live
        # lease): release stays the one legal exit under drift.
        claim, _sha = self._delivered_parked(10, 60)
        self._drift_contract(10)

        result, payload = self._ght_json("release", "10", "--status", "blocked",
                                         "--note", "drift; stop and replan")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["claim_id"], claim["claim_id"])
        record = self._read_claim_record(10)
        self.assertEqual(record["status"], "blocked")
        self.assertEqual(record["note"], "drift; stop and replan")

    def test_release_investigated_terminates_drifted_stale_attempt(self):
        # `investigated` is the same disposition family: the drift exit
        # applies identically.
        claim = self._stale_drifted_attempt()

        result, payload = self._ght_json("release", "10", "--status",
                                         "investigated",
                                         "--note", "investigated under drift")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["status"], "investigated")
        record = self._read_claim_record(10)
        self.assertEqual(record["status"], "investigated")
        self.assertEqual(record["claim_id"], claim["claim_id"])

    def test_release_refuses_drifted_attempt_of_foreign_identity(self):
        # The termination path is authority-bounded: another executor can
        # never release someone else's drifted attempt.
        self._stale_drifted_attempt()

        result = self._ght("release", "10", "--status", "blocked",
                           "--note", "not mine",
                           env_extra={"GHT_EXECUTOR_ID": "worker-2"})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        record = self._read_claim_record(10)
        self.assertEqual(record["status"], "active",
                         "a foreign release must never mutate the lineage")

    # -- T4: termination grants no authority ------------------------------

    def test_fresh_claim_after_drift_release_requires_fresh_ready(self):
        self._stale_drifted_attempt()
        result, payload = self._ght_json("release", "10", "--status", "blocked",
                                         "--note", "terminated under drift")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["status"], "blocked")

        # The released attempt consumed its one-shot authorization; nothing
        # about the release re-arms it.
        self.assertEqual(self._issue(10)["labels"], [])
        result = self._ght("claim", "10")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        record = self._read_claim_record(10)
        self.assertEqual(record["status"], "blocked",
                         "no new claim may appear without fresh authorization")

        # A FRESH one-shot authorization starts a NEW attempt bound to the
        # CURRENT canonical Contract digest — the normal claim machinery,
        # untouched by the termination path.
        self._update_issue(10, labels=["ready"])
        result, payload = self._ght_json("claim", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertNotEqual(payload["claim_id"], record["claim_id"])
        canonical = self._ght_json("contract-digest", "10")[1]["contract_digest"]
        new_record = self._read_claim_record(10)
        self.assertEqual(new_record["claim_id"], payload["claim_id"])
        self.assertEqual(new_record["contract_digest"], canonical,
                         "the fresh claim binds the CURRENT Contract digest")
        self.assertEqual(new_record["status"], "active")

    # -- T5: everything else under drift stays fail-closed ----------------

    def test_drifted_attempt_execution_surfaces_stay_fail_closed(self):
        claim = self._claim(10)
        self._checkout_claim_branch(claim)
        self._commit_on_branch("skills/demo.txt", "demo\n")
        self._drift_contract(10)

        for args in (("acquire", "10"), ("preserve", "10"),
                     ("deliver", "10", "--pr", "60")):
            result = self._ght(*args)
            self.assertNotEqual(result.returncode, 0,
                                f"{args[0]} must stay fail-closed under drift: "
                                f"{result.stdout} {result.stderr}")
            self.assertIn("Issue Contract changed during the active claim",
                          result.stdout + result.stderr)

        record = self._read_claim_record(10)
        self.assertEqual(record["status"], "active")
        self.assertIsNone(record.get("candidate"),
                          "no Candidate may be recorded under the stale authority")

    def test_drifted_stale_attempt_acquire_stays_fail_closed(self):
        # Even past the stale-holder grace, acquire is fenced by the digest —
        # the grace governs capacity, never stale Contract authority.
        self._stale_drifted_attempt()

        result = self._ght("acquire", "10",
                           env_extra={"GHT_TAKEOVER_GRACE_MINUTES": "0"})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("Issue Contract changed during the active claim",
                      result.stdout + result.stderr)


if __name__ == "__main__":
    unittest.main()
