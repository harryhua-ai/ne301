"""Cleanup fencing regression for #147: host-side/best-effort worktree
cleanup must never delete the execution resource of the current canonical
ACTIVE execution capacity — in flight or in the claim-established-but-
pre-dispatch window — while genuine orphans and parked/terminal worktrees
stay reclaimable under #97 bounded lifetime. Ownership eligibility is
reconciled against canonical ght truth at the destructive boundary
(TOCTOU-safe); ambiguity fails closed; no second registry/GC exists.
"""

import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

# #155: the canonical cleanup implementation is package-owned — it lives
# inside the github-task Skill package, not at the repository root.
HELPER_PATH = Path(__file__).parents[1] / "scripts" / "worktree_cleanup.py"
SKILL_MD = Path(__file__).parents[1] / "SKILL.md"


def _load_helper():
    spec = importlib.util.spec_from_file_location("worktree_cleanup", HELPER_PATH)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def _ownership(module, issue=555, readability="readable", claim_state="NONE",
               executor_id="harryhua-ai", candidate=None, capacity_live=False,
               identity_executor_id="harryhua-ai", fencing_token=None):
    return module.IssueOwnership(
        issue=issue, readability=readability, claim_state=claim_state,
        executor_id=executor_id, candidate=candidate,
        capacity_live=capacity_live, identity_executor_id=identity_executor_id,
        fencing_token=fencing_token)


class CleanupFenceDecisionTests(unittest.TestCase):
    """AC1/AC2: the pure eligibility decision over canonical ownership."""

    def test_active_running_attempt_worktree_is_protected(self):
        # AC1(a): admitted ACTIVE attempt with a live execution capacity —
        # the executor is using the worktree — must never be cleanup-eligible.
        module = _load_helper()
        own = _ownership(module, claim_state="ACTIVE", capacity_live=True)
        self.assertEqual(module.classify_ownership(own), module.PROTECTED)

    def test_claimed_pre_dispatch_worktree_is_protected(self):
        # AC1(b): claim established, worktree created, executor not yet
        # dispatched — no durable Candidate, no live capacity record —
        # must still never be cleanup-eligible.
        module = _load_helper()
        own = _ownership(module, claim_state="ACTIVE", capacity_live=False,
                         candidate=None)
        self.assertEqual(module.classify_ownership(own), module.PROTECTED)

    def test_stale_claim_residue_is_protected_until_canonical_reconciliation(self):
        # Non-terminal stale lineage is recovery-window residue: reclaiming
        # its worktree happens only after canonical reconciliation
        # (acquire/takeover/release), never off a local age/PID guess.
        module = _load_helper()
        own = _ownership(module, claim_state="STALE")
        self.assertEqual(module.classify_ownership(own), module.PROTECTED)

    def test_unreadable_ownership_fails_closed_not_orphaned(self):
        # AC2: unreadable canonical truth is never treated as orphan.
        module = _load_helper()
        own = _ownership(module, readability="unreadable")
        self.assertEqual(module.classify_ownership(own), module.FAIL_CLOSED)

    def test_ambiguous_ownership_fails_closed_not_orphaned(self):
        # AC2: ambiguous/contradictory ownership fails closed.
        module = _load_helper()
        own = _ownership(module, readability="ambiguous")
        self.assertEqual(module.classify_ownership(own), module.FAIL_CLOSED)

    def test_unknown_claim_state_fails_closed(self):
        # AC2: a claim_state value outside the canonical classification
        # is contradictory truth and fails closed.
        module = _load_helper()
        own = _ownership(module, claim_state="SOMETHING_ELSE")
        self.assertEqual(module.classify_ownership(own), module.FAIL_CLOSED)

    def test_cross_identity_nonterminal_claim_fails_closed(self):
        # AC2: a non-terminal claim owned by a different executor identity
        # is not this cleanup's to judge — fail closed, never orphan.
        module = _load_helper()
        own = _ownership(module, claim_state="ACTIVE",
                         executor_id="other-identity",
                         identity_executor_id="harryhua-ai")
        self.assertEqual(module.classify_ownership(own), module.FAIL_CLOSED)


class BoundedLifetimePreservedTests(unittest.TestCase):
    """AC4: #97 bounded-lifetime reclaimables stay reclaimable."""

    def test_true_orphan_worktree_is_reclaimable(self):
        # Authoritative absence of a claim (readable NONE) is a true orphan.
        module = _load_helper()
        own = _ownership(module, claim_state="NONE")
        self.assertEqual(module.classify_ownership(own), module.RECLAIMABLE)

    def test_terminal_attempt_worktree_is_reclaimable(self):
        module = _load_helper()
        own = _ownership(module, claim_state="TERMINAL")
        self.assertEqual(module.classify_ownership(own), module.RECLAIMABLE)

    def test_delivered_review_wait_worktree_is_reclaimable_without_live_capacity(self):
        # Parked per canonical predicate: durable Candidate delivered and
        # no live execution capacity — the A-review wait keeps no worktree.
        module = _load_helper()
        own = _ownership(module, claim_state="ACTIVE",
                         candidate="abc123def456", capacity_live=False)
        self.assertEqual(module.classify_ownership(own), module.RECLAIMABLE)

    def test_parked_is_protected_while_capacity_still_live(self):
        # A delivery-present window with a live lease is not parked
        # (canonical predicate) — conservative fence keeps it protected.
        module = _load_helper()
        own = _ownership(module, claim_state="ACTIVE",
                         candidate="abc123def456", capacity_live=True)
        self.assertEqual(module.classify_ownership(own), module.PROTECTED)


class TocTouBoundaryTests(unittest.TestCase):
    """AC3: stale discovery snapshots never authorize destructive removal."""

    def test_stale_snapshot_does_not_delete_worktree_that_became_active(self):
        # Discovery classified the worktree reclaimable from a stale
        # snapshot; before the destructive boundary the Issue transitioned
        # to a canonical ACTIVE attempt. The boundary revalidation must
        # fence the deletion.
        module = _load_helper()
        facts = {"state": "orphan"}
        provider_state = {"orphan": _ownership(module, claim_state="NONE"),
                          "active": _ownership(module, claim_state="ACTIVE",
                                               capacity_live=True)}

        def read_ownership(issue):
            return provider_state[facts["state"]]

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / ".worktree" / "555").mkdir(parents=True)
            plan = module.plan_cleanup(root, read_ownership)
            self.assertEqual([item.verdict for item in plan],
                             [module.RECLAIMABLE])
            # Ownership transfers after the stale snapshot was taken.
            facts["state"] = "active"
            report = module.execute_cleanup(root, read_ownership,
                                            remove=lambda path: None,
                                            authorize_removal=lambda issue, token: "m",
                                            confirm_removal=lambda issue, marker: None)
        self.assertEqual(report["removed"], [])
        self.assertEqual(len(report["fenced"]), 1)
        self.assertEqual(report["fenced"][0]["verdict"], module.PROTECTED)

    def test_execute_ignores_stale_plan_and_rereads_at_boundary(self):
        # The destructive path derives its verdict only from fresh
        # boundary reads; it must not consume plan-snapshot verdicts.
        module = _load_helper()
        calls = {"reads": 0}

        def read_ownership(issue):
            calls["reads"] += 1
            return _ownership(module, claim_state="NONE")

        removed = []
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / ".worktree" / "555").mkdir(parents=True)
            module.execute_cleanup(root, read_ownership,
                                   remove=lambda path: removed.append(path),
                                   authorize_removal=lambda issue, token: "m",
                                   confirm_removal=lambda issue, marker: None)
        self.assertGreaterEqual(calls["reads"], 1)
        self.assertEqual(len(removed), 1)


class ReclaimAuthorizationFencingTests(unittest.TestCase):
    """AC3 (R2): destructive removal is conditional on an atomic ght-side
    reclaim authorization on the Issue's claim ref — the same CAS domain
    every capacity-establishing transition must win. Between authorization
    and the destructive call no ACTIVE transition can become valid (the
    pending-reclaim marker holds the domain); a refused authorization
    (ownership moved since the eligibility read, not reclaimable, truth
    unreadable) fences the worktree fail-closed — never a removal."""

    def test_refused_authorization_prevents_removal_of_worktree_that_became_active(self):
        # The required review regression: the eligibility read classified a
        # true orphan; by authorization time a new claim became the current
        # ACTIVE execution resource. ght refuses the authorization (the
        # caller's claim_sha anchor no longer matches the ref head) and the
        # active worktree survives.
        module = _load_helper()

        def read_ownership(issue):
            return _ownership(module, claim_state="NONE", fencing_token=None)

        def authorize(issue, token):
            raise module.ReclaimRefused(
                "canonical ownership moved since the authorizing eligibility read")

        removed = []
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            wt = root / ".worktree" / "555"
            wt.mkdir(parents=True)
            (wt / "executor-state.txt").write_text("running\n")
            report = module.execute_cleanup(
                root, read_ownership, remove=lambda path: removed.append(path),
                authorize_removal=authorize,
                confirm_removal=lambda issue, marker: None)
            self.assertTrue(wt.exists(), "active worktree must survive")
            self.assertTrue((wt / "executor-state.txt").exists())
        self.assertEqual(removed, [])
        self.assertEqual(report["removed"], [])
        self.assertEqual(len(report["fenced"]), 1)
        self.assertEqual(report["fenced"][0]["verdict"], module.FAIL_CLOSED)
        self.assertIn("reclaim authorization refused",
                      report["fenced"][0]["detail"])

    def test_authorized_removal_removes_and_confirms_with_marker_anchor(self):
        # AC4 guard: the fence refuses transitions, not stable reclaimables
        # — a successful authorization removes, and the confirm consumes
        # exactly the marker anchor the authorization minted.
        module = _load_helper()
        seen = {"authorize": None, "confirm": None}

        def read_ownership(issue):
            return _ownership(module, claim_state="NONE", fencing_token=None)

        def confirm(issue, marker_sha):
            seen["confirm"] = (issue, marker_sha)

        removed = []
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            wt = root / ".worktree" / "555"
            wt.mkdir(parents=True)
            report = module.execute_cleanup(
                root, read_ownership, remove=lambda path: removed.append(path),
                authorize_removal=lambda issue, token: seen.__setitem__(
                    "authorize", (issue, token)) or "marker-sha-1",
                confirm_removal=confirm)
        self.assertEqual(report["removed"], ["555"])
        self.assertEqual(removed, [str(wt)])
        self.assertEqual(seen["authorize"], (555, None))
        self.assertEqual(seen["confirm"], (555, "marker-sha-1"))
        self.assertEqual(report["post_removal_alerts"], [])

    def test_authorization_receives_the_eligibility_fencing_token(self):
        # The authorization is anchored on the canonical claim-record
        # identity from the eligibility read (`ght inspect`'s claim_sha).
        module = _load_helper()
        seen = {"token": "unset"}

        def read_ownership(issue):
            return _ownership(module, claim_state="TERMINAL",
                              fencing_token="d" * 40)

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / ".worktree" / "555").mkdir(parents=True)
            module.execute_cleanup(
                root, read_ownership, remove=lambda path: None,
                authorize_removal=lambda issue, token:
                    seen.__setitem__("token", token) or "m",
                confirm_removal=lambda issue, marker: None)
        self.assertEqual(seen["token"], "d" * 40)

    def test_confirm_failure_is_loud_and_keeps_the_fence_closed(self):
        # A failed confirm is fail-safe (the marker keeps blocking new
        # capacity) and must never read as a silent success: it is reported
        # loudly for reconciliation via ght.
        module = _load_helper()

        def read_ownership(issue):
            return _ownership(module, claim_state="NONE", fencing_token=None)

        def confirm(issue, marker_sha):
            raise module.ReclaimRefused("confirm anchor mismatch")

        removed = []
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / ".worktree" / "555").mkdir(parents=True)
            report = module.execute_cleanup(
                root, read_ownership, remove=lambda path: removed.append(path),
                authorize_removal=lambda issue, token: "marker-sha-2",
                confirm_removal=confirm)
        self.assertEqual(report["removed"], ["555"])
        self.assertEqual(removed, [str(root / ".worktree" / "555")])
        self.assertEqual(len(report["post_removal_alerts"]), 1)
        self.assertIn("fence stays closed", report["post_removal_alerts"][0]["detail"])

    def test_unreadable_eligibility_truth_is_fenced_without_authorization(self):
        # AC2: unreadable canonical truth at the eligibility read fails
        # closed before any authorization is attempted.
        module = _load_helper()
        calls = {"authorize": 0}

        def read_ownership(issue):
            return _ownership(module, readability="unreadable")

        removed = []
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            wt = root / ".worktree" / "555"
            wt.mkdir(parents=True)
            report = module.execute_cleanup(
                root, read_ownership, remove=lambda path: removed.append(path),
                authorize_removal=lambda issue, token:
                    calls.__setitem__("authorize", calls["authorize"] + 1) or "m",
                confirm_removal=lambda issue, marker: None)
            self.assertTrue(wt.exists())
        self.assertEqual(removed, [])
        self.assertEqual(calls["authorize"], 0)
        self.assertEqual(report["fenced"][0]["verdict"], module.FAIL_CLOSED)

    def test_claim_record_without_fencing_token_fails_closed(self):
        # A present (terminal) claim record without a readable identity
        # token cannot anchor the atomic authorization — fail closed
        # instead of removing on an unfenceable decision (never fail-open).
        module = _load_helper()

        def read_ownership(issue):
            return _ownership(module, claim_state="TERMINAL",
                              fencing_token=None)

        removed = []
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            wt = root / ".worktree" / "555"
            wt.mkdir(parents=True)
            report = module.execute_cleanup(
                root, read_ownership, remove=lambda path: removed.append(path),
                authorize_removal=lambda issue, token: "m",
                confirm_removal=lambda issue, marker: None)
            self.assertTrue(wt.exists())
        self.assertEqual(removed, [])
        self.assertEqual(report["fenced"][0]["verdict"], module.FAIL_CLOSED)


class CapacityFreshnessTests(unittest.TestCase):
    """AC3 review delta: execution-capacity truth is re-derived from ght for
    every read — the destructive boundary never consumes a `ght status`
    snapshot taken once at reader construction, and unreadable status truth
    at read time fails closed instead of standing in stale capacity facts."""

    def test_capacity_live_is_rederived_per_read_not_snapshotted(self):
        module = _load_helper()
        live = {"executor_id": "harryhua-ai",
                "active_claims": [{"issue": 555, "attempt_state": "ACTIVE",
                                   "execution_capacity": {"state": "live"}}]}
        absent = {"executor_id": "harryhua-ai", "active_claims": []}
        payloads = [live, absent]
        status_calls = {"n": 0}
        inspect_payload = {
            "issue": 555,
            "claim": {"status": "active", "executor_id": "harryhua-ai",
                      "candidate": "abc123def456", "branch": "agent/555/y"},
            "claim_state": "ACTIVE", "claim_sha": "f" * 40}

        def runner(cmd):
            if cmd and cmd[0] == "status":
                payload = payloads[min(status_calls["n"], len(payloads) - 1)]
                status_calls["n"] += 1
                return 0, json.dumps(payload)
            return 0, json.dumps(inspect_payload)

        reader = module.GhtOwnershipReader(runner=runner,
                                           identity_executor_id="harryhua-ai")
        first = reader.read(555)
        second = reader.read(555)
        self.assertGreaterEqual(status_calls["n"], 2)
        self.assertTrue(first.capacity_live)
        self.assertFalse(second.capacity_live)
        # Same inspect identity, but the fence decision tracks the fresh
        # capacity per read: live is protected, absent is parked-reclaimable.
        self.assertEqual(module.classify_ownership(first), module.PROTECTED)
        self.assertEqual(module.classify_ownership(second), module.RECLAIMABLE)

    def test_status_failure_at_read_fails_closed(self):
        # Capacity truth unreadable at read time must fail closed — a stale
        # snapshot must never stand in for it, and absent-capacity must
        # never be inferred from an unreadable status.
        module = _load_helper()

        def runner(cmd):
            if cmd and cmd[0] == "status":
                return 3, "ght unavailable"
            return 0, json.dumps({
                "issue": 555,
                "claim": {"status": "active", "executor_id": "harryhua-ai",
                          "candidate": "abc123def456"},
                "claim_state": "ACTIVE", "claim_sha": "1" * 40})

        reader = module.GhtOwnershipReader(runner=runner,
                                           identity_executor_id="harryhua-ai")
        facts = reader.read(555)
        self.assertEqual(module.classify_ownership(facts), module.FAIL_CLOSED)

    def test_inspect_exposes_claim_record_fencing_token(self):
        # The identity space of the removal fence is the canonical claim
        # record itself: `ght inspect`'s `claim_sha` rides through to the
        # facts; a missing/unusable token is absent, not invented.
        module = _load_helper()

        def runner(cmd):
            if cmd and cmd[0] == "status":
                return 0, json.dumps({"executor_id": "harryhua-ai",
                                      "active_claims": []})
            return 0, json.dumps({
                "issue": 555,
                "claim": {"status": "delivered", "executor_id": "harryhua-ai",
                          "candidate": "abc123def456"},
                "claim_state": "TERMINAL", "claim_sha": "a" * 40})

        reader = module.GhtOwnershipReader(runner=runner,
                                           identity_executor_id="harryhua-ai")
        self.assertEqual(reader.read(555).fencing_token, "a" * 40)

        def tokenless(cmd):
            if cmd and cmd[0] == "status":
                return 0, json.dumps({"executor_id": "harryhua-ai",
                                      "active_claims": []})
            return 0, json.dumps({
                "issue": 555,
                "claim": {"status": "delivered", "executor_id": "harryhua-ai",
                          "candidate": "abc123def456"},
                "claim_state": "TERMINAL"})

        reader = module.GhtOwnershipReader(runner=tokenless,
                                           identity_executor_id="harryhua-ai")
        self.assertIsNone(reader.read(555).fencing_token)


class CleanupExecutionTests(unittest.TestCase):
    """Executable fenced-cleanup flow over a real (temporary) .worktree."""

    def test_execute_removes_only_freshly_reclaimable_worktrees(self):
        module = _load_helper()
        verdicts = {555: module.RECLAIMABLE, 556: module.PROTECTED,
                    557: module.FAIL_CLOSED}
        removed = []
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            worktree_root = root / ".worktree"
            for name in ("555", "556", "557"):
                (worktree_root / name).mkdir(parents=True)
            report = module.execute_cleanup(
                root,
                read_ownership=lambda issue: _ownership(
                    module, issue=issue, claim_state="NONE")
                if verdicts[issue] == module.RECLAIMABLE else
                (_ownership(module, issue=issue, claim_state="ACTIVE",
                            capacity_live=True)
                 if verdicts[issue] == module.PROTECTED else
                 _ownership(module, issue=issue, readability="unreadable")),
                remove=lambda path: removed.append(path),
                authorize_removal=lambda issue, token: "m",
                confirm_removal=lambda issue, marker: None)
        self.assertEqual(report["removed"], ["555"])
        fenced = {item["worktree"]: item["verdict"] for item in report["fenced"]}
        self.assertEqual(fenced, {"556": module.PROTECTED,
                                  "557": module.FAIL_CLOSED})
        self.assertEqual(removed, [str(worktree_root / "555")])

    def test_non_issue_worktree_entries_fail_closed(self):
        # Names without an Issue number (integration executors, unknown
        # hosts) have no canonical per-Issue ownership to reconcile —
        # they are never treated as orphans.
        module = _load_helper()
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            worktree_root = root / ".worktree"
            (worktree_root / "integration-abc").mkdir(parents=True)
            (worktree_root / "555").mkdir(parents=True)
            entries = module.iter_worktrees(root)
            by_name = {entry.name: entry for entry in entries}
            self.assertIsNone(by_name["integration-abc"].issue)
            self.assertIsNotNone(by_name["555"].issue)
            report = module.execute_cleanup(
                root,
                read_ownership=lambda issue: _ownership(module, issue=issue)
                if issue is not None else _ownership(module,
                                                     readability="unreadable"),
                remove=lambda path: None,
                authorize_removal=lambda issue, token: "m",
                confirm_removal=lambda issue, marker: None)
        self.assertEqual(report["removed"], ["555"])
        self.assertEqual(report["fenced"][0]["verdict"], module.FAIL_CLOSED)

    def test_git_worktree_removal_removes_registered_worktree(self):
        # Hermetic integration of the removal plumbing: a real git repo
        # with a registered worktree is removed by the helper's remover.
        # (#154 review R1: the remover is module-private and proof-gated —
        # it accepts only the single-use RemovalAuthorization the fenced
        # sequence mints after the atomic ght authorization.)
        module = _load_helper()
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp) / "repo"
            repo.mkdir()
            def git(*args):
                subprocess.run(["git", "-C", str(repo), *args], check=True,
                               capture_output=True)
            git("init")
            git("config", "user.email", "t@example.invalid")
            git("config", "user.name", "t")
            (repo / "f.txt").write_text("x\n")
            git("add", "f.txt")
            git("commit", "-m", "base")
            git("worktree", "add", ".worktree/555", "-b", "agent/555/x")
            target = repo / ".worktree" / "555"
            module._remove_worktree(
                repo, str(target),
                module.RemovalAuthorization(issue=555, path=str(target),
                                            marker_sha="m" * 40))
            self.assertFalse(target.exists())


class GhtOwnershipReaderParsingTests(unittest.TestCase):
    """Canonical reads only: the production reader composes facts from
    `ght inspect` + `ght status` payloads and fails closed on anything
    unreadable — never from PID/directory-age inference."""

    def test_payloads_map_to_facts_and_failures_fail_closed(self):
        module = _load_helper()
        status_payload = {
            "executor_id": "harryhua-ai",
            "active_claims": [
                {"issue": 556, "attempt_state": "ACTIVE",
                 "execution_capacity": {"state": "live"}},
                {"issue": 555, "attempt_state": "ACTIVE",
                 "execution_capacity": {"state": "absent"}},
            ],
        }
        def runner(cmd):
            if cmd and cmd[0] == "status":
                return 0, json.dumps(status_payload)
            if cmd[-1] == "556":
                return 0, json.dumps({
                    "issue": 556,
                    "claim": {"status": "active", "executor_id": "harryhua-ai",
                              "candidate": None, "branch": "agent/556/x"},
                    "claim_state": "ACTIVE", "claim_sha": "a" * 40})
            if cmd[-1] == "557":
                return 4, "AMBIGUOUS claim state"
            if cmd[-1] == "558":
                return 0, "{not json"
            return 0, json.dumps({
                "issue": 555,
                "claim": {"status": "active", "executor_id": "harryhua-ai",
                          "candidate": "abc123def456",
                          "branch": "agent/555/y"},
                "claim_state": "ACTIVE", "claim_sha": "b" * 40})

        reader = module.GhtOwnershipReader(runner=runner,
                                           identity_executor_id="harryhua-ai")
        live = reader.read(556)
        self.assertEqual(module.classify_ownership(live), module.PROTECTED)
        parked = reader.read(555)
        self.assertEqual(module.classify_ownership(parked), module.RECLAIMABLE)
        for bad in (557, 558):
            facts = reader.read(bad)
            self.assertEqual(module.classify_ownership(facts),
                             module.FAIL_CLOSED)


class NoSecondRegistryTests(unittest.TestCase):
    """AC6: the fence adds no durable registry, polling GC, or daemon."""

    def test_helper_is_single_shot_with_no_state_file_or_loop(self):
        module = _load_helper()
        source = HELPER_PATH.read_text()
        self.assertNotIn("while True", source)
        self.assertNotIn("time.sleep", source)
        self.assertNotIn("sqlite3", source)
        self.assertNotIn("threading", source)
        self.assertNotIn("\"w\"", source)
        self.assertNotIn("'w'", source)
        self.assertTrue(hasattr(module, "main"))

    def test_cli_help_offers_explicit_execute_only(self):
        # Dry-run is the default; destructive execution is explicit.
        result = subprocess.run(
            [sys.executable, str(HELPER_PATH), "--help"],
            capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("--execute", result.stdout)
        self.assertIn("--repo-root", result.stdout)


class SkillConformanceFencingTests(unittest.TestCase):
    """SKILL.md carries the canonical cleanup-fencing semantics
    (revert-proof: reverting the guidance while keeping the helper
    fails these anchors)."""

    def test_skill_md_prescribes_deletion_boundary_ownership_reconciliation(self):
        skill = SKILL_MD.read_text()
        self.assertIn("fenced against current canonical ownership", skill)
        self.assertIn("never cleanup-eligible", skill)
        self.assertIn("pre-dispatch window", skill)
        self.assertIn("fails closed for destructive cleanup", skill)
        self.assertIn("reclaim-execution-resource", skill)
        self.assertIn("never authorizes deletion", skill)

    def test_skill_md_keeps_pid_and_age_non_authoritative_and_lifecycle_intact(self):
        skill = SKILL_MD.read_text()
        self.assertIn("diagnostic inputs only, never durable ownership authority",
                      skill)
        self.assertIn("no durable worktree registry, worker database, "
                      "scheduler, daemon, or second ownership truth", skill)
        # #97 bounded-lifetime continuity must survive the fence.
        self.assertIn("never a polling GC daemon", skill)
        self.assertIn("disposable host state", skill)


if __name__ == "__main__":
    unittest.main()
