"""Anti-bypass conformance for #154: no Harry Dev/B-owned cleanup path may
destructively remove an Issue-executor worktree except through the #147
canonical fenced reclaim sequence (fresh ght ownership read → atomic
``ght reclaim-execution-resource`` authorization → removal → confirm,
fail-closed on missing/unreadable/ambiguous/refused).

Layers (AC1–AC4):
- guidance anchors: SKILL.md / README.md explicitly forbid raw `rm -rf`,
  bare `git worktree remove`, and age/PID shortcuts, and pin that GitHub
  Issue/PR open/closed/merged state is never deletion authority (both
  directions).
- behavioral fail-closed: the canonical helper's CLI has no bypass knob,
  dry-run never deletes, a refused authorization removes nothing, and the
  three #147 safe classes (true orphan, terminal attempt, parked
  delivery) still pass through the fenced sequence in order.
- structural tripwire (#154 audit, paired with the behavioral tests
  above): across the repository's executable surface (the
  ``skills/github-task/scripts/`` and ``skills/github-task/github_task/``
  package surface, plus the retired repository-root ``scripts/`` and
  ``.github/workflows/`` — the root surface is scanned only to police
  reintroduction of a top-level runtime/helper directory, #155 AC5), the
  only file that combines a destructive
  removal primitive with the ``.worktree`` namespace is the canonical
  fenced helper; every other destructive site is in an explicit allowlist
  of non-Issue-worktree targets, so a future raw cleanup entrypoint fails
  conformance until it joins the fenced sequence.
- capability gate (#154 review R1, paired with the scan below): the
  canonical raw remover itself must not be silently reachable as a second
  entrypoint. It is module-private and requires the single-use
  ``RemovalAuthorization`` proof the fenced sequence mints right after
  the atomic ght authorization, so an external helper that imports and
  calls it with a bare parameterized path (no ``.worktree`` literal, no
  destructive primitive of its own — invisible to the destructive-site
  scan) fails closed by construction; and no repository-owned executable
  surface outside the canonical helper may reference the remover (or
  import the cleanup module) at all.

Audit baseline (2026-09, #154; path updated by #155): destructive-removal
sites found in the scanned surface —
``skills/github-task/scripts/worktree_cleanup.py`` (the canonical fenced
path, package-owned since #155), ``github_task/orchestrator.py`` (the
Execution Driver tearing down
its own just-created ``trace-*`` workspace under the orchestrator run
root while holding that Issue's live capacity — executor session-end
teardown, never a cleanup verdict about a possibly-live resource),
``github_task/cli.py`` (``shutil.rmtree`` of its own ``ght-release-src-*``
temp release clones), and ``ght-formal-release.sh`` (``rm -rf`` of its
own ``mktemp`` release tmpdir). None of the non-canonical sites touches
``.worktree``.
"""

import dataclasses
import importlib.util
import json
import os
import re
import stat
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

REPO_ROOT = Path(__file__).parents[3]
# #155: the canonical cleanup implementation is package-owned — it lives
# inside the github-task Skill package, not at the repository root.
HELPER_PATH = Path(__file__).parents[1] / "scripts" / "worktree_cleanup.py"
CANONICAL_HELPER = "skills/github-task/scripts/worktree_cleanup.py"
SKILL_ROOT = Path(__file__).parents[1]
SKILL_MD = SKILL_ROOT / "SKILL.md"
README_MD = SKILL_ROOT / "README.md"


def _load_helper():
    spec = importlib.util.spec_from_file_location("worktree_cleanup_antibypass",
                                                  HELPER_PATH)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def _ownership(module, issue=555, readability="readable", claim_state="NONE",
               executor_id="harryhua-ai", candidate=None, capacity_live=False,
               identity_executor_id="harryhua-ai", fencing_token=None):
    return module.IssueOwnership(
        issue=issue, readability=readability, claim_state=claim_state,
        executor_id=executor_id, candidate=candidate,
        capacity_live=capacity_live, identity_executor_id=identity_executor_id,
        fencing_token=fencing_token)


def _worktree_root(tmp, name="555"):
    root = Path(tmp)
    wt = root / ".worktree" / name
    wt.mkdir(parents=True)
    return root, wt


class GuidanceAntiBypassConformanceTests(unittest.TestCase):
    """AC1 (+AC2 guidance half): the canonical B/operator surface states the
    anti-bypass invariant outright (revert-proof: reverting the guidance
    while keeping the helper fails these anchors)."""

    def test_skill_md_forbids_direct_raw_and_heuristic_destruction(self):
        skill = " ".join(SKILL_MD.read_text().split())
        self.assertIn("never deletes an Issue-executor worktree directly",
                      skill)
        self.assertIn("no raw `rm -rf` of `.worktree/<issue>`", skill)
        self.assertIn("no bare `git worktree remove`", skill)
        self.assertIn("no directory-age or PID shortcut", skill)
        self.assertIn("routes through the canonical fenced sequence", skill)
        self.assertIn("a raw entrypoint is a forbidden bypass", skill)

    def test_skill_md_pins_issue_pr_state_as_never_deletion_authority(self):
        # AC2: both directions, on the canonical surface.
        skill = " ".join(SKILL_MD.read_text().split())
        self.assertIn("never deletion authority in either direction", skill)
        self.assertIn("stays protected even when the surrounding GitHub UI "
                      "state is stale or contradictory", skill)
        self.assertIn("does not by itself require retaining a "
                      "parked/delivered worktree", skill)

    def test_readme_navigates_to_the_single_fenced_route(self):
        readme = " ".join(README_MD.read_text().split())
        self.assertIn("exactly one destructive route", readme)
        self.assertIn("forbidden bypasses", readme)
        self.assertIn("never deletion authority", readme)

    def test_skill_md_pins_the_raw_remover_as_proof_gated_internal(self):
        # #154 review R1: the remover itself must not be an importable
        # second entrypoint — the entrypoint contract is anchored on the
        # canonical surface, not only implemented in the helper.
        skill = " ".join(SKILL_MD.read_text().split())
        self.assertIn("fenced to that sequence by construction", skill)
        self.assertIn("single-use removal-authorization proof", skill)
        self.assertIn("must not import or call it from anywhere else", skill)

    def test_readme_states_the_remover_is_internal_to_the_sequence(self):
        readme = " ".join(README_MD.read_text().split())
        self.assertIn("internal to that sequence", readme)
        self.assertIn("not an importable second entrypoint", readme)


class IssuePrStateNotAuthorityTests(unittest.TestCase):
    """AC2 behavioral half: verdicts are functions of canonical ght facts
    only — GitHub Issue/PR UI state has no field in the ownership facts and
    cannot move a fence decision in either direction."""

    def test_ownership_facts_carry_no_github_ui_state_field(self):
        module = _load_helper()
        fields = {f.name for f in dataclasses.fields(module.IssueOwnership)}
        self.assertEqual(
            fields, {"issue", "readability", "claim_state", "executor_id",
                     "candidate", "capacity_live", "identity_executor_id",
                     "fencing_token"})
        for banned in ("issue_state", "pr_state", "merged", "ui_"):
            self.assertFalse(any(banned in name for name in fields),
                             f"UI-state field {banned!r} must never become "
                             "ownership truth")

    def test_merged_or_closed_ui_state_cannot_authorize_deleting_active(self):
        # GitHub UI asserts the PR merged / Issue closed; canonical ght says
        # the attempt is ACTIVE with a live execution capacity. The UI fact
        # has no voice: the resource stays PROTECTED.
        module = _load_helper()
        own = _ownership(module, claim_state="ACTIVE", capacity_live=True)
        self.assertEqual(module.classify_ownership(own), module.PROTECTED)

    def test_claimed_pre_dispatch_survives_contradictory_closed_ui(self):
        module = _load_helper()
        own = _ownership(module, claim_state="ACTIVE", capacity_live=False,
                         candidate=None)
        self.assertEqual(module.classify_ownership(own), module.PROTECTED)

    def test_open_issue_does_not_force_retaining_parked_worktree(self):
        # The inverse direction: GitHub UI says the Issue/PR are still open;
        # canonical ght proves the parked predicate (durable Candidate, no
        # live capacity). The open UI state must not force retention.
        module = _load_helper()
        own = _ownership(module, claim_state="ACTIVE",
                         candidate="abc123def456", capacity_live=False)
        self.assertEqual(module.classify_ownership(own), module.RECLAIMABLE)


class SingleFencedEntrypointConformanceTests(unittest.TestCase):
    """AC3/AC4 structural tripwire (paired with the behavioral fail-closed
    tests below and the #147 fencing suites): the only repository-owned
    file that combines a destructive removal primitive with the
    ``.worktree`` namespace is the canonical fenced helper, and every other
    destructive site is an allowlisted non-Issue-worktree target."""

    SCAN_ROOTS = (
        REPO_ROOT / "scripts",
        SKILL_ROOT / "scripts",
        SKILL_ROOT / "github_task",
        REPO_ROOT / ".github" / "workflows",
    )
    SCAN_SUFFIXES = (".py", ".sh", ".yml", ".yaml")

    # A line that removes things: rmtree, `rm -rf`-style shell, or any
    # worktree remove/prune (list-form git argv or plain shell text).
    DESTRUCTIVE_RE = re.compile(
        r"rmtree"
        r"|\brm\s+-[a-zA-Z-]*[rf]"
        r"|\bworktree[\"']?\s*,\s*[\"'](?:remove|prune)"
        r"|\bworktree\s+(?:remove|prune)\b")

    # Allowlisted destructive sites that are NOT Issue-worktree cleanup,
    # each with the reason it is out of the fenced path's charter.
    ALLOWLIST = {
        CANONICAL_HELPER:
            "the canonical fenced reclaim path itself (behaviorally proven "
            "by the fencing suites and the fail-closed tests below)",
        "skills/github-task/github_task/orchestrator.py":
            "the Execution Driver tears down only its own just-created "
            "trace-* workspace under the orchestrator run root while "
            "holding that Issue's live capacity — executor session-end "
            "teardown, never a cleanup verdict",
        "skills/github-task/github_task/cli.py":
            "rmtree of its own ght-release-src-* temp release clones "
            "(plain temporary clones, never .worktree state)",
        "skills/github-task/scripts/ght-formal-release.sh":
            "rm -rf of its own mktemp release tmpdir",
    }

    def _scanned_files(self):
        for scan_root in self.SCAN_ROOTS:
            if not scan_root.is_dir():
                continue
            for path in sorted(scan_root.rglob("*")):
                if path.is_file() and path.suffix in self.SCAN_SUFFIXES:
                    rel = path.relative_to(REPO_ROOT).as_posix()
                    if "/tests/" in f"/{rel}":
                        continue
                    yield rel, path

    def test_only_the_canonical_helper_combines_destruction_with_worktree_namespace(self):
        offenders = []
        for rel, path in self._scanned_files():
            text = path.read_text(errors="replace")
            destructive = any(self.DESTRUCTIVE_RE.search(line)
                              for line in text.splitlines())
            if destructive and ".worktree" in text and \
                    rel != CANONICAL_HELPER:
                offenders.append(rel)
        self.assertEqual(offenders, [],
                         "files that destructively remove .worktree state "
                         "outside the canonical fenced helper (bypass)")

    def test_every_destructive_site_is_an_allowlisted_non_worktree_target(self):
        unknown = []
        for rel, path in self._scanned_files():
            text = path.read_text(errors="replace")
            if any(self.DESTRUCTIVE_RE.search(line)
                   for line in text.splitlines()):
                if rel not in self.ALLOWLIST:
                    unknown.append(rel)
                elif ".worktree" in text and \
                        rel != CANONICAL_HELPER:
                    unknown.append(f"{rel} (allowlisted but touches "
                                   ".worktree)")
        self.assertEqual(unknown, [],
                         "new destructive entrypoints must join the fenced "
                         "sequence and be added here only with proof they "
                         "never touch .worktree state")

    def test_canonical_helper_is_the_only_worktree_namespace_script(self):
        # AC3: within the scanned surface, exactly one file reconciles
        # `.worktree` — the fenced helper; its removal goes through the
        # authorize → remove → confirm sequence (behaviorally proven in
        # FencedSequenceForSafeCasesTests and the #147 suites).
        touching = [rel for rel, path in self._scanned_files()
                    if ".worktree" in path.read_text(errors="replace")]
        self.assertEqual(touching, [CANONICAL_HELPER])


class FencedSequenceForSafeCasesTests(unittest.TestCase):
    """AC4: the three #147 safe classes still pass through the fenced path,
    in the canonical order — fresh eligibility read anchored the
    authorization, authorization precedes removal, confirm follows it."""

    def _run(self, module, claim_state, fencing_token, candidate=None):
        events = []
        with tempfile.TemporaryDirectory() as tmp:
            root, wt = _worktree_root(tmp)
            report = module.execute_cleanup(
                root,
                read_ownership=lambda issue: _ownership(
                    module, claim_state=claim_state, candidate=candidate,
                    fencing_token=fencing_token),
                remove=lambda path: events.append(("remove", path)),
                authorize_removal=lambda issue, token: events.append(
                    ("authorize", issue, token)) or "marker-sha-1",
                confirm_removal=lambda issue, marker: events.append(
                    ("confirm", issue, marker)))
        return events, report, wt

    def test_orphan_terminal_and_parked_all_reclaim_through_the_fence(self):
        module = _load_helper()
        cases = [
            ("orphan", dict(claim_state="NONE", fencing_token=None)),
            ("terminal", dict(claim_state="TERMINAL",
                              fencing_token="d" * 40)),
            ("parked", dict(claim_state="ACTIVE",
                            candidate="abc123def456",
                            fencing_token="e" * 40)),
        ]
        for label, kwargs in cases:
            with self.subTest(case=label):
                events, report, wt = self._run(module, **kwargs)
                self.assertEqual(report["removed"], ["555"])
                self.assertEqual(report["fenced"], [])
                self.assertEqual(report["post_removal_alerts"], [])
                self.assertEqual(
                    events,
                    [("authorize", 555, kwargs["fencing_token"]),
                     ("remove", str(wt)),
                     ("confirm", 555, "marker-sha-1")])
                self.assertEqual([event[0] for event in events],
                                 ["authorize", "remove", "confirm"],
                                 "authorization must precede removal and "
                                 "confirm must follow it")


class NoBypassKnobTests(unittest.TestCase):
    """AC4: the canonical CLI exposes no raw/forced/skipped destructive
    mode — ``--execute`` through the fence is the only removal path."""

    def test_cli_help_offers_no_force_skip_or_yes_flags(self):
        result = subprocess.run(
            [sys.executable, str(HELPER_PATH), "--help"],
            capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        help_text = result.stdout.lower()
        for banned in ("--force", "--skip", "--no-fence", "--yes", "-f,"):
            self.assertNotIn(banned, help_text)

    def test_raw_remover_is_only_reachable_through_the_fenced_sequence(self):
        source = HELPER_PATH.read_text()
        call_sites = [line.strip() for line in source.splitlines()
                      if "remove_worktree(" in line
                      and not line.strip().startswith("def ")]
        self.assertEqual(len(call_sites), 1, call_sites)
        self.assertIn("execute_cleanup",
                      source[:source.index(call_sites[0])],
                      "the raw remover must only be handed to the fenced "
                      "sequence, never called around it")

    def test_remove_worktree_refuses_paths_outside_the_worktree_namespace(self):
        # AC3 hardening: the remover is charter-scoped to the repo's
        # `.worktree/` — it must fail closed on any other path instead of
        # doubling as a general-purpose destroyer. (#154 review R1: the
        # remover is private and proof-gated, so the charter check is
        # exercised with the proof the fenced sequence would mint.)
        module = _load_helper()
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp) / "repo"
            repo.mkdir()
            def git(*args):
                subprocess.run(["git", "-C", str(repo), *args], check=True,
                               capture_output=True)
            git("init")
            git("config", "user.email", "t@example.invalid")
            git("config", "user.name", "t")
            (repo / "f.txt").write_text("x\n")
            git("add", "f.txt")
            git("commit", "-m", "base")
            outside = Path(tmp) / "outside-wt"
            git("worktree", "add", str(outside), "-b", "agent/555/x")
            proof = module.RemovalAuthorization(issue=555, path=str(outside),
                                                marker_sha="m" * 40)
            with self.assertRaises(ValueError):
                module._remove_worktree(repo, str(outside), proof)
            self.assertTrue(outside.exists(),
                            "non-.worktree path must survive the refusal")

    def test_dry_run_default_never_deletes_a_reclaimable_worktree(self):
        # Removal is always explicit: the default mode reports, never deletes.
        module = _load_helper()
        with tempfile.TemporaryDirectory() as tmp:
            root, wt = _worktree_root(tmp)
            result = subprocess.run(
                [sys.executable, str(HELPER_PATH), "--repo-root", str(root),
                 "--ght", str(_fake_ght(tmp, "authorize"))],
                capture_output=True, text=True,
                env={**os.environ, "FAKE_GHT_MODE": "authorize"})
            self.assertEqual(result.returncode, 0, result.stderr)
            report = json.loads(result.stdout)
            self.assertEqual(report["mode"], "dry-run")
            self.assertEqual(report["removed"], [])
            self.assertTrue(wt.exists())


class RawRemoverCapabilityGateTests(unittest.TestCase):
    """AC4 (review R1): the canonical raw remover must not be silently
    reachable as a second entrypoint for repository-owned executable
    surface. A new repo-owned helper that imports/calls it directly —
    path parameterized, no ``.worktree`` literal, no rmtree/``rm -rf``/
    ``git worktree`` primitive in its own source, so every scan above
    stays green — must fail closed by construction instead of deleting
    around authorize → remove → confirm."""

    def _git_repo_with_registered_worktree(self, tmp):
        repo = Path(tmp) / "repo"
        repo.mkdir(parents=True)
        def git(*args):
            subprocess.run(["git", "-C", str(repo), *args], check=True,
                           capture_output=True)
        git("init")
        git("config", "user.email", "t@example.invalid")
        git("config", "user.name", "t")
        (repo / "f.txt").write_text("x\n")
        git("add", "f.txt")
        git("commit", "-qm", "base")
        git("worktree", "add", ".worktree/555", "-b", "agent/555/x")
        return repo, repo / ".worktree" / "555"

    @staticmethod
    def _raw_remover_candidates(module):
        # What an external helper sees when it goes looking for the
        # canonical module's worktree-removal capability.
        return [getattr(module, name) for name in dir(module)
                if "remove" in name.lower() and "worktree" in name.lower()
                and callable(getattr(module, name))]

    def test_module_exposes_no_public_bare_path_raw_remover(self):
        # The public bare-path name is the second entrypoint: it must not
        # exist. Only a module-private remover remains, for the fenced
        # sequence's own binding.
        module = _load_helper()
        self.assertFalse(hasattr(module, "remove_worktree"),
                         "the raw remover must be module-private — a public "
                         "bare-path name is an importable second entrypoint "
                         "around the fence")

    def test_external_bare_path_call_on_the_raw_remover_fails_closed(self):
        # The adversarial shape from the review, executed for real: a
        # caller outside the canonical module resolves its remover and
        # calls it with just (repo_root, parameterized path). That call
        # must raise instead of deleting — never a silent bypass of
        # authorize → remove → confirm.
        module = _load_helper()
        with tempfile.TemporaryDirectory() as tmp:
            repo, wt = self._git_repo_with_registered_worktree(tmp)
            candidates = self._raw_remover_candidates(module)
            self.assertTrue(candidates, "the canonical module must still "
                                        "expose its remover to the fenced "
                                        "sequence itself")
            for remover in candidates:
                with self.subTest(remover=remover.__name__):
                    with self.assertRaises((TypeError, ValueError)):
                        remover(repo, str(wt))
            self.assertTrue(wt.exists(),
                            "an external bare-path call must never delete; "
                            "removal requires the fenced authorization "
                            "proof")

    def test_raw_remover_requires_the_single_use_fenced_authorization_proof(self):
        # By construction: no proof → refuse; a well-typed proof that does
        # not cover the path → refuse. One authorization fences exactly
        # one path.
        module = _load_helper()
        with tempfile.TemporaryDirectory() as tmp:
            repo, wt = self._git_repo_with_registered_worktree(tmp)
            with self.assertRaises((TypeError, ValueError)):
                module._remove_worktree(repo, str(wt))
            forged = module.RemovalAuthorization(
                issue=555, path=str(wt) + "-other", marker_sha="m" * 40)
            with self.assertRaises(ValueError):
                module._remove_worktree(repo, str(wt), forged)
            self.assertTrue(wt.exists())

    def test_default_sequence_binding_carries_the_proof_and_removes(self):
        # Through execute_cleanup's production binding (no injected
        # remove — exactly what the CLI wires), a reclaimable worktree is
        # still removed by the real remover: the proof minted right after
        # the atomic authorization is what lets the destructive call fire.
        module = _load_helper()
        with tempfile.TemporaryDirectory() as tmp:
            repo, wt = self._git_repo_with_registered_worktree(tmp)
            report = module.execute_cleanup(
                repo,
                read_ownership=lambda issue: _ownership(
                    module, claim_state="TERMINAL", fencing_token="d" * 40),
                authorize_removal=lambda issue, token: "m" * 40,
                confirm_removal=lambda issue, marker: None)
        self.assertEqual(report["removed"], ["555"])
        self.assertFalse(wt.exists(),
                         "the fenced production binding must still remove "
                         "the freshly authorized reclaimable")


class RawRemoverReachabilityConformanceTests(unittest.TestCase):
    """AC4 (review R1), repo-wide call-site constraint: no repository-owned
    executable surface may reference the canonical raw remover — by name or
    by importing the cleanup module — outside the canonical helper itself.
    This closes the scan gap the review identified: a helper that only
    imports/calls the remover (parameterized path, no ``.worktree``
    literal, no destructive primitive) evades the destructive-site scan
    but fails this reference scan. Paired with
    RawRemoverCapabilityGateTests, which proves the direct call also fails
    closed behaviorally."""

    SCAN_ROOTS = (
        REPO_ROOT / "scripts",
        SKILL_ROOT / "scripts",
        SKILL_ROOT / "github_task",
        REPO_ROOT / ".github" / "workflows",
    )
    SCAN_SUFFIXES = (".py", ".sh", ".yml", ".yaml")
    CANONICAL_HELPER = "skills/github-task/scripts/worktree_cleanup.py"

    @staticmethod
    def references_raw_remover(text: str) -> bool:
        # Deliberately substring-based (no leading word boundary): both the
        # public and the private remover name, and any import of the
        # cleanup module, must be caught regardless of call shape.
        return "remove_worktree" in text or "worktree_cleanup" in text

    def _scanned_files(self):
        for scan_root in self.SCAN_ROOTS:
            if not scan_root.is_dir():
                continue
            for path in sorted(scan_root.rglob("*")):
                if path.is_file() and path.suffix in self.SCAN_SUFFIXES:
                    rel = path.relative_to(REPO_ROOT).as_posix()
                    if "/tests/" in f"/{rel}":
                        continue
                    yield rel, path

    def test_only_the_canonical_helper_references_the_raw_remover(self):
        offenders = []
        for rel, path in self._scanned_files():
            text = path.read_text(errors="replace")
            if self.references_raw_remover(text) and \
                    rel != self.CANONICAL_HELPER:
                offenders.append(rel)
        self.assertEqual(offenders, [],
                         "repository-owned executable surface must reach "
                         "the raw remover only through the canonical fenced "
                         "module — a direct import/call elsewhere is a "
                         "forbidden second entrypoint (#154 AC4)")

    def test_detector_flags_the_adversarial_parameterized_helper_shape(self):
        # The exact bypass shape from the review: imports/calls the raw
        # remover with a parameterized path while carrying no ``.worktree``
        # literal and no destructive primitive — invisible to the
        # destructive-site scans above, flagged by the reference scan.
        adversarial = (
            "import importlib.util\n"
            "spec = importlib.util.spec_from_file_location(\"wc\", "
            "helper_path)\n"
            "module = importlib.util.module_from_spec(spec)\n"
            "spec.loader.exec_module(module)\n"
            "\n"
            "def purge(target):\n"
            "    module.remove_worktree(REPO_ROOT, target)\n"
        )
        self.assertNotIn(".worktree", adversarial)
        self.assertFalse(
            SingleFencedEntrypointConformanceTests.DESTRUCTIVE_RE.search(
                adversarial),
            "fixture must represent the scan-evading shape")
        self.assertTrue(self.references_raw_remover(adversarial))

    def test_benign_fenced_composition_is_not_flagged(self):
        # Composing the fenced sequence (fresh read + authorize + confirm)
        # never needs the remover's name and must stay green.
        benign = ("report = execute_cleanup(repo_root, reader.read,\n"
                  "                         authorize_removal=reclaim.authorize,\n"
                  "                         confirm_removal=reclaim.confirm)\n")
        self.assertFalse(self.references_raw_remover(benign))


class CliFencedBoundaryEndToEndTests(unittest.TestCase):
    """AC3/AC4 behavioral: through the real ``main()`` CLI, a reclaimable
    worktree is removed only when the atomic ght authorization succeeds,
    and a refused authorization fences it fail-closed."""

    def _run_cli(self, tmp, mode):
        tmp = Path(tmp)
        repo = tmp / "repo"
        repo.mkdir()
        def git(*args):
            subprocess.run(["git", "-C", str(repo), *args], check=True,
                           capture_output=True)
        git("init")
        git("config", "user.email", "t@example.invalid")
        git("config", "user.name", "t")
        (repo / "f.txt").write_text("x\n")
        git("add", "f.txt")
        git("commit", "-qm", "base")
        git("worktree", "add", ".worktree/555", "-b", "agent/555/x")
        wt = repo / ".worktree" / "555"
        log = tmp / "fake-ght-calls.log"
        result = subprocess.run(
            [sys.executable, str(HELPER_PATH), "--repo-root", str(repo),
             "--ght", str(_fake_ght(tmp, mode)), "--execute"],
            capture_output=True, text=True,
            env={**os.environ, "FAKE_GHT_MODE": mode,
                 "FAKE_GHT_LOG": str(log)})
        calls = [json.loads(line) for line in
                 log.read_text().splitlines()] if log.exists() else []
        return result, report_or_none(result), wt, calls

    def test_refused_authorization_removes_nothing_end_to_end(self):
        with tempfile.TemporaryDirectory() as tmp:
            result, report, wt, calls = self._run_cli(tmp, "refuse")
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(report["removed"], [])
            self.assertEqual(len(report["fenced"]), 1)
            self.assertEqual(report["fenced"][0]["verdict"], "FAIL_CLOSED")
            self.assertIn("refused", report["fenced"][0]["detail"])
            self.assertTrue(wt.exists(), "refused removal must leave the "
                                         "worktree in place")
            reclaim_calls = [call for call in calls
                             if call and call[0] == "reclaim-execution-resource"]
            self.assertTrue(reclaim_calls)
            self.assertNotIn("--confirm-removal",
                             [flag for call in reclaim_calls
                              for flag in call])

    def test_successful_authorization_removes_and_confirms_end_to_end(self):
        with tempfile.TemporaryDirectory() as tmp:
            result, report, wt, calls = self._run_cli(tmp, "authorize")
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(report["removed"], ["555"])
            self.assertEqual(report["post_removal_alerts"], [])
            self.assertFalse(wt.exists())
            reclaims = [call for call in calls
                        if call and call[0] == "reclaim-execution-resource"]
            authorize_call = reclaims[0]
            confirm_call = next(call for call in reclaims
                                if "--confirm-removal" in call)
            # The authorization anchors on the eligibility read's claim_sha;
            # the confirm anchors on the marker the authorization minted.
            self.assertIn("a" * 40, authorize_call)
            self.assertIn("m" * 40, confirm_call)


def report_or_none(result):
    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError:
        raise AssertionError(f"cleanup CLI emitted no report: "
                             f"{result.stdout!r} {result.stderr!r}")


def _fake_ght(tmp, mode):
    """A hermetic fake ght CLI: readable canonical truth (TERMINAL claim
    with a claim_sha) whose reclaim authorization honors FAKE_GHT_MODE."""
    script = Path(tmp) / f"fake-ght-{mode}.py"
    script.write_text(
        "import json, os, sys\n"
        "args = sys.argv[1:]\n"
        "log = os.environ.get('FAKE_GHT_LOG')\n"
        "if log:\n"
        "    with open(log, 'a') as fh:\n"
        "        fh.write(json.dumps(args) + chr(10))\n"
        "if args and args[0] == 'status':\n"
        "    print(json.dumps({'executor_id': 'worker-1',\n"
        "                      'active_claims': []}))\n"
        "elif args and args[0] == 'inspect':\n"
        "    print(json.dumps({'issue': 555,\n"
        "        'claim': {'status': 'delivered',\n"
        "                  'executor_id': 'worker-1',\n"
        "                  'candidate': 'abc123def456'},\n"
        "        'claim_state': 'TERMINAL',\n"
        "        'claim_sha': 'a' * 40}))\n"
        "elif args and args[0] == 'reclaim-execution-resource':\n"
        "    if '--confirm-removal' in args:\n"
        "        print(json.dumps({'ok': True}))\n"
        "    elif os.environ.get('FAKE_GHT_MODE') == 'authorize':\n"
        "        print(json.dumps({'marker_sha': 'm' * 40}))\n"
        "    else:\n"
        "        print(json.dumps({'error': 'reclaim authorization "
        "refused by fixture'}))\n"
        "        sys.exit(2)\n"
        "else:\n"
        "    sys.exit(3)\n")
    script.chmod(script.stat().st_mode | stat.S_IXUSR)
    return script


if __name__ == "__main__":
    unittest.main()
