"""The canonical Harry Dev project-AGENTS contract (#166).

Harry Dev ships ONE concise, mechanically identifiable, versioned AGENTS
managed block with the released github-task distribution (this module IS
the shipped artifact: it lives inside the packaged ``github_task/`` tree,
so release packaging carries it with no new release mechanics). On first
supported project adoption/deploy the block is applied to the TARGET
repository's root ``AGENTS.md`` idempotently, preserving all
project-owned content.

Ownership boundaries, stated exactly:

- AGENTS.md is durable project engineering/review guidance only. The
  managed block grants no READY, execution, acceptance, merge,
  scheduling, or release authority, and it never duplicates the A Prompt,
  the B Skill, Task Contract grammar, the methodology provider, the
  automated-review workflow, a repo map, commands, or project
  documentation — it is a small behavioral map.
- Project-owned content is everything OUTSIDE the managed block(s),
  including every nested ``AGENTS.md`` / ``AGENTS.override.md`` (which
  adoption never enumerates or touches). The bytes between the versioned
  markers are Harry Dev-owned and are what adoption reconciles.
- No-implicit-upgrade (AC4): an already adopted block carries its version
  in its begin/end markers; a newer installed Skill never silently
  rewrites it — reconciliation to a different block version happens only
  under a Harry Dev release upgrade ALREADY authorized for the project,
  with the ``--upgrade`` flag as that authorized path's execution
  selector (the flag is not itself the authorization and never
  establishes it).
- Material authority/security/credential conflicts in project-owned
  content fail closed for A reconciliation; they are never silently
  adopted. The screen below is deliberately conservative and mechanical —
  it never edits content, and the materiality judgment stays with A.
- No registry, ref, database, migration daemon, or lifecycle state is
  introduced: the versioned markers in the file are the only state.
"""

from __future__ import annotations

import re
from typing import Any

# The managed-block contract version. Bumping it changes the markers and
# signals a new release contract — never an implicit rewrite of an
# already adopted project's block (AC4).
BLOCK_VERSION = 1

_MARKER_NAME = "harry-dev:agents-managed"

BEGIN_MARKER_TEMPLATE = f"<!-- {_MARKER_NAME} begin v{{version}} -->"
END_MARKER_TEMPLATE = f"<!-- {_MARKER_NAME} end v{{version}} -->"

# Any managed-marker line, of either kind: the mechanical unit the
# fail-closed scan reasons over (a begin or end marker that is not part of
# a well-formed, version-matched pair is malformed state, never
# project-owned text). The lookahead (never a consumed ``\n``) recognizes a
# marker line even at EOF without a trailing newline — no Harry Dev marker
# line can escape the scan — while the block region ends exactly at the
# end marker, byte-identical to the canonical block.
_MARKER_RE = re.compile(
    rf"^<!-- {re.escape(_MARKER_NAME)} (begin|end) v(\d+) -->[ \t]*(?=\n|$)",
    re.M)


class MalformedManagedMarkersError(ValueError):
    """A Harry Dev managed-marker structure adoption cannot interpret.

    The whole malformed-marker family fails closed: a begin marker with
    no matching end marker, an end marker with no open begin marker, a
    begin/end version mismatch, doubled/nested begin markers, or a stray
    end marker after (or before) a complete block. Such state is never
    reclassified as project-owned text and then adopted/reconciled
    alongside a new or current block — it is surfaced for A
    reconciliation with the file preserved unchanged.
    """

    def __init__(self, reason: str, *, line: int):
        super().__init__(f"{reason} (managed-marker line {line})")
        self.reason = reason
        self.line = line

# The canonical block content between the markers. Exact wording is HOW;
# the semantic set it must preserve is pinned by
# tests.test_agents_adoption.test_shipped_block_carries_the_canonical_semantic_set.
_BLOCK_BODY = """\
## Harry Dev engineering / review boundary

- The current Task Contract (the active Issue's `ght-contract`) owns the task's WHAT, BOUNDARY, and DONE.
- This AGENTS.md is durable project engineering/review guidance only; it grants no READY, execution, acceptance, merge, scheduling, or release authority.
- Review what is consequential: correctness, regressions, Contract/scope violations, weak or missing tests, and security/data-integrity where material; avoid cosmetic or speculative churn better owned by deterministic tooling.
- Compare implementation behavior with the current Task Contract; passing tests and author-checked acceptance criteria are evidence, not proof.
- When a changed surface makes a negative path consequential, verify the test actually constructs the failure, race, permission, or partial-state condition it claims to exercise.
- The independent steward agent (A) remains the exact-Candidate acceptance/integration authority; User-owned product and release decisions remain User-owned."""


def begin_marker(version: int = BLOCK_VERSION) -> str:
    return BEGIN_MARKER_TEMPLATE.format(version=version)


def end_marker(version: int = BLOCK_VERSION) -> str:
    return END_MARKER_TEMPLATE.format(version=version)


def managed_block_body() -> str:
    """The canonical block content between the markers (no markers)."""
    return _BLOCK_BODY


def managed_block(version: int = BLOCK_VERSION) -> str:
    """The canonical managed block: markers + content, no trailing newline."""
    return f"{begin_marker(version)}\n{_BLOCK_BODY}\n{end_marker(version)}"


# The shipped canonical block at the module's contract version.
MANAGED_BLOCK = managed_block(BLOCK_VERSION)


def find_managed_blocks(text: str) -> list[dict[str, Any]]:
    """Every managed block in a document, in order — FAIL CLOSED.

    Each entry carries ``version`` (from the begin marker), ``begin`` and
    ``end`` offsets of the full ``marker..marker`` region, and ``text``
    (the exact region bytes).

    Any Harry Dev managed marker that is not part of a well-formed,
    version-matched begin/end pair raises ``MalformedManagedMarkersError``:
    a begin marker with no matching end marker, an end marker with no open
    begin marker, a begin/end version mismatch, doubled/nested begin
    markers, or a stray end marker before/after a complete block. Mangled
    marker state is never reclassified as project-owned text and then
    adopted/reconciled alongside a new or current block — that would leave
    ambiguous Harry Dev-owned marker state in the file. It fails closed
    for A reconciliation with the file preserved unchanged.
    """

    blocks: list[dict[str, Any]] = []
    open_begin: tuple[int, int] | None = None  # (version, region start)
    for marker in _MARKER_RE.finditer(text):
        kind, version = marker.group(1), int(marker.group(2))
        line = text.count("\n", 0, marker.start()) + 1
        if kind == "begin":
            if open_begin is not None:
                raise MalformedManagedMarkersError(
                    "a begin marker appears before the previous managed "
                    "block's end marker", line=line)
            open_begin = (version, marker.start())
        else:
            if open_begin is None:
                raise MalformedManagedMarkersError(
                    "an end marker appears with no open begin marker",
                    line=line)
            if version != open_begin[0]:
                raise MalformedManagedMarkersError(
                    "the end marker version does not match its begin "
                    "marker version", line=line)
            blocks.append({"version": version,
                           "begin": open_begin[1],
                           "end": marker.end(),
                           "text": text[open_begin[1]:marker.end()]})
            open_begin = None
    if open_begin is not None:
        raise MalformedManagedMarkersError(
            "a begin marker has no matching end marker",
            line=text.count("\n", 0, open_begin[1]) + 1)
    return blocks


def project_owned_text(text: str, blocks: list[dict[str, Any]]) -> str:
    """Everything outside the managed block regions — the project's bytes."""

    pieces: list[str] = []
    position = 0
    for block in blocks:
        pieces.append(text[position:block["begin"]])
        position = block["end"]
    pieces.append(text[position:])
    return "".join(pieces)


# --- material-conflict screen (conservative, mechanical, fail closed) ----
#
# Adoption never silently accepts a project AGENTS.md whose OWN content
# contradicts the contract it is adopting: grammar that grants the
# executor merge/release/acceptance authority, or credential-shaped
# literals. The screen is deliberately narrow — it exists to force an A
# reconciliation, never to judge for A. Hits are reported with class,
# line, and an excerpt; the file is never modified in that case.

_CREDENTIAL_PATTERNS: tuple[tuple[str, str], ...] = (
    ("aws-access-key-id", r"\bAKIA[0-9A-Z]{16}\b"),
    ("private-key-block", r"-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----"),
    ("github-token", r"\bgh[pousr]_[A-Za-z0-9]{20,}\b"),
    ("slack-token", r"\bxox[baprs]-[A-Za-z0-9-]{10,}\b"),
    ("model-provider-key", r"\bsk-(?:ant-|proj-)?[A-Za-z0-9_-]{20,}\b"),
    ("google-api-key", r"\bAIza[0-9A-Za-z_\-]{35}\b"),
)

_AUTHORITY_CONFLICT_PATTERNS: tuple[tuple[str, str], ...] = (
    ("self-merge-grammar", r"\bself-?(?:merge|accept|approve|release|deploy)\b"),
    ("merge-own-work-grammar",
     r"\b(?:merge|push|land)\s+(?:your|its|their|the)\s+(?:own\s+)?"
     r"(?:work|changes?|commits?|PRs?|branches?)\s+(?:directly\s+)?"
     r"(?:to|into|on)\b"),
    ("authorized-to-ship-grammar",
     r"\b(?:is|are|be)\s+(?:authorized|allowed|permitted|expected|"
     r"instructed)\s+to\s+(?:merge|release|deploy|accept|push)\b"),
    ("direct-to-protected-branch-grammar",
     r"\b(?:push|commit|merge)\s+(?:directly\s+)?to\s+(?:the\s+)?"
     r"(?:protected\s+)?(?:main|master|trunk)\b"),
    ("protection-bypass-grammar",
     r"\b(?:bypass|override|disable)\s+(?:the\s+)?(?:branch\s+)?protection\b"),
)

_CONFLICT_PATTERNS: tuple[tuple[str, str], ...] = \
    _CREDENTIAL_PATTERNS + _AUTHORITY_CONFLICT_PATTERNS


def scan_conflicts(project_text: str) -> list[dict[str, Any]]:
    """Mechanical material-conflict hits in project-owned content."""

    hits: list[dict[str, Any]] = []
    for name, pattern in _CONFLICT_PATTERNS:
        for match in re.finditer(pattern, project_text, re.I):
            line = project_text.count("\n", 0, match.start()) + 1
            excerpt = project_text[match.start():match.end()]
            hits.append({"class": name, "line": line, "excerpt": excerpt})
    return sorted(hits, key=lambda hit: (hit["line"], hit["class"]))


# --- reconcile decision ---------------------------------------------------
#
# Statuses:
#   created              — no root file (or empty): write the block alone
#   adopted              — existing file, no block: insert one block
#   current              — block present, canonical, version current: no-op
#   reconciled           — same-version block drifted: restore canonical
#   upgraded             — release-upgrade reconciliation of the block,
#                          used only under an upgrade ALREADY authorized
#                          for the project (the selector is not the grant)
#   duplicate_managed_block / material_conflict / upgrade_required /
#   malformed_markers    — fail closed for A reconciliation (never write)

_WRITE_STATUSES = ("created", "adopted", "reconciled", "upgraded")
_REFUSE_STATUSES = ("duplicate_managed_block", "material_conflict",
                    "upgrade_required", "malformed_markers")


def reconcile(existing: str | None, *,
              block_version: int = BLOCK_VERSION,
              block: str | None = None,
              upgrade_selector: bool = False) -> dict[str, Any]:
    """Decide what first adoption / re-adoption does to a root AGENTS.md.

    Pure function over the file's current text (``None``/empty when
    absent). Returns either ``{"status": <write status>, "action":
    "write", "content": <new file text>, ...}`` or ``{"status": <refusal>,
    "action": "refuse", "reason": <...>, ...}``. Never touches the
    filesystem; the caller performs the prepared write as a working-tree
    proposal only.

    ``upgrade_selector`` is an EXECUTION SELECTOR ONLY (AC4): it does not
    itself establish the authorization that reconciliation to a different
    block version requires. That authorization — an explicit Harry Dev
    release upgrade for this project — must already exist, established
    through the project's normal governance, before the selector is used.
    Passing the selector without such an independently established
    authorization is a Contract violation this surface cannot detect
    mechanically; the selector must never be cited as evidence that the
    authorization exists.
    """

    canonical = managed_block(block_version) if block is None else block
    if existing is None or not existing.strip():
        return {"status": "created", "action": "write",
                "content": canonical + "\n",
                "block_version": block_version}
    try:
        blocks = find_managed_blocks(existing)
    except MalformedManagedMarkersError as malformed:
        return {"status": "malformed_markers", "action": "refuse",
                "reason": "the file's Harry Dev managed-marker structure "
                          f"is malformed ({malformed.reason}) — mangled "
                          "marker state is never reclassified as "
                          "project-owned text; adoption fails closed and "
                          "the file is preserved unchanged — reconcile "
                          "with A",
                "malformed_line": malformed.line}
    if len(blocks) > 1:
        return {"status": "duplicate_managed_block", "action": "refuse",
                "reason": "the file carries more than one managed block — a "
                          "mangled state adoption cannot reconcile; "
                          "reconcile with A",
                "block_count": len(blocks)}
    owned = project_owned_text(existing, blocks)
    conflicts = scan_conflicts(owned)
    if conflicts:
        return {"status": "material_conflict", "action": "refuse",
                "reason": "project-owned AGENTS.md content carries material "
                          "authority/security/credential conflicts; adoption "
                          "is never declared successful over them — "
                          "reconcile with A",
                "conflicts": conflicts}
    if not blocks:
        # Minimal insert: preserve the project's bytes exactly, one blank
        # line of separation, then the canonical block.
        base = existing if existing.endswith("\n") else existing + "\n"
        if not base.endswith("\n\n"):
            base += "\n"
        return {"status": "adopted", "action": "write",
                "content": base + canonical + "\n",
                "block_version": block_version}
    found = blocks[0]
    if found["version"] == block_version:
        if found["text"] == canonical:
            return {"status": "current", "action": "none",
                    "block_version": block_version}
        # Same-version drift inside the managed region: the region is
        # Harry Dev-owned, so reconciliation restores the canonical block
        # while every byte outside it is preserved.
        content = existing[:found["begin"]] + canonical + \
            existing[found["end"]:]
        return {"status": "reconciled", "action": "write",
                "content": content, "block_version": block_version,
                "drift_reconciled": True}
    # Version differs: no-implicit-upgrade (AC4) — a newer (or older)
    # installed Skill never silently rewrites an adopted project's block.
    if not upgrade_selector:
        return {"status": "upgrade_required", "action": "refuse",
                "reason": "the adopted managed block is version "
                          f"v{found['version']} while the installed "
                          f"distribution ships v{block_version}; an "
                          "installed Skill never silently rewrites an "
                          "adopted project's managed block. Reconciliation "
                          "to a different block version is permitted only "
                          "when an explicit Harry Dev release upgrade has "
                          "ALREADY been authorized for this project through "
                          "its normal governance; `ght agents-adopt "
                          "--upgrade` is only the execution selector for "
                          "that already-authorized path — the flag is not "
                          "itself the authorization and never establishes "
                          "it",
                "existing_block_version": found["version"],
                "shipped_block_version": block_version}
    content = existing[:found["begin"]] + canonical + existing[found["end"]:]
    return {"status": "upgraded", "action": "write", "content": content,
            "block_version": block_version,
            "from_block_version": found["version"]}
