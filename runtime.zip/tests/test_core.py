"""Pure helper tests for the github-task v3 core (no network, no subprocess)."""

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[1]))

from github_task.core import (build_claim, claim_state, classify_paths, contract_digest,
                              new_claim_id, parse_contract)
from github_task.core import ContractError


CONTRACT = """```ght-contract
version: 1
intent: >
  A small runnable baseline.
acceptance:
  - id: AC1
    requirement: The CLI runs.
authority:
  implementation: allowed
depends_on: []
scope:
  forbidden:
    - template/**
```"""


def body_with(block: str) -> str:
    return f"# Title\n\nPlanning notes that are NOT part of the Contract.\n\n{block}\n"


class ParseContractTests(unittest.TestCase):
    def test_parses_valid_contract(self):
        contract = parse_contract(body_with(CONTRACT))
        self.assertEqual(contract["version"], 1)
        self.assertEqual(contract["authority"]["implementation"], "allowed")
        self.assertEqual(contract["scope"]["forbidden"], ["template/**"])
        self.assertEqual(contract["depends_on"], [])
        self.assertEqual(contract["acceptance"][0]["id"], "AC1")

    def test_requires_exactly_one_block(self):
        with self.assertRaises(ContractError):
            parse_contract("no block at all")
        with self.assertRaises(ContractError):
            parse_contract(body_with(CONTRACT) + "\n" + body_with(CONTRACT))

    def test_required_fields(self):
        block = CONTRACT.replace("intent: >\n  A small runnable baseline.\n", "")
        with self.assertRaises(ContractError):
            parse_contract(body_with(block))

    def test_authority_profiles(self):
        for profile in ("allowed", "investigation-only"):
            block = CONTRACT.replace("implementation: allowed", f"implementation: {profile}")
            contract = parse_contract(body_with(block))
            self.assertEqual(contract["authority"]["implementation"], profile)
        block = CONTRACT.replace("implementation: allowed", "implementation: whenever")
        with self.assertRaises(ContractError):
            parse_contract(body_with(block))

    def test_depends_on_accepts_numbers_and_hash_strings(self):
        block = CONTRACT.replace("depends_on: []", "depends_on:\n  - 4\n  - \"#7\"")
        self.assertEqual(parse_contract(body_with(block))["depends_on"], [4, "#7"])
        block = CONTRACT.replace("depends_on: []", 'depends_on: ["open issue"]')
        with self.assertRaises(ContractError):
            parse_contract(body_with(block))


class DigestTests(unittest.TestCase):
    def test_digest_is_canonical_and_stable(self):
        first = parse_contract(body_with(CONTRACT))
        second = parse_contract(body_with(CONTRACT))
        self.assertEqual(contract_digest(first), contract_digest(second))

    def test_semantic_change_changes_digest(self):
        first = parse_contract(body_with(CONTRACT))
        changed = parse_contract(body_with(CONTRACT.replace("The CLI runs.", "The CLI compiles.")))
        self.assertNotEqual(contract_digest(first), contract_digest(changed))

    def test_planning_metadata_outside_block_is_not_coupled(self):
        first = parse_contract(body_with(CONTRACT))
        noisy = body_with(CONTRACT).replace("Planning notes", "Edited planning notes")
        second = parse_contract(noisy)
        self.assertEqual(contract_digest(first), contract_digest(second))


class ClassifyPathsTests(unittest.TestCase):
    def test_forbidden_and_allowed(self):
        result = classify_paths(
            ["skills/github-task/x.py", "template/AGENTS.md", "docs/task-contract.md"],
            {"forbidden": ["template/**", "docs/task-contract.md"]})
        self.assertFalse(result["pass"])
        self.assertEqual(result["paths"]["template/AGENTS.md"], "FORBIDDEN")
        self.assertEqual(result["paths"]["docs/task-contract.md"], "FORBIDDEN")
        self.assertEqual(result["paths"]["skills/github-task/x.py"], "ALLOWED")
        self.assertEqual(result["counts"],
                         {"ALLOWED": 1, "FORBIDDEN": 2, "MAIN_ATTRIBUTED": 0})

    def test_no_scope_means_everything_allowed(self):
        result = classify_paths(["a/b.py"], None)
        self.assertTrue(result["pass"])
        self.assertEqual(result["counts"]["FORBIDDEN"], 0)


class AcceptedMainAttributionTests(unittest.TestCase):
    """#104 AC1/AC2: a candidate-diff path proven (mechanically, by the CLI
    layer) to carry only accepted-main movement is MAIN_ATTRIBUTED — never a
    violation — while every unproven forbidden path stays strictly closed."""

    def test_main_only_forbidden_path_is_attributed_not_violation(self):
        result = classify_paths(
            ["skills/github-task/x.py", "template/upstream.md"],
            {"forbidden": ["template/**"]},
            main_attributable={"template/upstream.md"})
        self.assertTrue(result["pass"])
        self.assertEqual(result["paths"]["template/upstream.md"], "MAIN_ATTRIBUTED")
        self.assertEqual(result["paths"]["skills/github-task/x.py"], "ALLOWED")
        self.assertEqual(result["main_attributed_paths"], ["template/upstream.md"])
        self.assertEqual(result["counts"],
                         {"ALLOWED": 1, "FORBIDDEN": 0, "MAIN_ATTRIBUTED": 1})
        self.assertEqual(result["violations"], [])

    def test_unproven_forbidden_path_stays_violation(self):
        result = classify_paths(
            ["template/upstream.md", "template/candidate.md"],
            {"forbidden": ["template/**"]},
            main_attributable={"template/upstream.md"})
        self.assertFalse(result["pass"])
        self.assertEqual(result["paths"]["template/upstream.md"], "MAIN_ATTRIBUTED")
        self.assertEqual(result["paths"]["template/candidate.md"], "FORBIDDEN")
        self.assertEqual(result["main_attributed_paths"], ["template/upstream.md"])
        self.assertEqual(result["counts"],
                         {"ALLOWED": 0, "FORBIDDEN": 1, "MAIN_ATTRIBUTED": 1})

    def test_attribution_is_narrow_and_inert_outside_forbidden_matches(self):
        # Without proven attribution the strict classification is unchanged.
        strict = classify_paths(["template/a.md"], {"forbidden": ["template/**"]})
        self.assertFalse(strict["pass"])
        self.assertEqual(strict["main_attributed_paths"], [])
        self.assertEqual(strict["counts"]["MAIN_ATTRIBUTED"], 0)
        # An attribution claim for a path that is not forbidden-matched is
        # inert: allowed paths stay ALLOWED and are never reported attributed.
        result = classify_paths(["skills/x.py"], {"forbidden": ["template/**"]},
                                main_attributable={"skills/x.py"})
        self.assertTrue(result["pass"])
        self.assertEqual(result["paths"]["skills/x.py"], "ALLOWED")
        self.assertEqual(result["main_attributed_paths"], [])


class ClaimStateTests(unittest.TestCase):
    def make(self, status="active", lease="2999-01-01T00:00:00Z"):
        return {"status": status, "lease_expires_at": lease,
                "claim_id": "x", "heartbeat_at": "2998-01-01T00:00:00Z"}

    def test_classification(self):
        self.assertEqual(claim_state(None), "NONE")
        self.assertEqual(claim_state(self.make()), "ACTIVE")
        self.assertEqual(claim_state(self.make(lease="2000-01-01T00:00:00Z")), "STALE")
        for status in ("delivered", "investigated", "blocked"):
            self.assertEqual(claim_state(self.make(status=status)), "TERMINAL")
        self.assertEqual(claim_state(self.make(lease="not-a-date")), "STALE")


class BuildClaimTests(unittest.TestCase):
    def test_record_has_identity_lineage_and_no_deprecated_fields(self):
        contract = parse_contract(body_with(CONTRACT))
        claim = build_claim(issue=10, github_principal="acct", executor_id="worker-1",
                            execution_base="ad3b658", branch="agent/10/abc", contract=contract,
                            now="2026-09-16T10:00:00Z", lease_expires_at="2026-09-16T10:45:00Z")
        self.assertEqual(claim["v"], 3)
        self.assertEqual(claim["executor_id"], "worker-1")
        self.assertEqual(claim["github_principal"], "acct")
        self.assertEqual(claim["contract_digest"], contract_digest(contract))
        self.assertTrue(claim["claim_id"].startswith("worker-1-"))
        for banned in ("policy_digest", "lane", "preferred_lane", "mode", "promotion",
                       "plan_gate"):
            self.assertNotIn(banned, claim)
        self.assertIsNone(claim["supersedes"],
                          "build_claim without a prior records no supersedes")

    def test_claim_ids_are_unique(self):
        from github_task.core import parse_contract as pc
        contract = pc(body_with(CONTRACT))
        one = new_claim_id("worker-1", __import__("datetime").datetime(2026, 9, 16, 10, 0, 0))
        two = new_claim_id("worker-1", __import__("datetime").datetime(2026, 9, 16, 10, 0, 0))
        self.assertNotEqual(one, two)


if __name__ == "__main__":
    unittest.main()
