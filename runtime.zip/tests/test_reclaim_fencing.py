"""Destructive-boundary reclaim fencing regression for #147 (R2).

The cleanup removal of an execution resource is authorized by an atomic
ght-side CAS transition on the Issue's canonical claim ref — the same CAS
domain every capacity-establishing transition (``ght claim`` / ``ght
acquire`` / takeover / renewal) must win to become valid. Between
authorization and the destructive ``git worktree remove`` no ACTIVE
transition can become valid: either the transition won the ref first
(authorization is refused — the caller's expected claim_sha no longer
anchors) or the pending-reclaim marker holds and claim/acquire fail
closed until the removal confirms.
"""

import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SKILL_ROOT = Path(__file__).parents[1]
CLI = SKILL_ROOT / "scripts" / "ght.py"
REAL_GIT = shutil.which("git")
sys.path.insert(0, str(SKILL_ROOT))
sys.path.insert(0, str(SKILL_ROOT / "tests"))

from test_cli_safety import MOCK_GH, GIT_WRAPPER, IMPL_CONTRACT, issue_body  # noqa: E402


class ReclaimExecutionResourceFencingTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="ght-reclaim-fencing-"))
        self.origin = self.tmp / "origin.git"
        self.state = self.tmp / "issues.json"
        self.bin = self.tmp / "bin"
        self.bin.mkdir()
        self._write_executable(self.bin / "gh", MOCK_GH)
        self._write_executable(self.bin / "git", GIT_WRAPPER)
        self._git(self.tmp, "init", "--bare", str(self.origin), "-b", "main")
        seed = self.tmp / "seed"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(seed))
        (seed / "README.md").write_text("seed\n")
        self._git(seed, "add", ".")
        self._git(seed, "-c", "user.email=t@t", "-c", "user.name=t", "commit", "-qm", "seed")
        self._git(seed, "push", "-q", "origin", "HEAD:main")
        self.repo = self.tmp / "worker"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(self.repo))
        self._git(self.repo, "config", "user.email", "w@t")
        self._git(self.repo, "config", "user.name", "w")
        self.state.write_text(json.dumps({
            "10": {"number": 10, "title": "Task ten", "state": "OPEN",
                   "url": "https://github.com/example/repo/issues/10",
                   "body": issue_body(IMPL_CONTRACT), "labels": ["ready"], "comments": []},
            "15": {"number": 15, "title": "Task fifteen", "state": "OPEN",
                   "url": "https://github.com/example/repo/issues/15",
                   "body": issue_body(IMPL_CONTRACT), "labels": ["ready"], "comments": []},
        }, indent=2))
        self._env = {
            "PATH": f"{self.bin}:{os.environ['PATH']}",
            "GHT_TEST_STATE": str(self.state),
            "GHT_TEST_REAL_GIT": REAL_GIT,
            "GHT_EXECUTOR_ID": "worker-1",
            "GHT_LEASE_MINUTES": "45",
            "GHT_SPAWN_SUPERVISOR": "0",
            "GIT_AUTHOR_NAME": "w", "GIT_AUTHOR_EMAIL": "w@t",
            "GIT_COMMITTER_NAME": "w", "GIT_COMMITTER_EMAIL": "w@t",
        }
        self._activate_runtime_pin()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _activate_runtime_pin(self):
        import github_task.cli as ght_cli
        payload, manifest = ght_cli._runtime_capsule_payload(SKILL_ROOT)
        manifest["release"] = "v1.0.3"
        manifest["source_sha"] = "f" * 40
        payload_file = self.tmp / "pin-runtime.zip"
        payload_file.write_bytes(payload)
        payload_blob = self._git(self.repo, "hash-object", "-w",
                                 str(payload_file)).stdout.strip()
        manifest_blob = self._git(self.repo, "hash-object", "-w", "--stdin",
                                  input_text=json.dumps(
                                      manifest, sort_keys=True)).stdout.strip()
        tree = self._git(self.repo, "mktree", input_text=(
            f"100644 blob {payload_blob}\truntime.zip\n"
            f"100644 blob {manifest_blob}\tMANIFEST.json\n")).stdout.strip()
        identity_env = {**os.environ,
                        "GIT_AUTHOR_NAME": "ght", "GIT_AUTHOR_EMAIL": "ght@harry-dev",
                        "GIT_COMMITTER_NAME": "ght", "GIT_COMMITTER_EMAIL": "ght@harry-dev"}
        commit = self._git(self.repo, "commit-tree", tree,
                           "-m", "fixture runtime capsule",
                           env=identity_env).stdout.strip()
        for ref in ("refs/ght/runtime/current", f"refs/ght/runtime/{manifest['digest']}"):
            pushed = self._git(self.repo, "push", "-q", "origin", f"{commit}:{ref}")
            self.assertEqual(pushed.returncode, 0, pushed.stdout + pushed.stderr)

    # -- helpers --------------------------------------------------------

    def _write_executable(self, path, content):
        path.write_text(content)
        path.chmod(path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    def _git(self, cwd, *args, env=None, input_text=None):
        return subprocess.run([REAL_GIT, *args], cwd=cwd, capture_output=True, text=True,
                              env=env or {**os.environ}, input=input_text)

    def _ght(self, *args, env_extra=None):
        env = {**self._env, **(env_extra or {})}
        return subprocess.run([sys.executable, str(CLI), "--json", *args],
                              cwd=str(self.repo), capture_output=True, text=True, env=env)

    def _ght_ok(self, *args, env_extra=None):
        result = self._ght(*args, env_extra=env_extra)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        return json.loads(result.stdout)

    def _ght_fail(self, *args, env_extra=None):
        result = self._ght(*args, env_extra=env_extra)
        self.assertNotEqual(result.returncode, 0,
                            f"expected failure, got: {result.stdout} {result.stderr}")
        return result.stdout + result.stderr

    def _update_issue(self, number, **changes):
        data = json.loads(self.state.read_text())
        data[str(number)].update(changes)
        self.state.write_text(json.dumps(data, indent=2))

    def _inspect(self, number):
        return self._ght_ok("inspect", str(number))

    def _claim(self, number=10):
        return self._ght_ok("claim", str(number))

    def _parked(self, number=10, pr=60):
        """Drive one attempt to the parked condition: durable Candidate
        delivery, capacity released, attempt still non-terminal."""
        claim = self._claim(number)
        self._git(self.repo, "checkout", "-q", "-b", claim["branch"], "origin/main")
        path = self.repo / "skills" / "demo.txt"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("demo\n")
        self._git(self.repo, "add", "skills/demo.txt")
        self._git(self.repo, "commit", "-qm", "add demo")
        sha = self._git(self.repo, "rev-parse", "HEAD").stdout.strip()
        self._ght_ok("preserve", str(number))
        self.state.write_text(json.dumps({
            **json.loads(self.state.read_text()),
            str(pr): {"number": pr, "is_pr": True, "state": "OPEN",
                      "url": f"https://github.com/example/repo/pull/{pr}",
                      "headRefName": claim["branch"], "headRefOid": sha,
                      "mergeCommit": None, "reviews": [], "pr_comments": []},
        }, indent=2))
        self._ght_ok("deliver", str(number), "--pr", str(pr))
        return claim, sha

    def _authorize(self, number, sha, env_extra=None):
        return self._ght("reclaim-execution-resource", str(number),
                         "--expect-claim-sha", sha or "", env_extra=env_extra)

    def _authorize_ok(self, number, sha, env_extra=None):
        result = self._authorize(number, sha, env_extra=env_extra)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        return json.loads(result.stdout)

    def _confirm(self, number, sha, env_extra=None):
        return self._ght("reclaim-execution-resource", str(number), "--confirm-removal",
                         "--expect-claim-sha", sha or "", env_extra=env_extra)

    def _marker_present(self, number):
        claim = self._inspect(number).get("claim")
        return isinstance(claim, dict) and bool(claim.get("resource_reclaim"))

    # -- authorization semantics ---------------------------------------

    def test_authorize_appends_pending_reclaim_marker_to_parked_lineage(self):
        # A parked (delivered, capacity released) attempt is cleanup-eligible;
        # authorize CAS-appends the marker onto the claim ref and the marker
        # commit becomes the current claim_sha.
        self._parked(10)
        sha = self._inspect(10)["claim_sha"]
        payload = self._authorize_ok(10, sha)
        self.assertNotEqual(payload["marker_sha"], sha)
        self.assertEqual(self._inspect(10)["claim_sha"], payload["marker_sha"])
        self.assertTrue(self._marker_present(10))

    def test_authorize_with_moved_claim_sha_fails_closed_without_marker(self):
        # The caller's expected claim_sha no longer anchors the ref head:
        # canonical ownership moved since the eligibility read — the stale
        # decision is voided, no marker is written, the ref does not move.
        self._parked(10)
        stale = self._inspect(10)["claim_sha"]
        self._ght_ok("acquire", "10")  # capacity re-established after the read
        current = self._inspect(10)["claim_sha"]
        self.assertNotEqual(current, stale)
        self._ght_fail("reclaim-execution-resource", "10", "--expect-claim-sha", stale)
        self.assertFalse(self._marker_present(10))
        self.assertEqual(self._inspect(10)["claim_sha"], current)

    def test_pending_marker_blocks_acquire_of_parked_attempt(self):
        # The mechanical exclusion: while the marker holds, the review-resume
        # path cannot re-establish execution capacity for the Issue.
        self._parked(10)
        sha = self._inspect(10)["claim_sha"]
        self._authorize_ok(10, sha)
        output = self._ght_fail("acquire", "10")
        self.assertIn("reclaim", output)

    def test_confirm_clears_marker_and_review_resume_succeeds(self):
        # The fence is temporary: after the removal confirms (CAS-anchored on
        # the marker commit), the same attempt acquires a fresh fencing
        # identity again.
        self._parked(10)
        sha = self._inspect(10)["claim_sha"]
        marker = self._authorize_ok(10, sha)["marker_sha"]
        self._ght_ok("reclaim-execution-resource", "10", "--confirm-removal",
                     "--expect-claim-sha", marker)
        self.assertFalse(self._marker_present(10))
        reacquired = self._ght_ok("acquire", "10")
        self.assertNotEqual(reacquired["execution_lease"]["fencing_token"], "")

    def test_confirm_with_stale_anchor_fails_and_marker_survives(self):
        self._parked(10)
        sha = self._inspect(10)["claim_sha"]
        self._authorize_ok(10, sha)
        self._ght_fail("reclaim-execution-resource", "10", "--confirm-removal",
                       "--expect-claim-sha", "0" * 40)
        self.assertTrue(self._marker_present(10))

    def test_pending_marker_blocks_new_claim_over_completed_terminal_lineage(self):
        # A terminal lineage would normally accept a fresh authorized start;
        # while the removal marker holds, the new attempt fails closed.
        _claim_rec, candidate_sha = self._parked(10)
        sha = self._inspect(10)["claim_sha"]
        marker = self._authorize_ok(10, sha)["marker_sha"]
        data = json.loads(self.state.read_text())
        data["60"].update({"state": "MERGED",
                           "mergeCommit": {"oid": "mergesha0000000000000000000000000000000"},
                           "pr_comments": [{"body": "A REVIEW — ACCEPTED\n\nReviewed "
                                                    "exact Candidate:\n`" + candidate_sha + "`\n"}]})
        data["10"]["labels"] = ["ready"]
        self.state.write_text(json.dumps(data, indent=2))
        self._ght_ok("complete", "10", "--pr", "60")
        # #171: the canonical completion now converges the Issue itself
        # (mechanical close of the proven A acceptance) before any later
        # claim can be considered.
        self.assertEqual(json.loads(self.state.read_text())["10"]["state"], "CLOSED")
        # A reopens the Issue for more work (the marker survived completion):
        # the pending removal fence — not the Issue state — is what blocks
        # the fresh start now.
        data = json.loads(self.state.read_text())
        data["10"].update({"state": "OPEN", "stateReason": None, "labels": ["ready"]})
        self.state.write_text(json.dumps(data, indent=2))
        output = self._ght_fail("claim", "10")
        self.assertIn("reclaim", output)
        # Confirm restores the normal start semantics.
        self._ght_ok("reclaim-execution-resource", "10", "--confirm-removal",
                     "--expect-claim-sha", self._inspect(10)["claim_sha"])
        self._ght_ok("claim", "10")

    def test_authorize_refuses_current_active_execution_resource(self):
        # An in-flight attempt (live capacity, no delivery) is never
        # cleanup-eligible — authorize refuses before any marker is written.
        self._claim(10)
        sha = self._inspect(10)["claim_sha"]
        self._ght_fail("reclaim-execution-resource", "10", "--expect-claim-sha", sha)
        self.assertFalse(self._marker_present(10))

    # -- true-orphan tombstone semantics --------------------------------

    def test_orphan_authorize_creates_tombstone_that_blocks_fresh_claim(self):
        # A true orphan has no claim lineage; authorize CAS-creates a reclaim
        # tombstone (empty expect-lease) so a concurrent fresh claim for the
        # same Issue cannot become ACTIVE before the removal lands.
        self._ght_fail("reclaim-execution-resource", "15", "--expect-claim-sha",
                       "nonexistent-anchor")
        self.assertEqual(self._inspect(15)["claim"], "none")
        payload = self._authorize_ok(15, None)
        self.assertTrue(payload["tombstone"])
        self.assertEqual(self._inspect(15)["claim_sha"], payload["marker_sha"])
        self.assertTrue(self._marker_present(15))
        output = self._ght_fail("claim", "15")
        self.assertIn("reclaim", output)

    def test_orphan_confirm_deletes_tombstone_and_fresh_claim_succeeds(self):
        self._authorize_ok(15, None)
        marker = self._inspect(15)["claim_sha"]
        self._ght_ok("reclaim-execution-resource", "15", "--confirm-removal",
                     "--expect-claim-sha", marker)
        self.assertEqual(self._inspect(15)["claim"], "none")
        self._ght_ok("claim", "15")

    def test_orphan_authorize_is_idempotent_while_marker_is_current(self):
        # An interrupted cleanup (authorized, crashed before removal) can be
        # re-run: re-authorizing against the unchanged marker head re-emits
        # the marker anchor instead of wedging.
        first = self._authorize_ok(15, None)
        again = self._authorize_ok(15, first["marker_sha"])
        self.assertEqual(again["marker_sha"], first["marker_sha"])
        self.assertTrue(again.get("idempotent"))

    def test_orphan_authorize_refuses_stale_anchor_when_lineage_appeared(self):
        # The eligibility read saw no lineage, but a claim appeared before
        # authorize: the empty expect-lease create must lose the race and
        # fail closed instead of tombstoning a live lineage.
        first = self._authorize_ok(15, None)
        marker = self._inspect(15)["claim_sha"]
        self.assertEqual(first["marker_sha"], marker)
        # Simulate the orphan read happening before a lineage appears: a
        # second orphan authorize anchored on "absent" must refuse now.
        self._ght_fail("reclaim-execution-resource", "15", "--expect-claim-sha",
                       "orphan-read-sha")
        self.assertEqual(self._inspect(15)["claim_sha"], marker)


if __name__ == "__main__":
    unittest.main()
