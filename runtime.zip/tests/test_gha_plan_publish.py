"""Targeted validation for the A-side remote Execution Plan publication (#82).

The surface is deliberately thin glue: A commits the complete Plan payload
to the repository through GitHub's remote surface, then a workflow_dispatch
hands the payload PATH verbatim to the canonical `ght plan-publish`
primitive. These tests bind the workflow trigger/permission contract and
the glue's input validation / argv assembly / payload non-mutation /
fail-closed propagation. #156: the argv assembly always carries
`--bind-contract-digests`, so a digest-free remote-A scheduling decision is
mechanically bound by ght itself at publication time (no-op for fully
bound payloads). Plan semantics themselves (v1 schema, immutable
revisions, exact-prior CAS, plan_id stability) stay owned and tested by the
runtime suite via the canonical primitive.
"""

import json
import os
import stat
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SKILL_ROOT = Path(__file__).parents[1]
WORKFLOW = SKILL_ROOT.parent.parent / ".github" / "workflows" / "ght-plan-publish.yml"
GLUE = SKILL_ROOT / "scripts" / "ght-plan-publish.sh"
CLI = SKILL_ROOT / "scripts" / "ght.py"

PLAN_PAYLOAD = (
    '{"plan_id": "backlog-2026-09", "revision": "v1", "nodes": ['
    '{"issue": 75, "priority": 10}, {"issue": 66, "priority": 5}]}'
)

# #91: the canonical publish primitive fresh-reads every node's Issue
# Contract, so the integration fixture carries a real readable Issue whose
# digest is produced by the same canonical primitive the runtime uses.
CONTRACT_BODY = """## Dogfood binding issue

```ght-contract
version: 1

intent: >
  Bind the Plan node digest mechanically to this Issue Contract.

authority:
  implementation: allowed

acceptance:
  - id: AC1
    requirement: >
      The Plan node carries the canonical digest of this Contract.
```
"""


def _canonical_digest() -> str:
    from github_task.core import contract_digest, parse_contract
    return contract_digest(parse_contract(CONTRACT_BODY))


def run_glue(*args, env_extra=None, cwd=None):
    env = {"PATH": "/usr/bin:/bin"}
    env.update(env_extra or {})
    return subprocess.run(["sh", str(GLUE), *args],
                          capture_output=True, text=True, env=env, cwd=cwd)


def integration_env(base: Path) -> dict:
    """Environment for runs that reach the REAL ght runtime: a stub `gh`
    (principal() softly resolves to None, exactly like a credentialless
    runner) and a current interpreter for the bundled ght.py."""
    fake_bin = base / "bin"
    fake_bin.mkdir(exist_ok=True)
    gh = fake_bin / "gh"
    # Credentialless principal (`gh api user` fails) exactly like a real
    # GITHUB_TOKEN runner, but Issue reads succeed so the #91 digest-
    # binding gate can fresh-read the fixture Contract.
    gh.write_text(
        "#!/usr/bin/env python3\n"
        "import json, os, sys\n"
        "args = sys.argv[1:]\n"
        "if (args[:3] == ['issue', 'view', '75']\n"
        "        and not os.environ.get('GHT_TEST_ISSUE_75_UNREADABLE')):\n"
        "    print(json.dumps({\n"
        "        'number': 75, 'title': 'Dogfood binding issue',\n"
        "        'state': 'OPEN', 'stateReason': None,\n"
        "        'url': 'https://github.com/example/repo/issues/75',\n"
        "        'labels': [], 'assignees': [], 'comments': [],\n"
        "        'body': os.environ['GHT_TEST_ISSUE_75_BODY']}))\n"
        "    sys.exit(0)\n"
        "sys.exit(1)\n")
    gh.chmod(gh.stat().st_mode | stat.S_IXUSR)
    # Production-equivalent CLEAN RUNNER identity: no global/system git
    # config and no inherited identity env — commit-tree must succeed purely
    # through the runtime's explicit publisher identity.
    env = {"PATH": f"{fake_bin}:/usr/bin:/bin",
           "GHT_PLAN_PUBLISH_PYTHON": sys.executable,
           "GHT_TEST_ISSUE_75_BODY": CONTRACT_BODY,
           "GIT_CONFIG_GLOBAL": "/dev/null",
           "GIT_CONFIG_SYSTEM": "/dev/null",
           # Installation-token condition: `gh api user` cannot answer, so
           # the canonical publication path carries the machine identity.
           "GHT_PLAN_PUBLISHER_ID": "ght-plan-publish-workflow"}
    for var in ("GIT_AUTHOR_NAME", "GIT_AUTHOR_EMAIL", "GIT_COMMITTER_NAME",
                "GIT_COMMITTER_EMAIL", "EMAIL"):
        env.pop(var, None)
    return env


def write_stub(path: Path, body: str):
    path.write_text("#!/usr/bin/env python3\n" + body)
    path.chmod(path.stat().st_mode | stat.S_IXUSR)


class GhaPlanPublishSurfaceTests(unittest.TestCase):
    def test_workflow_and_glue_exist_with_executable_glue(self):
        self.assertTrue(WORKFLOW.exists(), "remote publication workflow is missing")
        self.assertTrue(GLUE.exists(), "publication glue is missing")
        self.assertTrue(GLUE.stat().st_mode & stat.S_IXUSR,
                        "glue script must be executable")

    def test_workflow_routes_only_through_the_glue_with_minimal_permissions(self):
        # #82 AC1/AC6: a GitHub-native dispatch surface A can drive from a
        # remote host; the workflow only routes through the glue into the
        # canonical primitive and carries the minimal permissions it needs.
        text = WORKFLOW.read_text()
        # Normal remote-A trigger (#82 review): a plain contents write — the
        # push of the committed payload publishes it; no dispatch mutation,
        # no local checkout, no gh CLI needed.
        self.assertIn("push:", text)
        self.assertIn("branches: [main]", text)
        # One-to-one binding (#82 review): the trigger fires only on the
        # designated payload file — unrelated docs/plans/** writes never
        # publish a stale or different payload.
        self.assertIn("paths: ['docs/plans/current-plan.yaml']", text)
        self.assertNotIn("docs/plans/**", text)
        self.assertIn("workflow_dispatch:", text)
        self.assertIn("plan_path:", text)
        self.assertIn("replace_revision:", text)
        self.assertIn("ght-plan-publish.sh", text)
        self.assertIn("--replace-current", text,
                      "the push path resolves the exact prior revision mechanically")
        self.assertNotIn("ght.py", text,
                         "the workflow must not invoke ght.py directly")
        self.assertNotIn("gh api", text,
                         "no duplicated Plan logic via raw API calls")
        self.assertIn("permissions:", text)
        self.assertIn("contents: write", text)
        # #91 R2: the mandatory fresh-read digest gate needs the minimum
        # Issue READ surface on a real runner (unspecified scopes are none
        # under GHA permission semantics) — no Issue write, no PR surface.
        self.assertIn("issues: read", text,
                      "the digest gate fresh-reads Issue Contracts on the runner")
        self.assertNotIn("issues: write", text,
                         "no Issue write surface")
        self.assertNotIn("pull-requests:", text,
                         "publication needs no PR surface")
        self.assertEqual(text.count("set -euo pipefail"), 1)
        self.assertIn("$GITHUB_STEP_SUMMARY", text,
                      "success exposes the exact revision + plan_id durably")

    def test_first_publish_invokes_canonical_primitive_with_exact_argv(self):
        # #82 AC2/AC4: the payload path is handed verbatim to the canonical
        # primitive; the glue invents no scheduling content and adds no
        # replacement.
        with tempfile.TemporaryDirectory() as tmp:
            payload = Path(tmp) / "plan.json"
            payload.write_text(PLAN_PAYLOAD)
            stub = Path(tmp) / "ght-stub.py"
            marker = Path(tmp) / "invocation.json"
            write_stub(stub,
                       "import json, os, sys\n"
                       "open(os.environ['GHT_STUB_OUT'], 'w').write("
                       "json.dumps(sys.argv[1:]))\n"
                       "print(json.dumps({'plan_id': 'p', 'revision': 'a' * 40}))\n")
            result = run_glue(str(payload), env_extra={
                "GHT_PLAN_PUBLISH_GHT_BIN": str(stub),
                "GHT_STUB_OUT": str(marker)})
            self.assertEqual(result.returncode, 0, result.stderr)
            # #156: the canonical invocation always carries the mechanical
            # Contract-binding flag (a no-op for fully bound payloads).
            self.assertEqual(json.loads(marker.read_text()),
                             ["--json", "plan-publish", str(payload),
                              "--bind-contract-digests"])

    def test_replacement_passes_exact_prior_revision_to_the_primitive(self):
        # #82 AC3: replacement keeps the canonical exact-prior CAS semantics —
        # the glue forwards --replace untouched and never retries or mends.
        with tempfile.TemporaryDirectory() as tmp:
            payload = Path(tmp) / "plan.json"
            payload.write_text(PLAN_PAYLOAD)
            stub = Path(tmp) / "ght-stub.py"
            marker = Path(tmp) / "invocation.json"
            write_stub(stub,
                       "import json, os, sys\n"
                       "open(os.environ['GHT_STUB_OUT'], 'w').write("
                       "json.dumps(sys.argv[1:]))\n"
                       "print(json.dumps({'plan_id': 'p', 'revision': 'b' * 40}))\n")
            result = run_glue(str(payload), "--replace", "a" * 40, env_extra={
                "GHT_PLAN_PUBLISH_GHT_BIN": str(stub),
                "GHT_STUB_OUT": str(marker)})
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(marker.read_text()),
                             ["--json", "plan-publish", str(payload),
                              "--bind-contract-digests",
                              "--replace", "a" * 40])

    def test_glue_never_mutates_the_payload(self):
        # #82 AC2/AC4: publication executes exactly the payload A gave — the
        # file bytes are identical after the run, and a stub read through the
        # argv path sees the same content.
        with tempfile.TemporaryDirectory() as tmp:
            payload = Path(tmp) / "plan.json"
            payload.write_text(PLAN_PAYLOAD)
            stub = Path(tmp) / "ght-stub.py"
            seen = Path(tmp) / "seen.json"
            write_stub(stub,
                       "import json, os, sys\n"
                       "open(os.environ['GHT_STUB_ARGV'], 'w').write("
                       "json.dumps(sys.argv[1:]))\n"
                       "plan_path = sys.argv[3]\n"
                       "open(os.environ['GHT_STUB_SEEN'], 'w').write(open(plan_path).read())\n"
                       "print(json.dumps({'plan_id': 'p', 'revision': 'c' * 40}))\n")
            argv_marker = Path(tmp) / "argv.json"
            result = run_glue(str(payload), env_extra={
                "GHT_PLAN_PUBLISH_GHT_BIN": str(stub),
                "GHT_STUB_SEEN": str(seen),
                "GHT_STUB_ARGV": str(argv_marker)})
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(argv_marker.read_text()),
                             ["--json", "plan-publish", str(payload),
                              "--bind-contract-digests"],
                             "#156: binding rides the same canonical invocation")
            self.assertEqual(seen.read_text(), PLAN_PAYLOAD,
                             "the primitive must see the exact A-provided payload")
            self.assertEqual(payload.read_text(), PLAN_PAYLOAD,
                             "the glue must leave the payload bytes untouched")

    def test_primitive_failure_propagates_fail_closed_with_diagnostics(self):
        # #82 AC3/AC5: invalid plans, stale CAS replacements, and unreadable
        # durable truth all fail through the primitive unchanged — the glue
        # adds no remediation and leaves no fake success output.
        with tempfile.TemporaryDirectory() as tmp:
            payload = Path(tmp) / "plan.json"
            payload.write_text(PLAN_PAYLOAD)
            stub = Path(tmp) / "ght-fail.py"
            write_stub(stub,
                       "import sys\n"
                       "print('{\"ok\": false, \"error\": \"CAS mismatch: current "
                       "Execution Plan pointer is 123456789abc, expected "
                       "abcdefabcdef; fail-closed\"}', file=sys.stderr)\n"
                       "raise SystemExit(5)\n")
            result = run_glue(str(payload), "--replace", "a" * 40, env_extra={
                "GHT_PLAN_PUBLISH_GHT_BIN": str(stub)})
            self.assertEqual(result.returncode, 5,
                             "the primitive's fail-closed exit code must propagate")
            self.assertIn("CAS mismatch", result.stderr)
            self.assertIn("fail-closed", result.stderr)


    def _git(self, *args, cwd):
        env = {**os.environ, "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t",
               "GIT_COMMITTER_NAME": "t", "GIT_COMMITTER_EMAIL": "t@t"}
        return subprocess.run(["git", *args], cwd=str(cwd),
                              capture_output=True, text=True, env=env)

    def _make_repo(self, base: Path) -> Path:
        """A bare origin plus a real checkout standing in for the Actions
        runner's workspace (real git remote, real push credentials)."""
        origin = base / "origin.git"
        subprocess.run(["git", "init", "--bare", "-q", str(origin)], check=True)
        clone = base / "clone"
        subprocess.run(["git", "clone", "-q", str(origin), str(clone)], check=True)
        (clone / "README.md").write_text("init\n")
        self._git("add", "-A", cwd=clone)
        self._git("commit", "-qm", "init", cwd=clone)
        pushed = self._git("push", "-q", "origin", "HEAD", cwd=clone)
        self.assertEqual(pushed.returncode, 0, pushed.stderr)
        return clone

    def _write_payload(self, clone: Path, digest: str, plan_id="backlog-integration") -> Path:
        payload = clone / "docs" / "plans"
        payload.mkdir(parents=True, exist_ok=True)
        plan = {"version": 1, "plan_id": plan_id,
                "nodes": [{"issue": 75, "contract_digest": digest,
                           "authorization_id": "plan-75", "priority": 10}]}
        target = payload / "current-plan.yaml"
        target.write_text(json.dumps(plan))
        return target

    def test_replace_current_resolves_exact_prior_revision(self):
        # The --replace-current mode reads the current pointer from durable
        # remote truth and forwards it as the exact-prior CAS replacement;
        # an absent pointer resolves to the canonical first-publish path.
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            clone = self._make_repo(base)
            payload = self._write_payload(clone, _canonical_digest())
            self._git("add", "-A", cwd=clone)
            self._git("commit", "-qm", "plan", cwd=clone)
            stub = base / "ght-stub.py"
            marker = base / "invocation.json"
            write_stub(stub,
                       "import json, os, sys\n"
                       "open(os.environ['GHT_STUB_OUT'], 'w').write("
                       "json.dumps(sys.argv[1:]))\n"
                       "print(json.dumps({'plan_id': 'p', 'revision': 'b' * 40}))\n")
            # No pointer yet -> first publish (no --replace in argv).
            result = run_glue(str(payload), "--replace-current", cwd=clone,
                              env_extra={"GHT_PLAN_PUBLISH_GHT_BIN": str(stub),
                                         "GHT_STUB_OUT": str(marker)})
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(marker.read_text()),
                             ["--json", "plan-publish", str(payload),
                              "--bind-contract-digests"])
            # Publish a real pointer, commit again, and the exact current
            # revision is forwarded as the CAS replacement.
            head = self._git("rev-parse", "HEAD", cwd=clone).stdout.strip()
            self._git("push", "-q", "origin",
                      f"{head}:refs/ght/plans/current", cwd=clone)
            result = run_glue(str(payload), "--replace-current", cwd=clone,
                              env_extra={"GHT_PLAN_PUBLISH_GHT_BIN": str(stub),
                                         "GHT_STUB_OUT": str(marker)})
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(marker.read_text()),
                             ["--json", "plan-publish", str(payload),
                              "--bind-contract-digests", "--replace", head])

    def test_integration_real_primitive_publish_and_cas_replacement(self):
        # #82 review verification gap: an integration-level proof that the
        # remote glue reaches the REAL canonical `ght plan-publish` path —
        # valid payload publishes (exact revision exposed, durable pointer
        # confirmed from remote truth), a second commit replaces it as a new
        # immutable revision, and a stale replacement fails closed with the
        # primitive's own CAS diagnostics.
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            clone = self._make_repo(base)
            payload = self._write_payload(clone, _canonical_digest())
            self._git("add", "-A", cwd=clone)
            self._git("commit", "-qm", "plan v1", cwd=clone)
            result = run_glue(str(payload), "--replace-current", cwd=clone,
                              env_extra=integration_env(base))
            self.assertEqual(result.returncode, 0, result.stderr)
            first = json.loads(result.stdout)
            self.assertEqual(first["plan_id"], "backlog-integration")
            self.assertEqual(len(first["revision"]), 40)
            self.assertEqual(first["nodes"], 1)
            remote = self._git("ls-remote", "origin",
                               "refs/ght/plans/current", cwd=clone).stdout.split()
            self.assertEqual(remote[0], first["revision"],
                             "the durable pointer confirms the exact published revision")
            author = self._git("log", "-1", "--format=%an <%ae>",
                               first["revision"], cwd=clone).stdout.strip()
            self.assertEqual(
                author,
                "ght-plan-publish-workflow <ght-plan-publish-workflow@ght>",
                "the revision records the machine publisher identity")
            # Second publication: A updates the payload; the exact current
            # revision is replaced by a new immutable child revision.
            payload.write_text(json.dumps(
                {"version": 1, "plan_id": "backlog-integration",
                 "nodes": [{"issue": 75, "contract_digest": _canonical_digest(),
                            "authorization_id": "plan-75", "priority": 10}]}))
            self._git("add", "-A", cwd=clone)
            self._git("commit", "-qm", "plan v2", cwd=clone)
            result = run_glue(str(payload), "--replace-current", cwd=clone,
                              env_extra=integration_env(base))
            self.assertEqual(result.returncode, 0, result.stderr)
            second = json.loads(result.stdout)
            self.assertEqual(second["plan_id"], "backlog-integration",
                             "plan identity stays stable across revisions")
            self.assertNotEqual(second["revision"], first["revision"])
            self.assertEqual(second["replaced"], first["revision"])
            remote = self._git("ls-remote", "origin",
                               "refs/ght/plans/current", cwd=clone).stdout.split()
            self.assertEqual(remote[0], second["revision"])
            # Stale replacement: an explicit wrong prior fails closed with
            # the canonical CAS diagnostics — no glue-level repair.
            stale = run_glue(str(payload), "--replace", "e" * 40, cwd=clone,
                             env_extra=integration_env(base))
            self.assertNotEqual(stale.returncode, 0)
            self.assertIn("CAS mismatch", stale.stdout + stale.stderr)

    def test_unreadable_issue_read_fails_publication_closed(self):
        # #91 R2 (AC5): a genuinely unreadable Issue read — what a runner
        # token WITHOUT issues:read produces — fails the whole publication
        # closed with the pointer never appearing. Distinct from the
        # invalid-Contract and stale-CAS cases above.
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            clone = self._make_repo(base)
            payload = self._write_payload(clone, _canonical_digest())
            self._git("add", "-A", cwd=clone)
            self._git("commit", "-qm", "plan", cwd=clone)
            env = integration_env(base)
            env["GHT_TEST_ISSUE_75_UNREADABLE"] = "1"
            result = run_glue(str(payload), "--replace-current", cwd=clone,
                              env_extra=env)
            self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertEqual(
                self._git("ls-remote", "origin", "refs/ght/plans/current",
                          cwd=clone).stdout.strip(),
                "", "an unreadable Issue read must never publish a pointer")


    def _run_ght(self, base, args, cwd, extra_env=None):
        env = integration_env(base)
        env.update(extra_env or {})
        return subprocess.run([sys.executable, str(CLI), "--json", *args],
                              cwd=str(cwd), capture_output=True, text=True,
                              env=env)

    def test_publisher_machine_identity_is_plan_publish_only(self):
        # #82/#69 pattern: GHT_PLAN_PUBLISHER_ID carries the publication
        # event under an installation credential and is refused on every
        # other command; the reconciler identity stays completion-only.
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            clone = self._make_repo(base)
            payload = self._write_payload(clone, _canonical_digest())
            self._git("add", "-A", cwd=clone)
            self._git("commit", "-qm", "plan", cwd=clone)
            result = self._run_ght(base, ["plan-publish", str(payload)], clone)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertEqual(json.loads(result.stdout)["plan_id"],
                             "backlog-integration")
            # The same identity cannot reach any other command.
            refused = self._run_ght(base, ["status"], clone)
            self.assertNotEqual(refused.returncode, 0)
            self.assertIn("Plan-publication-only", refused.stdout)
            # The completion-only reconciler identity is still refused for
            # plan-publish — no identity overlap.
            mixed = self._run_ght(base, ["plan-publish", str(payload)], clone,
                                  extra_env={"GHT_RECONCILER_ID": "ght-complete-workflow",
                                             "GHT_PLAN_PUBLISHER_ID": ""})
            self.assertNotEqual(mixed.returncode, 0)
            self.assertIn("completion-only", mixed.stdout)

    def test_glue_fails_closed_on_missing_or_bad_inputs(self):
        # #82 AC3: glue-level input validation never guesses — a missing
        # payload, a dangling --replace value, or stray argv all fail closed
        # before the canonical primitive is invoked.
        with tempfile.TemporaryDirectory() as tmp:
            payload = Path(tmp) / "plan.json"
            payload.write_text(PLAN_PAYLOAD)
            cases = [
                ((), {}),
                ((str(Path(tmp) / "absent.json"),), {}),
                ((str(payload), "--replace"), {}),
                ((str(payload), "--replace", "not-a-sha"), {}),
                ((str(payload), "--replace", "a" * 40, "extra"), {}),
                ((str(payload), "--bogus"), {}),
            ]
            for args, _env in cases:
                result = run_glue(*args, env_extra={
                    "GHT_PLAN_PUBLISH_GHT_BIN": str(Path(tmp) / "never-invoked")})
                self.assertNotEqual(result.returncode, 0, args)
                if args:  # the no-argv case is a pure usage error
                    self.assertIn("fail closed", result.stderr, args)


if __name__ == "__main__":
    unittest.main()
