"""#108: `ght release-publish` — the A-facing canonical release
publication surface (exact tag → GitHub Release → stamp → sync →
activate → read-back), fail-closed on drift/collision/mismatch and
idempotent-safe for resume."""

import json
import os
import stat
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SKILL_ROOT = Path(__file__).parents[1]
CLI = SKILL_ROOT / "scripts" / "ght.py"
REAL_GIT = "/usr/bin/git"

MOCK_GH = r'''#!/usr/bin/env python3
import json, os, shutil, sys
args = sys.argv[1:]
state_path = os.environ["GHT_RELEASE_STATE"]
state = json.load(open(state_path)) if os.path.exists(state_path) else {"releases": {}, "assets": {}}
def save():
    json.dump(state, open(state_path, "w"))
# The explicit --repo override is only valid before a repo-scoped
# subcommand, exactly like the real CLI (`gh api` refuses --repo) — the
# mock enforces the same argv shape (review R2 finding 2).
REPO_SCOPED_COMMANDS = ("issue", "pr", "release", "repo")
if args[:1] == ["--repo"]:
    command = args[2] if len(args) > 2 else None
    if command not in REPO_SCOPED_COMMANDS:
        print("unknown flag: --repo", file=sys.stderr)
        raise SystemExit(2)
    args = args[2:]
if args[:1] == ["api"] and ("--repo" in args or "-R" in args):
    print("unknown flag: --repo", file=sys.stderr)
    raise SystemExit(2)
if args[:2] == ["api", "user"]:
    print(os.environ.get("GHT_TEST_PRINCIPAL", "acct"))
    raise SystemExit(0)
if args[:2] == ["repo", "view"]:
    print("example/repo")
    raise SystemExit(0)
if args[:3] == ["api", "-X", "POST"] and len(args) > 3 and args[3].endswith("/releases"):
    body = json.loads(sys.stdin.read())
    tag = body["tag_name"]
    if tag in state["releases"]:
        print(json.dumps(state["releases"][tag]))
        raise SystemExit(0)
    rel = {"tag_name": tag, "name": body.get("name", tag), "draft": bool(body.get("draft")),
           "prerelease": bool(body.get("prerelease")), "id": len(state["releases"]) + 1}
    state["releases"][tag] = rel
    save()
    print(json.dumps(rel))
    raise SystemExit(0)
if args[:2] == ["release", "upload"]:
    # gh release upload <tag> <file...> [--clobber] — like the real CLI:
    # an existing same-name asset fails unless --clobber is passed (the
    # reconciliation contract never passes it).
    tag = args[2]
    if tag not in state["releases"]:
        print("release not found", file=sys.stderr)
        raise SystemExit(1)
    names = state.setdefault("assets", {}).setdefault(tag, [])
    for path in [a for a in args[3:] if not a.startswith("-")]:
        name = os.path.basename(path)
        dest = os.path.join(os.environ["GHT_ASSET_DIR"], name)
        if os.path.exists(dest) and "--clobber" not in args:
            print("asset with name %r already exists; use --clobber to "
                  "overwrite" % name, file=sys.stderr)
            raise SystemExit(1)
        os.makedirs(os.environ["GHT_ASSET_DIR"], exist_ok=True)
        shutil.copyfile(path, dest)
        if name not in names:
            names.append(name)
    save()
    raise SystemExit(0)
if args[:2] == ["release", "download"]:
    # gh release download <tag> --pattern <name> --dir <dir> — serves the
    # stored asset bytes like the real CLI (asset reconciliation read-back).
    tag = args[2]
    pattern = args[args.index("--pattern") + 1]
    outdir = args[args.index("--dir") + 1]
    if pattern not in state.get("assets", {}).get(tag, []):
        print("no assets match the pattern %r" % pattern, file=sys.stderr)
        raise SystemExit(1)
    src = os.path.join(os.environ["GHT_ASSET_DIR"], pattern)
    os.makedirs(outdir, exist_ok=True)
    shutil.copyfile(src, os.path.join(outdir, pattern))
    raise SystemExit(0)
if args[:1] == ["api"] and len(args) > 1 and "/releases/tags/" in args[1]:
    tag = args[1].rsplit("/", 1)[-1]
    if tag in state["releases"]:
        rel = dict(state["releases"][tag])
        rel["assets"] = [{"name": name, "size": 1}
                         for name in sorted(state.get("assets", {}).get(tag, []))]
        print(json.dumps(rel))
        raise SystemExit(0)
    print("Not Found", file=sys.stderr)
    raise SystemExit(1)
print("unsupported mock gh command", file=sys.stderr)
raise SystemExit(1)
'''


class ReleasePublishTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="ght-release-"))
        self.origin = self.tmp / "origin.git"
        self.bin = self.tmp / "bin"
        self.bin.mkdir()
        (self.bin / "gh").write_text(MOCK_GH)
        (self.bin / "gh").chmod(os.stat(self.bin / "gh").st_mode | stat.S_IXUSR)
        self.state = self.tmp / "release-state.json"
        self.state.write_text(json.dumps({"releases": {}}))
        self.assets = self.tmp / "assets"
        self.assets.mkdir()
        self.env = {
            "PATH": f"{self.bin}:{os.environ['PATH']}",
            "GHT_RELEASE_STATE": str(self.state),
            "GHT_ASSET_DIR": str(self.assets),
            "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t",
            "GIT_COMMITTER_NAME": "t", "GIT_COMMITTER_EMAIL": "t@t",
        }
        self._git(self.tmp, "init", "--bare", str(self.origin), "-b", "main")
        seed = self.tmp / "seed"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(seed))
        (seed / "skills" / "github-task" / "scripts").mkdir(parents=True)
        (seed / "skills" / "github-task" / "scripts" / "ght.py").write_text(
            "# minimal ght runtime stub\n")
        (seed / "skills" / "github-task" / "SKILL.md").write_text("# skill\n")
        (seed / "README.md").write_text("seed\n")
        self._git(seed, "add", "-A")
        self._git(seed, "-c", "user.email=t@t", "-c", "user.name=t",
                  "commit", "-qm", "seed main")
        self._git(seed, "push", "-q", "origin", "HEAD:main")
        self.target = self._git(seed, "rev-parse", "HEAD").stdout.strip()
        self.worker = self.tmp / "worker"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(self.worker))
        self.source = self.tmp / "release-source"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(self.source))
        self.notes = self.tmp / "notes.md"
        self.notes.write_text("# v9.9.9\n\nRelease notes body.\n")
    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _git(self, cwd, *args, env=None, input_text=None):
        return subprocess.run([REAL_GIT, *args], cwd=str(cwd), capture_output=True,
                              text=True, env=env or {**os.environ, **self.env},
                              input=input_text)

    def _ght(self, *args, cwd=None, env_extra=None):
        env = {**self.env, **(env_extra or {})}
        return subprocess.run([sys.executable, str(CLI), "--json", *args],
                              cwd=str(cwd or self.worker), capture_output=True,
                              text=True, env=env)

    def _publish(self, checkout=None, version="v9.9.9", target=None):
        argv = ["release-publish", "--version", version,
                "--target", target or self.target,
                "--notes-file", str(self.notes)]
        if checkout:
            argv += ["--checkout", str(checkout)]
        return self._ght(*argv, cwd=self.worker)

    def _dispatch_write(self, target, extra="# governance write\n"):
        """The durable content of a designated formal-release dispatch
        record binding `target`: an ACTIVE release instruction
        (`action: release`) User-authorized for the published version.
        The primitive's governance-eligibility grant reads exactly this
        flat head; the gate validates the full record (timing, statement,
        notes, frozen CHANGELOG) in the workflow flow."""
        return (f"{extra}action: release\nversion: v9.9.9\n"
                f"target: {target}\nauthorized_by: User\n")

    def _advance_main(self, name, content, merge=False):
        """Push an advance commit (or merge, when merge=True) onto main and
        return the new main tip."""
        moved = self.tmp / f"advance-{abs(hash(name + content))}"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(moved))
        if merge:
            self._git(moved, "checkout", "-q", "-b", f"side-{name}", "origin/main")
            (moved / name).write_text(content)
            self._git(moved, "add", "-A")
            self._git(moved, "commit", "-qm", f"side {name}")
            self._git(moved, "checkout", "-q", "main")
            self._git(moved, "merge", "--no-ff", "-q", "-m", f"merge {name}",
                      f"side-{name}")
        else:
            target_file = moved / name
            target_file.parent.mkdir(parents=True, exist_ok=True)
            target_file.write_text(content)
            self._git(moved, "add", "-A")
            self._git(moved, "commit", "-qm", f"advance main ({name})")
        self._git(moved, "push", "-q", "origin", "HEAD:main")
        return self._git(moved, "rev-parse", "HEAD").stdout.strip()

    def _remote_tag_sha(self, version):
        out = self._git(self.worker, "ls-remote", "origin",
                        f"refs/tags/{version}", f"refs/tags/{version}^{{}}").stdout
        shas = [line.split()[0] for line in out.splitlines() if line.strip()]
        return shas[-1] if shas else None

    def _pin(self):
        import hashlib
        pin_sha = self._git(self.worker, "ls-remote", "origin",
                            "refs/ght/runtime/current").stdout.split()
        if not pin_sha:
            return None
        self._git(self.worker, "fetch", "-q", "origin",
                  "+refs/ght/runtime/current:refs/ght-read/pin")
        manifest = json.loads(self._git(
            self.worker, "show", "refs/ght-read/pin:MANIFEST.json").stdout)
        self._git(self.worker, "update-ref", "-d", "refs/ght-read/pin")
        return manifest

    def _capsule_serves_as_bound_runtime(self, digest):
        """Fetch the capsule and prove `scripts/ght.py` sits at the capsule
        root (attempt-bound dispatch requires exactly that shape)."""
        import io
        import zipfile
        self._git(self.worker, "fetch", "-q", "origin",
                  f"+refs/ght/runtime/{digest}:refs/ght-read/capsule")
        zip_bytes = subprocess.run(
            [REAL_GIT, "cat-file", "blob",
             "refs/ght-read/capsule:runtime.zip"],
            cwd=str(self.worker), capture_output=True).stdout
        self._git(self.worker, "update-ref", "-d", "refs/ght-read/capsule")
        names = zipfile.ZipFile(io.BytesIO(zip_bytes)).namelist()
        self.assertIn("scripts/ght.py", names,
                      f"capsule root must carry the ght runtime: {names[:8]}")
        self.assertNotIn("skills/github-task/scripts/ght.py", names,
                         "a whole-repo capsule would break attempt-bound dispatch")

    def _remote_runtime_refs(self):
        out = self._git(self.worker, "ls-remote", "origin",
                        "refs/ght/runtime/*").stdout
        return {line.split()[1]: line.split()[0]
                for line in out.splitlines() if line.strip()}

    def _source_on_tag(self, version="v9.9.9"):
        self._git(self.source, "fetch", "-q", "origin",
                  f"+refs/tags/{version}:refs/tags/{version}")
        co = self._git(self.source, "checkout", version)
        self.assertEqual(co.returncode, 0, co.stdout + co.stderr)
        desc = self._git(self.source, "describe", "--tags", "--exact-match",
                         "--match", "v*", "HEAD")
        self.assertEqual(desc.returncode, 0, desc.stdout + desc.stderr)
        self.assertEqual(desc.stdout.strip(), version)

    # -- the AC9 matrix -------------------------------------------------

    def test_happy_path_publishes_end_to_end(self):
        # No --checkout: the surface materializes its own packaging clone
        # at the freshly minted tag (the tag does not exist beforehand).
        result = self._publish()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        payload = json.loads(result.stdout)
        self.assertEqual(payload["tag"], "created")
        self.assertEqual(payload["release"], "created")
        self.assertEqual(self._remote_tag_sha("v9.9.9"), self.target,
                         "the tag binds the requested exact target SHA")
        pin = self._pin()
        self.assertEqual(pin["release"], "v9.9.9")
        self.assertTrue(self.target.startswith(pin["source_sha"]),
                        "the capsule manifest carries the exact target source")
        self.assertIn("release", json.dumps(pin))
        # #165 AC1: the canonical downstream install surface — the release
        # asset IS the stamped distribution (same bytes as the capsule).
        self.assertEqual(payload["distribution_asset"]["name"],
                         "github-task-v9.9.9.zip")
        self.assertEqual(payload["distribution_asset"]["digest"],
                         payload["runtime"]["digest"])
        release = json.loads(self.state.read_text())
        self.assertEqual(release.get("assets", {}).get("v9.9.9"),
                         ["github-task-v9.9.9.zip"],
                         "the asset read-back proves it is on the Release")
        self.assertNotIn("DISTRIBUTION.json",
                         [p.name for p in self.source.iterdir()],
                         "the operator's checkout is never mutated by default")

    def test_republication_is_idempotent_without_rewrite(self):
        first = self._publish()
        self.assertEqual(first.returncode, 0, first.stdout + first.stderr)
        digest = json.loads(first.stdout)["runtime"]["digest"]
        again = self._publish()
        self.assertEqual(again.returncode, 0, again.stdout + again.stderr)
        payload = json.loads(again.stdout)
        self.assertEqual(payload["tag"], "idempotent")
        self.assertEqual(payload["release"], "idempotent")
        self.assertEqual(payload["runtime"]["digest"], digest,
                         "the same stamped tree yields the same capsule digest")
        self.assertEqual(len(json.loads(self.state.read_text())["releases"]), 1,
                         "the GitHub Release is reconciled, never duplicated")

    def test_target_drift_fails_closed(self):
        moved = self.tmp / "moved"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(moved))
        (moved / "extra.txt").write_text("main moved\n")
        self._git(moved, "add", "-A")
        self._git(moved, "-c", "user.email=t@t", "-c", "user.name=t",
                  "commit", "-qm", "move main")
        self._git(moved, "push", "-q", "origin", "HEAD:main")
        self._git(self.worker, "fetch", "-q", "origin")
        result = self._publish(checkout=self.source)
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("target drift", result.stdout)
        self.assertIn("A must", result.stdout,
                      "the failure demands A reconcile, not an auto-retarget")
        self.assertIsNone(self._remote_tag_sha("v9.9.9"),
                          "nothing is published from a drifted decision")

    def test_governance_only_advance_publishes_the_frozen_target(self):
        # #125 R4: an accepted-main advance made ONLY of single-parent
        # writes to the designated formal-release dispatch record whose
        # durable content binds the exact frozen target is release-cut
        # evidence, not a new source cut — with NO caller flag in
        # existence, the fresh publication still tags the FROZEN target.
        self._advance_main("docs/releases/dispatch.yaml",
                           self._dispatch_write(self.target))
        self._advance_main("docs/releases/dispatch.yaml",
                           self._dispatch_write(self.target, "# re-write\n"))
        self._git(self.worker, "fetch", "-q", "origin")
        result = self._publish()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        payload = json.loads(result.stdout)
        self.assertEqual(payload["tag"], "created")
        self.assertEqual(self._remote_tag_sha("v9.9.9"), self.target,
                         "the tag binds the frozen target, not the "
                         "governance advance")
        self.assertTrue(self.target.startswith(payload["runtime"]["source_sha"]))

    def test_source_advance_under_governance_advance_still_fails_closed(self):
        # #125 R4: the designated-record exception is exact — a designated
        # write PLUS any other content (or a source-only advance) is
        # material drift and the publication refuses.
        self._advance_main("docs/releases/dispatch.yaml",
                           self._dispatch_write(self.target))
        self._advance_main("late.txt", "source drift\n")
        self._git(self.worker, "fetch", "-q", "origin")
        result = self._publish(checkout=self.source)
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("target drift", result.stdout)
        self.assertIsNone(self._remote_tag_sha("v9.9.9"))

    def test_other_path_advance_fails_closed(self):
        # #125 R4: the designated path is policy, never selectable — a
        # governance-looking advance over ANY other repository path is
        # drift, and no caller surface exists to nominate that path as
        # governance-only.
        self._advance_main("docs/releases/other.yaml", "action: none\n")
        self._git(self.worker, "fetch", "-q", "origin")
        result = self._publish(checkout=self.source)
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("target drift", result.stdout)
        self.assertIsNone(self._remote_tag_sha("v9.9.9"))

    def test_merge_in_governance_advance_fails_closed(self):
        # #125 R3/R4: a merge commit inside the advance is never a
        # governance write — material drift, fail closed.
        self._advance_main("side.txt", "side work\n", merge=True)
        self._git(self.worker, "fetch", "-q", "origin")
        result = self._publish(checkout=self.source)
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("target drift", result.stdout)
        self.assertIsNone(self._remote_tag_sha("v9.9.9"))

    def test_unbound_or_cleared_record_keeps_exact_equality_rule(self):
        # #125 R4: the eligibility grant is the designated record's own
        # frozen-target binding. Designated-path writes that do NOT bind
        # the published target — a cleared (`action: none`) record, a
        # record bound to another SHA, or a missing record — grant
        # nothing: the fresh-publication rule stays exact current-main
        # equality, exactly as before the exception existed.
        self._advance_main("docs/releases/dispatch.yaml", "action: none\n")
        self._git(self.worker, "fetch", "-q", "origin")
        cleared = self._publish(checkout=self.source)
        self.assertNotEqual(cleared.returncode, 0,
                            cleared.stdout + cleared.stderr)
        self.assertIn("target drift", cleared.stdout)
        self.assertIsNone(self._remote_tag_sha("v9.9.9"))
        other_target = "f" * 40
        self._advance_main("docs/releases/dispatch.yaml",
                           self._dispatch_write(other_target,
                                                "# bound elsewhere\n"))
        self._git(self.worker, "fetch", "-q", "origin")
        bound_elsewhere = self._publish(checkout=self.source)
        self.assertNotEqual(bound_elsewhere.returncode, 0,
                            bound_elsewhere.stdout + bound_elsewhere.stderr)
        self.assertIn("target drift", bound_elsewhere.stdout)
        self.assertIsNone(self._remote_tag_sha("v9.9.9"))

    def test_cleared_or_non_release_records_never_grant_eligibility(self):
        # #125 R5 regression (A review of b536953): the governance-only
        # exception is granted ONLY by a mechanically valid ACTIVE
        # formal-release record — `action: release`, User-authorized, for
        # exactly the published version, binding the exact frozen target
        # in a strictly well-formed record. THE blocker case: a cleared
        # (`action: none`) designated-path record that still carries a
        # matching `target:` line must grant NOTHING — the older frozen
        # target stays ineligible and exact current-main equality rules.
        # Every malformed, duplicate, conflicting, or non-release variant
        # fails closed identically; nothing is ever published.
        matching = self.target
        cases = {
            "cleared record with a matching target line":
                f"action: none\nversion: v9.9.9\ntarget: {matching}\n"
                "authorized_by: User\n",
            "non-release action with a matching target line":
                f"action: deploy\nversion: v9.9.9\ntarget: {matching}\n"
                "authorized_by: User\n",
            "missing action":
                f"version: v9.9.9\ntarget: {matching}\nauthorized_by: User\n",
            "non-User authorization":
                f"action: release\nversion: v9.9.9\ntarget: {matching}\n"
                "authorized_by: merge of PR #123\n",
            "record for a different version":
                f"action: release\nversion: v8.8.8\ntarget: {matching}\n"
                "authorized_by: User\n",
            "duplicate target key (conflicting binding)":
                f"action: release\nversion: v9.9.9\ntarget: {matching}\n"
                f"target: {matching}\nauthorized_by: User\n",
            "malformed non-key:value line":
                f"action: release\nthis line has no colon\n"
                f"version: v9.9.9\ntarget: {matching}\nauthorized_by: User\n",
            "unclosed notes block":
                f"action: release\nversion: v9.9.9\ntarget: {matching}\n"
                "authorized_by: User\nrelease-notes-begin:\n",
        }
        for name, content in cases.items():
            # Each case advances main ONLY over designated-record writes,
            # so the range itself stays governance-shaped: the verdict is
            # carried by the record's own (non-)eligibility alone.
            self._advance_main("docs/releases/dispatch.yaml", content)
            self._git(self.worker, "fetch", "-q", "origin")
            result = self._publish(checkout=self.source)
            self.assertNotEqual(result.returncode, 0,
                                f"{name}: must fail closed — "
                                f"{result.stdout}{result.stderr}")
            self.assertIn("target drift", result.stdout, name)
            self.assertIsNone(self._remote_tag_sha("v9.9.9"),
                              f"{name}: the older frozen target stays "
                              "ineligible — nothing is published")

    def test_caller_selected_governance_paths_cannot_publish_an_older_target(self):
        # #125 R4 regression (A review of a3807c7): an arbitrary
        # caller-selected path can NEVER make an older frozen target
        # publishable. (a) The caller-selectable CLI flag is gone —
        # passing it is an argument error, even when main still equals
        # the target. (b) With main advanced over an arbitrary path, the
        # publication fails closed; nothing can nominate that path as
        # governance-only. (c) Even the designated path cannot grant
        # eligibility when its durable record does not bind this exact
        # frozen target (forged/tampered/cleared variant).
        flag = self._ght("release-publish", "--version", "v9.9.9",
                         "--target", self.target,
                         "--notes-file", str(self.notes),
                         "--governance-paths", "docs/releases/other.yaml")
        self.assertNotEqual(flag.returncode, 0, flag.stdout + flag.stderr)
        self.assertIn("unrecognized arguments", flag.stderr,
                      "no caller-selectable governance-path flag exists")
        self.assertIsNone(self._remote_tag_sha("v9.9.9"))

        # (c) even the designated path cannot grant eligibility when its
        # durable record does not bind this exact frozen target (cleared /
        # forged variant) — isolated on a designated-only advance.
        self._advance_main("docs/releases/dispatch.yaml", "action: none\n")
        self._git(self.worker, "fetch", "-q", "origin")
        forged = self._ght("release-publish", "--version", "v9.9.9",
                           "--target", self.target,
                           "--notes-file", str(self.notes),
                           cwd=self.worker)
        self.assertNotEqual(forged.returncode, 0,
                            forged.stdout + forged.stderr)
        self.assertIn("target drift", forged.stdout)
        self.assertIsNone(self._remote_tag_sha("v9.9.9"),
                          "a designated-path write that does not bind the "
                          "frozen target grants no eligibility")

        # (b) with main advanced over an arbitrary path, the publication
        # fails closed; nothing can nominate that path as governance-only.
        self._advance_main("late.txt", "arbitrary caller-selected path\n")
        self._git(self.worker, "fetch", "-q", "origin")
        drifted = self._publish(checkout=self.source)
        self.assertNotEqual(drifted.returncode, 0,
                            drifted.stdout + drifted.stderr)
        self.assertIn("target drift", drifted.stdout)
        self.assertIsNone(self._remote_tag_sha("v9.9.9"),
                          "an older frozen target is not publishable "
                          "over an arbitrary path")

    def test_tag_collision_fails_closed(self):
        other = self._git(self.worker, "commit-tree",
                          self._git(self.worker, "mktree", input_text="").stdout.strip(),
                          "-m", "unrelated commit").stdout.strip()
        self._git(self.worker, "push", "-q", "origin",
                  f"{other}:refs/tags/v9.9.9")
        result = self._publish(checkout=self.source)
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("collision", result.stdout.lower())
        self.assertNotIn(self.target, self._remote_tag_sha("v9.9.9"),
                         "the colliding tag is never force-moved")

    def test_release_identity_mismatch_fails_closed(self):
        data = json.loads(self.state.read_text())
        data["releases"]["v9.9.9"] = {
            "tag_name": "v9.9.9", "draft": True, "prerelease": False, "id": 7}
        self.state.write_text(json.dumps(data))
        result = self._publish(checkout=self.source)
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("mismatch", result.stdout.lower())

    def test_stamp_requires_exact_tag_checkout(self):
        result = self._publish(checkout=self.source)
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("does not sit exactly on", result.stdout)
        self.assertEqual(self._remote_tag_sha("v9.9.9"), self.target,
                         "tag/Release stay published (partial publication is resume-safe)")
        self.assertTrue(json.loads(self.state.read_text())["releases"]
                        .get("v9.9.9"), "the Release stays published")

    def test_resume_completes_partial_publication(self):
        partial = self._publish(checkout=self.source)
        self.assertNotEqual(partial.returncode, 0)
        self._source_on_tag()
        resumed = self._publish(checkout=self.source)
        self.assertEqual(resumed.returncode, 0, resumed.stdout + resumed.stderr)
        payload = json.loads(resumed.stdout)
        self.assertEqual(payload["tag"], "idempotent",
                         "resume never rewrites the existing immutable tag")
        self.assertEqual(payload["release"], "idempotent",
                         "resume never duplicates the existing Release")
        self.assertEqual(len(json.loads(self.state.read_text())["releases"]), 1)
        self.assertTrue(self.target.startswith(
            payload["runtime"]["source_sha"]), "read-back passes after resume")

    def test_checkout_must_be_the_exact_clean_frozen_target(self):
        # R3 finding 1 (producer): the explicit --checkout must be the EXACT
        # CLEAN frozen target BEFORE anything is stamped, synced, or
        # uploaded. Matching the tag NAME is not enough — a checkout that
        # sits on a same-named tag at a DIFFERENT commit (a parallel/forged
        # checkout) must fail closed, and nothing may be published from it.
        stray = self.tmp / "stray-checkout"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(stray))
        stray_commit = self._git(stray, "commit-tree",
                                 self._git(stray, "mktree", input_text="").stdout.strip(),
                                 "-m", "parallel commit carrying a same-named tag"
                                 ).stdout.strip()
        self._git(stray, "tag", "v9.9.9", stray_commit)
        self._git(stray, "checkout", "-q", "v9.9.9")
        desc = self._git(stray, "describe", "--tags", "--exact-match",
                         "--match", "v*", "HEAD")
        self.assertEqual(desc.stdout.strip(), "v9.9.9",
                         "fixture: the forged checkout sits exactly on the tag NAME")
        self.assertNotEqual(self._git(stray, "rev-parse", "HEAD").stdout.strip(),
                            self.target,
                            "fixture: the forged checkout is NOT the frozen target")
        result = self._publish(checkout=stray)
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("frozen target", result.stdout)
        self.assertEqual(self._remote_runtime_refs(), {},
                         "no capsule is published from a checkout that is not the "
                         "exact frozen target")
        state = json.loads(self.state.read_text())
        self.assertEqual(state.get("assets", {}).get("v9.9.9", []),
                         [], "no install asset is published from forged bytes")

    def test_checkout_must_be_clean(self):
        # R3 finding 1 (producer): a dirty checkout — even sitting exactly
        # on the release tag — packages modified bytes. The producer must
        # prove the packaged distribution is the exact CLEAN frozen target
        # and fail closed before stamping/publishing anything.
        partial = self._publish(checkout=self.source)
        self.assertNotEqual(partial.returncode, 0,
                            "fixture: the un-checkouted source fails at stamping "
                            "and minted the tag/Release (resume-safe partial state)")
        self._source_on_tag()
        (self.source / "SKILL.md").write_text("# locally modified\n")
        dirty = self._git(self.source, "status", "--porcelain")
        self.assertTrue(dirty.stdout.strip(), "fixture: the checkout is dirty")
        result = self._publish(checkout=self.source)
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("clean", result.stdout)
        self.assertEqual(self._remote_runtime_refs(), {},
                         "no capsule is published from a dirty checkout")
        state = json.loads(self.state.read_text())
        self.assertEqual(state.get("assets", {}).get("v9.9.9", []),
                         [], "no install asset is published from dirty bytes")

    def test_resume_after_main_advance_completes_exact_identity_publication(self):
        # AC2/AC5 R2: a partial publication whose tag/Release froze at the
        # requested target RESUMES after accepted main advances — the
        # freeze gate applies only to fresh publications, and the existing
        # immutable facts are never rewritten.
        partial = self._publish(checkout=self.source)
        self.assertNotEqual(partial.returncode, 0)
        self.assertEqual(self._remote_tag_sha("v9.9.9"), self.target)
        self._source_on_tag()
        moved = self.tmp / "moved"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(moved))
        (moved / "after.txt").write_text("main advanced\n")
        self._git(moved, "add", "-A")
        self._git(moved, "-c", "user.email=t@t", "-c", "user.name=t",
                  "commit", "-qm", "advance main")
        self._git(moved, "push", "-q", "origin", "HEAD:main")
        self._git(self.worker, "fetch", "-q", "origin")
        resumed = self._publish(checkout=self.source)
        self.assertEqual(resumed.returncode, 0, resumed.stdout + resumed.stderr)
        payload = json.loads(resumed.stdout)
        self.assertEqual(payload["tag"], "idempotent")
        self.assertEqual(payload["release"], "idempotent")
        self.assertEqual(payload["runtime"]["source_sha"], self.target[:7],
                         "the capsule still proves the frozen target, not new main")
        self._capsule_serves_as_bound_runtime(payload["runtime"]["digest"])

    def test_machine_identities_are_refused(self):
        for identity in ("GHT_RECONCILER_ID", "GHT_PLAN_PUBLISHER_ID"):
            result = self._ght("release-publish", "--version", "v9.9.9",
                               "--target", self.target,
                               "--notes-file", str(self.notes),
                               env_extra={identity: "machine-id"})
            self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertIn("identity", result.stdout)

    def test_read_back_mismatch_fails_closed(self):
        # Unit proof of the AC6 read-back: a pin whose manifest does not
        # prove the requested identity is rejected.
        from github_task.cli import (Context, _read_runtime_pin,
                                     _verify_release_runtime_publication)
        from github_task import cli as ght_cli
        cwd = os.getcwd()
        os.chdir(self.worker)
        try:
            ctx = Context()
            digest = "d" * 64
            payload, manifest = ght_cli._runtime_capsule_payload(SKILL_ROOT)
            manifest = {**manifest, "digest": digest, "release": "v9.9.9",
                        "source_sha": self.target[:7]}
            blob_p = self._git(self.worker, "hash-object", "-w", "--stdin",
                               input_text=json.dumps(manifest)).stdout.strip()
            tree = self._git(self.worker, "mktree", input_text=(
                f"100644 blob {blob_p}\tMANIFEST.json\n")).stdout.strip()
            commit = self._git(self.worker, "commit-tree", tree,
                               "-m", "pin").stdout.strip()
            self._git(self.worker, "push", "-q", "origin",
                      f"{commit}:refs/ght/runtime/{digest}")
            self._git(self.worker, "push", "-q", "origin",
                      f"{commit}:refs/ght/runtime/current")
            with self.assertRaises(Exception) as ctx_exc:
                _verify_release_runtime_publication(ctx, digest, "v1.0.0",
                                                    self.target)
            self.assertIn("mismatch", str(ctx_exc.exception))
            ok = _verify_release_runtime_publication(ctx, digest, "v9.9.9",
                                                     self.target)
            self.assertEqual(ok["release"], "v9.9.9")
        finally:
            os.chdir(cwd)


if __name__ == "__main__":
    unittest.main()
