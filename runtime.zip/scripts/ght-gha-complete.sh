#!/bin/sh
# Minimal GitHub Actions glue for the canonical executor-neutral completion
# primitive (#67 bootstrap). This script owns NO completion semantics: it
# only resolves the (issue, pr) pair from canonical metadata — or takes the
# explicit workflow_dispatch inputs — and invokes
# `ght complete <issue> --pr <pr>`. Every durable predicate (exact Candidate,
# durable A acceptance, merged head == Candidate, delivery/claim/namespace/
# lease-reservation facts) is verified by ght itself. Any failure exits
# non-zero with diagnostics; there is deliberately no retry-with-different-
# input, best-effort cleanup, or state rewriting here.
#
# Usage:
#   ght-gha-complete.sh resolve                 # emits issue=/pr= lines
#   ght-gha-complete.sh complete <issue> <pr>   # runs the canonical primitive
#
# Environment (set by the workflow):
#   GHA_EVENT_NAME     pull_request | workflow_dispatch
#   GHA_PR_NUMBER      pull_request event: the merged PR number
#   GHA_HEAD_REF       pull_request event: the PR head branch
#                      (canonical claim branch: agent/<issue>/<id>)
#   GHA_DISPATCH_ISSUE / GHA_DISPATCH_PR   workflow_dispatch inputs
#   GHT_COMPLETE_GHT_BIN   test seam: alternative ght entrypoint to exec
set -eu

die() {
    echo "ght-gha-complete: $1" >&2
    exit 1
}

require_digits() {
    case "$1" in
        ''|*[!0-9]*) die "expected a numeric $2, got '$1'; refusing to guess — fail closed" ;;
    esac
}

script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

resolve() {
    case "${GHA_EVENT_NAME:-}" in
        pull_request)
            [ -n "${GHA_PR_NUMBER:-}" ] || die "pull_request event without a PR number"
            require_digits "$GHA_PR_NUMBER" "PR number"
            # Applicability boundary (#81): the Mechanical Reconciler only
            # applies to merged ght Candidate PRs. A head ref outside the
            # canonical attempt-branch namespace (agent/*) is clearly NOT
            # applicable — A-owned docs/release/other PRs end here as an
            # explicit no-op success, never a red failure. A ref that DOES
            # enter the agent/ namespace but is not exactly
            # agent/<digits>/<id> is applicable-but-untrusted and fails
            # closed; a missing head ref is contradictory metadata and also
            # fails closed.
            [ -n "${GHA_HEAD_REF:-}" ] || die "pull_request event without a head ref; metadata is contradictory — fail closed"
            case "${GHA_HEAD_REF}" in
                agent/*)
                    tail=${GHA_HEAD_REF#agent/}
                    case "$tail" in
                        */*) ;;
                        *) die "head ref '${GHA_HEAD_REF}' entered the ght attempt-branch namespace but is not the canonical agent/<issue>/<id> shape; the Candidate identity is untrusted — fail closed" ;;
                    esac
                    issue=${tail%%/*}
                    require_digits "$issue" "issue number derived from head ref"
                    rest=${tail#"$issue"/}
                    case "$rest" in
                        */*) die "head ref '${GHA_HEAD_REF}' entered the ght attempt-branch namespace but has a non-canonical multi-segment shape (agent/<issue>/<id> expected); the Candidate identity is untrusted — fail closed" ;;
                        ?*) ;;
                        "") die "head ref '${GHA_HEAD_REF}' carries no attempt id; the Candidate identity is untrusted — fail closed" ;;
                    esac
                    echo "applicable=true"
                    echo "issue=$issue"
                    echo "pr=$GHA_PR_NUMBER"
                    ;;
                *)
                    echo "ght-gha-complete: head ref '${GHA_HEAD_REF}' is not a ght attempt branch; PR #$GHA_PR_NUMBER is not applicable — completion skipped (no-op success)" >&2
                    echo "applicable=false"
                    ;;
            esac
            ;;
        workflow_dispatch)
            [ -n "${GHA_DISPATCH_ISSUE:-}" ] || die "workflow_dispatch requires an explicit issue input"
            [ -n "${GHA_DISPATCH_PR:-}" ] || die "workflow_dispatch requires an explicit pr input"
            require_digits "$GHA_DISPATCH_ISSUE" "issue input"
            require_digits "$GHA_DISPATCH_PR" "pr input"
            echo "applicable=true"
            echo "issue=$GHA_DISPATCH_ISSUE"
            echo "pr=$GHA_DISPATCH_PR"
            ;;
        *)
            die "unsupported event '${GHA_EVENT_NAME:-}'; only pull_request (merged) and
workflow_dispatch are handled"
            ;;
    esac
}

complete() {
    issue=$1
    pr=$2
    require_digits "$issue" "issue argument"
    require_digits "$pr" "pr argument"
    # The canonical primitive; --json so failures carry structured
    # diagnostics. exec propagates its exit code unchanged: ght already
    # fails closed on every missing/conflicting durable fact.
    echo "ght-gha-complete: invoking canonical completion (gh complete $issue --pr $pr)" >&2
    if [ -n "${GHT_COMPLETE_GHT_BIN:-}" ]; then
        exec "${GHT_COMPLETE_GHT_BIN}" --json complete "$issue" --pr "$pr"
    fi
    exec "${GHT_COMPLETE_PYTHON:-python3}" "${script_dir}/ght.py" --json complete "$issue" --pr "$pr"
}

case "${1:-}" in
    resolve)
        [ $# -eq 1 ] || die "resolve takes no arguments"
        resolve
        ;;
    complete)
        [ $# -eq 3 ] || die "complete takes exactly <issue> <pr>"
        complete "$2" "$3"
        ;;
    *)
        die "usage: ght-gha-complete.sh resolve | complete <issue> <pr>"
        ;;
esac
